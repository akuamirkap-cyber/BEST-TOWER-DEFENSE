import { useEffect, useRef, useState } from 'react';
import type { CSSProperties } from 'react';
import { Game } from './game/engine';
import type { GameState, FloatText } from './game/engine';
import { ORC_DATA, TOWER_DATA } from './game/newcomers';
import type { OrcKind, TowerKind } from './game/newcomers';

const TOWER_ORDER = Object.keys(TOWER_DATA) as TowerKind[];

function Pill({ children, bg }: { children: React.ReactNode; bg: string }) {
  return <div className="pill-pop px-3 py-1 flex items-center gap-1.5" style={{ background: bg }}>{children}</div>;
}
function Btn({ children, onClick, bg, shadow, className = '', style, disabled }: { children: React.ReactNode; onClick?: () => void; bg: string; shadow: string; className?: string; style?: CSSProperties; disabled?: boolean }) {
  // pointer-events-auto is REQUIRED: the HUD wrapper is pointer-events-none and that property is inherited,
  // so without this no button in the top bar ever receives a click.
  return <button onClick={onClick} disabled={disabled} className={`btn-candy pointer-events-auto text-white ${className}`} style={{ background: bg, ['--shadow' as string]: shadow, ...style }}>{children}</button>;
}
function Overlay({ children, dark }: { children: React.ReactNode; dark?: boolean }) {
  return (
    <div className={`absolute inset-0 flex items-center justify-center p-3 overflow-y-auto ${dark ? 'bg-slate-900/75' : 'bg-gradient-to-b from-sky-400/80 via-cyan-300/75 to-emerald-300/80'} backdrop-blur-[2px]`}>
      <div className="relative text-center max-w-lg w-full panel-pop p-5 pop-in my-auto" style={{ background: dark ? 'linear-gradient(180deg,#475569,#1e293b)' : 'linear-gradient(180deg,#7dd3fc,#2563eb)' }}>{children}</div>
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [s, setS] = useState<GameState | null>(null);
  const [floats, setFloats] = useState<FloatText[]>([]);
  const [towerPortraits, setTowerPortraits] = useState<Partial<Record<TowerKind, string>>>({});
  const [orcPortraits, setOrcPortraits] = useState<Partial<Record<OrcKind, string>>>({});

  useEffect(() => {
    if (!canvasRef.current) return;
    const g = new Game(canvasRef.current, setS, f => {
      setFloats(prev => [...prev.slice(-18), f]);
      setTimeout(() => setFloats(prev => prev.filter(x => x.id !== f.id)), 1100);
    });
    gameRef.current = g;
    setS({ ...g.state }); // push state right away so every button already holds the game instance
    // two extra WebGL contexts, staggered: creating them at the very same moment can make the browser drop one
    const tm1 = window.setTimeout(() => setTowerPortraits(g.makePortraits()), 80);
    const tm2 = window.setTimeout(() => setOrcPortraits(g.makeOrcPortraits()), 450);
    return () => { window.clearTimeout(tm1); window.clearTimeout(tm2); g.destroy(); };
  }, []);

  const g = gameRef.current;
  const sel = s?.selected ?? null;
  // ONLY the orcs that the wave generator can really produce are shown (no ghost entries in the roster)
  const spawnKinds = g?.rosterKinds() ?? [];

  return (
    <div className="fixed inset-0 overflow-hidden bg-sky-300 select-none" style={{ touchAction: 'none' }}>
      <canvas ref={canvasRef} className="block w-full h-full" />

      {floats.map(f => (
        <div key={f.id} className="absolute pointer-events-none font-display text-xl text-outline-sm float-up" style={{ left: f.x, top: f.y, color: f.color, transform: 'translate(-50%,-50%)' }}>{f.text}</div>
      ))}

      {s && s.screen !== 'menu' && (
        <>
          {/* top HUD */}
          <div className="absolute top-0 left-0 right-0 p-2 sm:p-3 flex items-start justify-between gap-2 pointer-events-none">
            <div className="flex flex-col gap-1.5">
              <Pill bg="linear-gradient(180deg,#c084fc,#7c3aed)"><span className="text-xs text-white/90">LEVEL</span><b className="font-display text-xl text-white text-outline-sm">{s.level}</b></Pill>
              <Pill bg="linear-gradient(180deg,#60a5fa,#2563eb)"><span className="text-xs text-white/90">WAVE</span><b className="font-display text-xl text-white text-outline-sm">{s.wave}<span className="text-sm text-white/80">/{s.wavesPerLevel}</span></b></Pill>
              <Btn onClick={() => g?.cycleSpeed()} bg={s.speed === 1 ? 'linear-gradient(180deg,#94a3b8,#475569)' : s.speed === 2 ? 'linear-gradient(180deg,#38bdf8,#0284c7)' : 'linear-gradient(180deg,#f472b6,#db2777)'} shadow="#281430" className="px-3 py-1 text-base">⏩ {s.speed}×</Btn>
            </div>
            <div className="flex flex-col items-center gap-1.5">
              {!s.waveActive && (
                <>
                  <Btn onClick={() => g?.callWave()} bg="linear-gradient(180deg,#86efac,#16a34a)" shadow="#14532d" className="px-5 py-2 text-lg wiggle">
                    ▶ {s.wave === 0 ? 'MULAI!' : 'WAVE BERIKUTNYA'} <span className="text-yellow-200 text-sm">({Math.ceil(s.countdown)}s{s.wave > 0 ? ` +${Math.floor(s.countdown * 2)}💰` : ''})</span>
                  </Btn>
                  {s.nextWave && <Pill bg="linear-gradient(180deg,#fef3c7,#fde68a)"><span className="text-[10px] text-amber-900 font-black">BERIKUTNYA</span><span className="text-amber-950 text-xs font-black">{s.nextWave}</span></Pill>}
                </>
              )}
              {s.waveActive && <Pill bg="linear-gradient(180deg,#fda4af,#e11d48)"><span className="text-xs text-white/90">MUSUH</span><b className="font-display text-xl text-white text-outline-sm">{s.enemiesLeft}</b></Pill>}
            </div>
            <div className="flex flex-col items-end gap-1.5">
              <Pill bg="linear-gradient(180deg,#fde68a,#f59e0b)"><span className="text-lg">💰</span><b className="font-display text-xl text-white text-outline-sm">{s.gold}</b></Pill>
              <Pill bg={s.lives <= 3 ? 'linear-gradient(180deg,#fca5a5,#dc2626)' : 'linear-gradient(180deg,#f9a8d4,#db2777)'}><span className="text-lg">❤️</span><b className="font-display text-xl text-white text-outline-sm">{s.lives}</b></Pill>
              <Btn onClick={() => g?.toggleMute()} bg={s.muted ? 'linear-gradient(180deg,#e2e8f0,#94a3b8)' : 'linear-gradient(180deg,#7dd3fc,#0284c7)'} shadow="#281430" className="w-10 h-10 text-base">{s.muted ? '🔇' : '🔊'}</Btn>
            </div>
          </div>

          {/* bottom: tower picker / upgrade panel */}
          <div className="absolute bottom-0 left-0 right-0 h-52 pointer-events-none" style={{ background: 'linear-gradient(0deg, rgba(59,29,90,0.72), rgba(59,29,90,0.22) 55%, transparent)' }} />
          <div className="absolute bottom-0 left-0 right-0 pb-2 sm:pb-3 flex justify-center pointer-events-none">
            {sel ? (
              <div className="pointer-events-auto mx-2 panel-pop p-2.5 sm:p-3 flex flex-wrap items-center gap-2 sm:gap-3 max-w-3xl" style={{ background: 'linear-gradient(180deg,#fff7ed,#fed7aa)' }}>
                <div className="w-[68px] h-[68px] rounded-2xl border-[3px] border-[#281430] overflow-hidden shrink-0" style={{ background: `radial-gradient(circle at 50% 62%, ${TOWER_DATA[sel.kind].color2}, ${TOWER_DATA[sel.kind].color})` }}>
                  {towerPortraits[sel.kind] ? <img src={towerPortraits[sel.kind]} alt={TOWER_DATA[sel.kind].name} className="w-full h-full object-contain" /> : <div className="w-full h-full flex items-center justify-center text-3xl">{TOWER_DATA[sel.kind].icon}</div>}
                </div>
                <div className="text-[#281430] min-w-[140px]">
                  <div className="font-display text-lg leading-tight">{TOWER_DATA[sel.kind].name} <span className="text-amber-500 text-outline-sm">{'★'.repeat(sel.level)}</span><span className="text-black/20">{'★'.repeat(3 - sel.level)}</span></div>
                  <div className="text-[11px] font-semibold text-[#281430]/80 leading-tight">
                    {sel.kind === 'gravity' ? '🌀 tarik' : sel.kind === 'tornado' ? '🌪️ angkat' : sel.kind === 'meteor' ? '☄️ ledak' : sel.kind === 'midas' ? '💰 eksekusi' : '⚔️'} {sel.dmg} · 📏 {sel.range} · ⏱ {sel.rate}/dtk
                    {sel.splash > 0 && <span> · 💥 {sel.splash}</span>}
                  </div>
                  <div className="text-[11px] font-semibold text-[#281430]/70 leading-tight">{TOWER_DATA[sel.kind].role} · {TOWER_DATA[sel.kind].tag}</div>
                </div>
                {sel.upgradeCost != null ? (
                  <Btn onClick={() => g?.upgradeSelected()} disabled={s.gold < sel.upgradeCost} bg="linear-gradient(180deg,#7dd3fc,#2563eb)" shadow="#1e3a8a" className="px-4 py-2 text-base leading-tight disabled:opacity-60">
                    ⬆ UPGRADE<br /><span className="text-xs text-yellow-200">{sel.upgradeCost}💰</span>
                  </Btn>
                ) : <div className="font-display text-amber-500 text-lg px-2">MAX</div>}
                <Btn onClick={() => g?.sellSelected()} bg="linear-gradient(180deg,#fda4af,#e11d48)" shadow="#881337" className="px-3 py-2 text-sm leading-tight">JUAL<br /><span className="text-xs text-yellow-200">+{sel.sellValue}💰</span></Btn>
                <Btn onClick={() => g?.selectTower(null)} bg="linear-gradient(180deg,#f1f5f9,#cbd5e1)" shadow="#281430" className="w-9 h-9 text-base text-[#281430]">✕</Btn>
              </div>
            ) : (
              <div className="pointer-events-auto w-full overflow-x-auto no-scrollbar px-2">
                <div className="flex gap-2 w-max mx-auto items-end">
                  {TOWER_ORDER.map(k => {
                    const d = TOWER_DATA[k]; const active = s.selectedType === k; const can = s.gold >= d.cost;
                    return (
                      <button key={k} onClick={() => g?.setSelectedType(k)} className={`card-tower relative w-[92px] p-1.5 flex flex-col items-center ${active ? 'selected' : ''}`} style={{ background: active ? 'linear-gradient(180deg,#ffffff,#fde68a)' : 'linear-gradient(180deg,#fffaf0,#fcd9a8)' }}>
                        <div className="portrait-win w-full h-[54px]" style={{ background: `radial-gradient(circle at 50% 62%, ${d.color2}, ${d.color})` }}>
                          {towerPortraits[k] ? <img src={towerPortraits[k]} alt={d.name} className={`absolute inset-0 w-full h-full object-contain ${can ? '' : 'grayscale'}`} /> : <div className="absolute inset-0 flex items-center justify-center text-2xl">{d.icon}</div>}
                        </div>
                        <div className="font-display text-[13px] text-[#281430] mt-1 leading-none">{d.name}</div>
                        <div className="price-tag mt-1 px-2.5 py-0.5 flex items-center gap-1 font-display text-[13px] leading-none" style={{ background: can ? 'linear-gradient(180deg,#fde68a,#f59e0b)' : 'linear-gradient(180deg,#fca5a5,#ef4444)', color: can ? '#3b1d00' : '#fff' }}>
                          <span className="text-[11px]">🪙</span>{d.cost}
                        </div>
                        {active && <div className="absolute -top-2 left-1/2 -translate-x-1/2 text-base">👆</div>}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
          {s.wave === 0 && !sel && s.screen === 'playing' && (
            <div className="absolute left-0 right-0 text-center pointer-events-none px-4" style={{ bottom: 210 }}>
              <span className="inline-block pill-pop text-[#281430] text-xs font-bold px-4 py-1.5" style={{ background: 'linear-gradient(180deg,#fffbeb,#fde68a)' }}>
                👆 Pilih tower di bawah, lalu ketuk rumput untuk membangun · ketuk tower untuk upgrade
              </span>
            </div>
          )}
        </>
      )}

      {/* menu */}
      {s?.screen === 'menu' && (
        <Overlay>
          <div className="text-7xl mb-1 wiggle inline-block">🏰</div>
          <h1 className="font-display text-5xl sm:text-6xl text-white text-outline leading-none">VOXEL<span className="text-yellow-300">DEFENSE</span></h1>
          <p className="text-white font-semibold mt-3 max-w-md mx-auto text-sm drop-shadow">
            Orc datang dari kiri. Pilih di antara <b>5 tower</b> unik, upgrade ke level 3, dan tahan 5 wave!
          </p>

          {/* tower roster */}
          <div className="mt-3 text-left">
            <div className="font-display text-lg text-white text-outline-sm mb-1">🏰 TOWER ({TOWER_ORDER.length} — semuanya bisa dipakai)</div>
            <div className="grid grid-cols-5 gap-1.5">
              {TOWER_ORDER.map(k => {
                const d = TOWER_DATA[k];
                return (
                  <div key={k} className="rounded-xl border-2 border-[#281430] p-1 text-center" style={{ background: `linear-gradient(180deg, ${d.color2}, ${d.color})` }}>
                    <div className="text-lg leading-none">{d.icon}</div>
                    <div className="font-display text-[10px] text-white leading-tight">{d.nick}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* orc roster */}
          <div className="mt-3 text-left">
            <div className="font-display text-lg text-white text-outline-sm mb-1">👹 MUSUH ({spawnKinds.length} JENIS — yang benar-benar muncul)</div>
            <div className="flex flex-col gap-1.5">
              {spawnKinds.map(k => {
                const d = ORC_DATA[k];
                return (
                  <div key={k} className="flex items-center gap-2 rounded-xl border-2 border-[#281430] p-1.5" style={{ background: `radial-gradient(circle at 50% 60%, ${d.color[0]}, ${d.color[1]})` }}>
                    <div className="relative w-10 h-10 shrink-0 overflow-hidden rounded-lg border-2 border-[#281430]" style={{ background: `radial-gradient(circle at 50% 60%, ${d.color[0]}, ${d.color[1]})` }}>
                      {orcPortraits[k] ? <img src={orcPortraits[k]} alt={d.name} className="absolute inset-0 w-full h-full object-contain" /> : <div className="absolute inset-0 flex items-center justify-center text-xl">{d.icon}</div>}
                    </div>
                    <div className="flex-1 min-w-0 text-[#281430]">
                      <div className="flex items-center gap-1.5">
                        <span className="font-display text-sm leading-none">{d.name}</span>
                        <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full border-2 border-[#281430]" style={{ background: d.difficulty >= 3 ? '#fbbf24' : d.difficulty === 2 ? '#86efac' : '#e0e7ff' }}>
                          {'★'.repeat(d.difficulty)}
                        </span>
                      </div>
                      <div className="text-[10px] font-semibold leading-tight opacity-85">{d.desc}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <Btn onClick={() => g?.startGame()} bg="linear-gradient(180deg,#86efac,#16a34a)" shadow="#14532d" className="mt-5 text-3xl px-10 py-3">MAIN!</Btn>
          {s.best > 0 && <div className="text-white font-bold mt-3 text-sm drop-shadow">🏆 Skor terbaik: {s.best}</div>}
        </Overlay>
      )}

      {/* level complete */}
      {s?.screen === 'levelComplete' && (
        <Overlay>
          <div className="text-7xl mb-1 animate-bounce inline-block">🎉</div>
          <h2 className="font-display text-4xl sm:text-5xl text-white text-outline">LEVEL {s.level} SELESAI!</h2>
          <div className="text-4xl mt-2 text-yellow-300 text-outline-sm">{'★'.repeat(s.lives >= 8 ? 3 : s.lives >= 4 ? 2 : 1)}<span className="text-white/30">{'★'.repeat(3 - (s.lives >= 8 ? 3 : s.lives >= 4 ? 2 : 1))}</span></div>
          <div className="flex gap-2 justify-center mt-4">
            {[['Skor', s.score], ['Kill', s.kills], ['Bonus', `+${90 + (s.level + 1) * 25}💰`]].map(([l, v]) => (
              <div key={String(l)} className="pill-pop px-4 py-1.5 text-white" style={{ background: 'linear-gradient(180deg,#c084fc,#7c3aed)' }}>
                <div className="text-[10px] font-black uppercase opacity-80">{l}</div><div className="font-display text-lg">{v}</div>
              </div>
            ))}
          </div>
          <p className="text-white font-bold text-sm mt-3 drop-shadow">Peta baru · orc lebih kuat · +2 ❤️</p>
          <Btn onClick={() => g?.nextLevel()} bg="linear-gradient(180deg,#86efac,#16a34a)" shadow="#14532d" className="mt-5 text-3xl px-10 py-3">LEVEL {s.level + 1} ▶</Btn>
        </Overlay>
      )}

      {/* game over */}
      {s?.screen === 'gameOver' && (
        <Overlay dark>
          <div className="text-7xl mb-1 inline-block">💔</div>
          <h2 className="font-display text-4xl sm:text-5xl text-white text-outline">KRISTAL HANCUR</h2>
          <p className="text-white font-bold mt-1">Bertahan sampai Level {s.level} · Wave {s.wave}</p>
          <div className="flex gap-2 justify-center mt-4">
            {[['Skor', s.score], ['Kill', s.kills], ['Terbaik', s.best]].map(([l, v]) => (
              <div key={String(l)} className="pill-pop px-4 py-1.5 text-white" style={{ background: 'linear-gradient(180deg,#fbbf24,#d97706)' }}>
                <div className="text-[10px] font-black uppercase opacity-80">{l}</div><div className="font-display text-lg">{v}</div>
              </div>
            ))}
          </div>
          {s.score >= s.best && s.score > 0 && <div className="font-display text-yellow-300 text-2xl mt-2 wiggle inline-block">🏆 REKOR BARU!</div>}
          <Btn onClick={() => g?.restart()} bg="linear-gradient(180deg,#86efac,#16a34a)" shadow="#14532d" className="mt-5 text-3xl px-10 py-3">MAIN LAGI</Btn>
        </Overlay>
      )}
    </div>
  );
}
