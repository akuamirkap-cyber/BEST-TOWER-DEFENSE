import * as THREE from 'three';
import { SPH, OUTLINE_MAT, makeFace, makeFlame } from './voxel';
import { buildOrc, S, C, B, cone, tor, M } from './actors';
import type { Actor, TowerModel } from './actors';

/**
 * NEWCOMERS – four brand new orcs and four brand new towers, none of which ever existed in the old roster.
 *
 * ORCS      🎃 Pecah (splits into 3 minis) · 💣 Bom (blows up on death, hurts its own side) ·
 *           🐢 Perisai (curls into an invulnerable shell) · ❄️ Pembeku (freezes towers it walks past)
 * TOWERS    🕳️ Gav (sucks every orc toward it) · 🌪️ Twisty (lifts a whole group into the air) ·
 *           🌠 Comet (calls a meteor down on the biggest cluster) · 💰 Midas (turns weak orcs into gold)
 */

// ================= ORCS =================
export type OrcKind = 'normal' | 'splitter' | 'bomber' | 'shellback' | 'frostmage';

export const ORC_DATA: Record<OrcKind, { name: string; icon: string; desc: string; hp: number; speed: number; reward: number; size: number; color: [string, string]; difficulty: 1 | 2 | 3 }> = {
  normal: { name: 'Orc', icon: '👹', desc: 'Jalan santai, mudah dikalahkan', hp: 30, speed: 1.25, reward: 6, size: 1, color: ['#bbf7d0', '#22a05a'], difficulty: 1 },
  splitter: { name: 'Orc Pecah', icon: '🎃', desc: 'Besar & lambat. Saat mati jadi 3 orc kecil!', hp: 120, speed: 0.75, reward: 16, size: 1.45, color: ['#fed7aa', '#c2410c'], difficulty: 2 },
  bomber: { name: 'Orc Bom', icon: '💣', desc: 'Bom di punggungnya meledak saat mati & melukai orc sekitar', hp: 45, speed: 1.45, reward: 11, size: 1.05, color: ['#fecaca', '#be123c'], difficulty: 2 },
  shellback: { name: 'Orc Perisai', icon: '🐢', desc: 'Masuk ke cangkang: KEBAL & berhenti, lalu jalan lagi', hp: 150, speed: 0.7, reward: 15, size: 1.12, color: ['#bbf7d0', '#166534'], difficulty: 3 },
  frostmage: { name: 'Orc Pembeku', icon: '❄️', desc: 'Membekukan tower di dekatnya supaya tidak menembak', hp: 65, speed: 1.05, reward: 14, size: 1.0, color: ['#bae6fd', '#0369a1'], difficulty: 3 },
};

/** 🎃 the splitter: an ogre-ish orc in a spiky wooden helmet with a huge rock club */
function buildSplitter(): Actor {
  const a = buildOrc(0x4f9e3c); const L = a.limbs; const wood = M(0x8a5a2b), stone = M(0x9aa4b5, 0.1, 0.5), dark = M(0x2f4f2a, 0.05, 0.7);
  const helmet = new THREE.Group(); helmet.position.y = 0.36; L.head.add(helmet);
  helmet.add(S(0.34, wood, 0, 0, -0.02, { sy: 0.72, ol: true }));
  helmet.add(tor(0.35, 0.05, dark, 0, -0.02, 0, { rx: Math.PI / 2 }));
  for (let i = 0; i < 6; i++) { const ang = (i / 6) * Math.PI * 2 + 0.4; helmet.add(cone(0.06, 0.2, stone, Math.sin(ang) * 0.28, 0.12, Math.cos(ang) * 0.28, { ol: true })); }
  for (const sd of [-1, 1]) { const pad = S(0.17, stone, sd * 0.32, 0.18, 0, { ol: true }); L.body.add(pad); L.body.add(S(0.06, M(0xfbbf24, 0.3), sd * 0.32, 0.32, 0.14, { ol: true })); }
  L.body.add(B(0.42, 0.14, 0.06, M(0x7c4a1e), 0, -0.18, 0.28, { ol: true }));
  const rock = new THREE.Group(); rock.position.set(0, -0.32, 0.04); rock.rotation.x = 1.2; L.armR.add(rock);
  rock.add(S(0.26, stone, 0, 0, 0, { ol: true, cast: true })); rock.add(S(0.14, M(0xb8c1cc, 0.12), 0.16, 0.12, 0.1, { ol: true }));
  return a;
}

/** 💣 the bomber: a small orc with a lit bomb strapped to its back */
function buildBomber(): Actor {
  const a = buildOrc(0x6abe4a); const L = a.limbs; const bombM = M(0x3b3b4d, 0.1, 0.5), rope = M(0xc9a66b, 0.1, 0.8), gold = M(0xfbbf24, 0.3, 0.3);
  const bomb = new THREE.Group(); bomb.position.set(0, 0.15, -0.42); L.body.add(bomb);
  bomb.add(S(0.26, bombM, 0, 0, 0, { ol: true, cast: true }));
  bomb.add(C(0.07, 0.07, 0.12, gold, 0, 0.26, 0, 8, true));
  bomb.add(C(0.018, 0.018, 0.16, rope, 0, 0.34, 0, 6, false));
  const f = makeFlame(0.12); f.position.set(0, 0.42, 0); bomb.add(f); L.flame = f;
  for (const sd of [-1, 1]) L.body.add(tor(0.12, 0.025, rope, sd * 0.3, 0.1, -0.1, { rz: sd * 0.7 }));
  L.body.add(B(0.08, 0.36, 0.03, rope, 0, 0.15, -0.4, {}));
  const sash = new THREE.Group(); sash.position.set(0, 0.1, 0.28); L.body.add(sash);
  sash.add(B(0.1, 0.6, 0.04, M(0xbe123c), 0, 0, 0, { rz: 0.6, ol: true }));
  sash.add(S(0.06, gold, 0, -0.1, 0.04, { ol: true }));
  return a;
}

/** 🐢 the shellback: a big domed shell on its back that swings over the head when it curls up */
function buildShellback(): Actor {
  const a = buildOrc(0x6abe4a); const L = a.limbs;
  const shell = new THREE.Group(); shell.position.set(0, 0.72, -0.1); L.body.add(shell);
  const domeG = new THREE.SphereGeometry(1, 18, 10, 0, Math.PI * 2, 0, Math.PI / 2);
  const domeM = M(0x2f7d4f, 0.1, 0.5);
  const d = new THREE.Mesh(domeG, domeM); d.scale.set(0.48, 0.42, 0.44); d.castShadow = true;
  const h = new THREE.Mesh(domeG, OUTLINE_MAT); h.scale.set(0.5, 0.44, 0.46); d.add(h); shell.add(d);
  shell.add(tor(0.42, 0.04, M(0x166534), 0, 0, 0, { rx: Math.PI / 2 }));
  for (let i = 0; i < 6; i++) { const ang = (i / 6) * Math.PI * 2; shell.add(S(0.1, M(0x166534, 0.1), Math.sin(ang) * 0.28, 0.16, Math.cos(ang) * 0.28, { ol: true })); }
  shell.add(S(0.06, M(0xfbbf24, 0.3), 0, 0.32, 0, { ol: true }));
  L.shell = shell;
  for (const sd of [-1, 1]) L.body.add(tor(0.13, 0.03, M(0x166534), sd * 0.34, 0.16, 0, { rz: sd * 0.5 }));
  return a;
}

/** ❄️ the frost mage: an icy shaman with a glowing staff that freezes towers */
function buildFrostMage(): Actor {
  const a = buildOrc(0x86c8e8); const L = a.limbs; const ice = M(0x9be8ff, 0.6, 0.25), iceD = M(0x3aa5d6, 0.2, 0.4), white = M(0xf0f9ff, 0.15, 0.8);
  const hood = new THREE.Group(); hood.position.set(0, 0.3, -0.06); L.head.add(hood);
  hood.add(S(0.46, iceD, 0, 0, 0, { sy: 0.85, ol: true }));
  hood.add(tor(0.42, 0.06, white, 0, -0.06, 0, { rx: Math.PI / 2 }));
  hood.add(cone(0.16, 0.34, ice, 0, 0.18, -0.34, { rx: -1.9, ol: true }));
  for (let i = 0; i < 3; i++) { const ang = i * 2.1; hood.add(cone(0.05, 0.18, ice, Math.sin(ang) * 0.3, 0.28, Math.cos(ang) * 0.3, { ol: true })); }
  const staff = new THREE.Group(); staff.position.set(0, -0.3, 0.04); staff.rotation.x = 1.15; L.armR.add(staff);
  staff.add(C(0.035, 0.045, 0.95, M(0x6b8fa8, 0.1, 0.6), 0, 0.5, 0, 8, true));
  const orb2 = new THREE.Mesh(new THREE.OctahedronGeometry(0.14), M(0x9be8ff, 1, 0.2)); orb2.position.y = 1.0; orb2.name = 'orb';
  const oh = new THREE.Mesh(new THREE.OctahedronGeometry(0.14), OUTLINE_MAT); oh.scale.setScalar(1.12); orb2.add(oh); staff.add(orb2);
  for (let i = 0; i < 3; i++) { const a2 = i * 2.1; staff.add(cone(0.03, 0.12, ice, Math.sin(a2) * 0.14, 0.88, Math.cos(a2) * 0.14, { ol: true })); }
  L.staff = staff;
  L.body.add(B(0.62, 0.36, 0.06, iceD, 0, -0.1, 0.3, { ol: true }));
  L.body.add(S(0.07, ice, 0, -0.1, 0.34, { ol: true }));
  return a;
}

export function buildOrcKind(kind: OrcKind): Actor {
  switch (kind) {
    case 'splitter': return buildSplitter();
    case 'bomber': return buildBomber();
    case 'shellback': return buildShellback();
    case 'frostmage': return buildFrostMage();
    default: return buildOrc(0x6abe4a);
  }
}

// ================= TOWERS =================
export type TowerKind = 'cannon' | 'gravity' | 'tornado' | 'meteor' | 'midas' | 'draco' | 'sol' | 'chroma' | 'frostbite';

export interface TowerStat {
  name: string; icon: string; nick: string; desc: string; long: string;
  cost: number; dmg: number[]; range: number[]; rate: number[]; splash: number[]; upgrade: [number, number];
  color: string; color2: string; role: string; tag: string; air: boolean;
}
export const TOWER_DATA: Record<TowerKind, TowerStat> = {
  cannon: {
    name: 'Meriam', icon: '🔵', nick: 'Bolo', desc: 'Tembak cepat, Lv2-3 meledak area', role: 'Damage', tag: 'Darat', air: false,
    long: 'Meriam bulat yang menembak cepat. Di level 2 & 3 pelurunya meledak dan mengenai orc di sekitar.',
    cost: 60, dmg: [12, 22, 38], range: [2.8, 3.0, 3.3], rate: [0.55, 0.5, 0.42], splash: [0, 1.15, 1.45], upgrade: [60, 100],
    color: '#2f6fe0', color2: '#7ab8ff',
  },
  gravity: {
    name: 'Gravitasi', icon: '🕳️', nick: 'Gav', desc: 'Menarik semua orc mendekat + kerusakan', role: 'Kontrol', tag: 'Darat + Udara', air: true,
    long: 'Bola gravitasi menarik SEMUA orc di jangkauannya mendekat (mereka jalan mundur) dan terus melukai mereka. Bagus untuk menumpuk orc supaya tower lain lebih efektif.',
    cost: 110, dmg: [6, 10, 16], range: [2.8, 3.1, 3.4], rate: [5, 4.5, 4], splash: [0, 0, 0], upgrade: [70, 110],
    color: '#6d28d9', color2: '#c4b5fd',
  },
  tornado: {
    name: 'Pusaran', icon: '🌪️', nick: 'Twisty', desc: 'Angkat orc ke udara & jatuhkan', role: 'Kontrol', tag: 'Darat', air: false,
    long: 'Melempar pusaran angin yang berjalan di sepanjang jalan. Orc yang tersangkut TERANGKAT ke udara (terpaku) dan terus terluka selama 2,5 detik.',
    cost: 100, dmg: [4, 6, 9], range: [3.2, 3.6, 4.0], rate: [4, 3.5, 3], splash: [1.2, 1.45, 1.7], upgrade: [70, 110],
    color: '#0ea5e9', color2: '#bae6fd',
  },
  meteor: {
    name: 'Meteor', icon: '🌠', nick: 'Comet', desc: 'Serangan dari langit + api yang membakar', role: 'Damage', tag: 'Darat + Udara', air: true,
    long: 'Memanggil meteor ke titik paling ramai dalam jangkauan. Ledakan besar meninggalkan kobaran api yang membakar orc selama 4 detik.',
    cost: 130, dmg: [30, 55, 90], range: [3.4, 3.8, 4.2], rate: [3.2, 2.8, 2.4], splash: [1.3, 1.5, 1.8], upgrade: [85, 130],
    color: '#dc2626', color2: '#fca5a5',
  },
  midas: {
    name: 'Alkimia', icon: '💰', nick: 'Midas', desc: 'Ubah orc sekarat jadi emas!', role: 'Eksekusi', tag: 'Darat + Udara', air: true,
    long: 'Menembakkan sinar emas ke orc paling terluka. Kalau HP-nya di bawah 30%, orc itu langsung berubah jadi EMAS dan memberi bonus besar.',
    cost: 120, dmg: [14, 24, 40], range: [3.0, 3.3, 3.6], rate: [1.1, 1.0, 0.85], splash: [0, 0, 0], upgrade: [80, 120],
    color: '#b45309', color2: '#fde68a',
  },
  draco: {
    name: 'Naga', icon: '🐉', nick: 'Draco', desc: 'Semburan api ke semua di depan', role: 'Semburan api', tag: 'Darat', air: false,
    long: 'Naga batu giok yang melingkari menaranya. Menyemburkan api seperti penyembur api ke seluruh orc yang berdiri di depannya, membakar banyak musuh sekaligus.',
    cost: 130, dmg: [4, 7, 11], range: [2.6, 2.9, 3.2], rate: [0.12, 0.1, 0.085], splash: [0, 0, 0], upgrade: [85, 130],
    color: '#0d9488', color2: '#5eead4',
  },
  sol: {
    name: 'Matahari', icon: '☀️', nick: 'Sol', desc: 'Nova cahaya: hanguskan semua di sekitar', role: 'Nova cahaya', tag: 'Darat + Udara', air: true,
    long: 'Matahari kecil yang tersenyum. Setiap beberapa detik ia meledakkan cahaya ke segala arah dan menghanguskan SEMUA musuh dalam jangkauan sekaligus. Makin ramai, makin terasa.',
    cost: 150, dmg: [26, 46, 76], range: [2.8, 3.1, 3.5], rate: [3.2, 2.8, 2.4], splash: [2.8, 3.1, 3.5], upgrade: [95, 145],
    color: '#d97706', color2: '#fde68a',
  },
  chroma: {
    name: 'Prisma', icon: '💎', nick: 'Chroma', desc: 'Balok cahaya memantul antar musuh', role: 'Pantul cahaya', tag: 'Darat + Udara', air: true,
    long: 'Kristal besar yang melayang. Balok cahayanya memantul dari satu musuh ke musuh berikutnya (2 pantulan di Lv1, 4 di Lv3), makin jauh makin lemah.',
    cost: 125, dmg: [16, 28, 46], range: [3.2, 3.5, 3.8], rate: [1.3, 1.15, 1.0], splash: [0, 0, 0], upgrade: [85, 125],
    color: '#c026d3', color2: '#f0abfc',
  },
  frostbite: {
    name: 'Beku', icon: '❄️', nick: 'Frostbite', desc: 'Sinar dingin: musuh melambat parah', role: 'Perlambat', tag: 'Darat + Udara', air: true,
    long: 'Menara es dengan mahkota salju. Sinar dinginnya menempel pada musuh: mereka jalan separuh kecepatan selama terkena, jadi sempat dibantai tower lain.',
    cost: 110, dmg: [6, 10, 16], range: [2.8, 3.1, 3.4], rate: [0.4, 0.35, 0.3], splash: [0, 0, 0], upgrade: [75, 115],
    color: '#0284c7', color2: '#bae6fd',
  },
};

function podium(level: number, accent: number) {
  const g = new THREE.Group();
  const stone = M(0x98a3b5, 0.1, 0.75), acc = M(accent, 0.35), glow = M(0xffffff, 1);
  g.add(C(0.5, 0.55, 0.22, stone, 0, 0.11, 0, 12, true));
  g.add(C(0.43, 0.47, 0.1, acc, 0, 0.26, 0, 12, true));
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + 0.26;
    const r = B(0.07, 0.06, 0.05, glow, Math.cos(a) * 0.53, 0.15, Math.sin(a) * 0.53);
    r.rotation.y = -a + Math.PI / 2; g.add(r);
  }
  const shards = new THREE.Group(); shards.name = 'shards'; shards.position.y = 0.52; g.add(shards);
  for (let i = 0; i < level; i++) {
    const a = (i * Math.PI * 2) / Math.max(1, level);
    const sh = new THREE.Mesh(new THREE.OctahedronGeometry(0.075), M(0xffffff, 0.9, 0.3));
    sh.scale.y = 1.5; sh.position.set(Math.cos(a) * 0.6, 0, Math.sin(a) * 0.6); shards.add(sh);
  }
  return g;
}
function eyesOn(host: THREE.Group, R: number, cy: number, y0: number, iris: number, skin: number, mouth: 'none' | 'grin' | 'smile' = 'grin', brows?: number) {
  const f = makeFace({ r: 0.125, gap: 0.155, iris, skin, mouth, cheeks: true, brows, body: { R, cy, sy: 1, y0 } });
  host.add(f); return f;
}

/** 🕳️ Gav – a floating gravity orb with a swirl ring and orbiting rocks */
function buildGravity(level: number): TowerModel {
  const group = podium(level, 0x6d28d9);
  const head = new THREE.Group(); head.position.y = 0.3; group.add(head);
  const dark = M(0x2b1a4a, 0.15, 0.4), purple = M(0x6d28d9, 0.4), ring = M(0xc4b5fd, 1);
  head.add(C(0.3, 0.36, 0.24, dark, 0, 0.12, 0, 12, true));
  head.add(tor(0.34, 0.04, ring, 0, 0.14, 0, { rx: Math.PI / 2 }));
  const orbG = new THREE.Group(); orbG.position.y = 0.92; head.add(orbG);
  orbG.add(S(0.34, purple, 0, 0, 0, { ol: true, cast: true }));
  const face = eyesOn(orbG, 0.34, 0, 0.02, 0xc4b5fd, 0x6d28d9, 'smile', 0x4c1d95);
  orbG.add(S(0.1, M(0xc4b5fd, 1), 0, 0.32, 0, { ol: true }));
  const swirl = new THREE.Group(); swirl.name = 'swirl'; head.add(swirl);
  for (let i = 0; i < 2; i++) { const r = tor(0.5 + i * 0.12, 0.035, ring, 0, 0.86, 0, { rx: Math.PI / 2 - 0.4 + i * 0.25 }); swirl.add(r); }
  for (let i = 0; i < 4; i++) {
    const r = new THREE.Mesh(SPH, M(0x8b8fa8, 0.2, 0.6)); r.name = 'orbit' + i;
    r.scale.setScalar(0.1); r.userData = { r: 0.62, y: 0.9, n: 4, spd: 1.6 }; head.add(r);
    const h = new THREE.Mesh(SPH, OUTLINE_MAT); h.scale.setScalar(1.12); r.add(h);
  }
  return { group, head, face, muzzle: orbG, flame: new THREE.Group() };
}

/** 🌪️ Twisty – a smiling cloud with a spinning propeller and a wind funnel */
function buildTornado(level: number): TowerModel {
  const group = podium(level, 0x0ea5e9);
  const head = new THREE.Group(); head.position.y = 0.3; group.add(head);
  const cloud = M(0xf0f9ff, 0.18, 0.85), funnel = M(0x38bdf8, 0.25, 0.5), wood = M(0xfbbf24, 0.3, 0.3);
  const cloudG = new THREE.Group(); cloudG.position.y = 0.72; head.add(cloudG);
  cloudG.add(S(0.3, cloud, 0, 0, 0, { ol: true, cast: true }));
  cloudG.add(S(0.22, cloud, -0.3, 0.08, 0, { ol: true, cast: true }));
  cloudG.add(S(0.22, cloud, 0.3, 0.08, 0, { ol: true, cast: true }));
  cloudG.add(S(0.18, cloud, 0, 0.2, -0.15, { ol: true }));
  const face = eyesOn(cloudG, 0.3, 0, 0.02, 0x0ea5e9, 0xf0f9ff, 'grin', 0x0369a1);
  // wind funnel (two stacked cones) that spins
  const funnelG = new THREE.Group(); funnelG.name = 'funnel'; funnelG.position.y = 0.32; head.add(funnelG);
  funnelG.add(C(0.26, 0.42, 0.3, funnel, 0, 0, 0, 12, true));
  funnelG.add(C(0.1, 0.26, 0.3, M(0x7dd3fc, 0.3), 0, -0.28, 0, 12, true));
  // propeller on top
  const rotor = new THREE.Group(); rotor.name = 'rotor'; rotor.position.y = 1.28; head.add(rotor);
  rotor.add(C(0.04, 0.04, 0.14, wood, 0, 0, 0, 8, true));
  for (let i = 0; i < 3; i++) { const b = B(0.34, 0.05, 0.12, wood, 0, 0, 0, { ol: true }); b.rotation.y = (i * 2 * Math.PI) / 3; const g2 = new THREE.Group(); g2.rotation.y = (i * 2 * Math.PI) / 3; g2.add(B(0.34, 0.05, 0.12, wood, 0.18, 0, 0, { ol: true })); rotor.add(g2); }
  rotor.add(S(0.08, wood, 0, 0, 0, { ol: true }));
  for (let i = 0; i < 3; i++) { const a = i * 2.1; head.add(S(0.07, M(0xbae6fd, 0.6), Math.sin(a) * 0.42, 0.5, Math.cos(a) * 0.42, { ol: true })); }
  return { group, head, face, muzzle: cloudG, flame: new THREE.Group() };
}

/** 🌠 Comet – a stone lookout with a glowing crystal and a telescope aimed at the sky */
function buildMeteor(level: number): TowerModel {
  const group = podium(level, 0xdc2626);
  const head = new THREE.Group(); head.position.y = 0.3; group.add(head);
  const stone = M(0x8b8fa8, 0.12, 0.7), stoneD = M(0x6b7280, 0.1, 0.7), gold = M(0xfbbf24, 0.35, 0.3), ember = M(0xff7a3c, 0.8, 0.35);
  head.add(C(0.36, 0.42, 0.5, stone, 0, 0.25, 0, 12, true));
  head.add(C(0.4, 0.4, 0.1, stoneD, 0, 0.52, 0, 12, true));
  const face = eyesOn(head, 0.36, 0.25, 0.34, 0xdc2626, 0x8b8fa8, 'grin', 0x4b5563);
  const crystal = new THREE.Group(); crystal.name = 'spin'; crystal.position.y = 1.0; head.add(crystal);
  const c1 = new THREE.Mesh(new THREE.OctahedronGeometry(0.22), M(0xffb37a, 1, 0.2)); c1.scale.y = 1.5;
  const c1h = new THREE.Mesh(new THREE.OctahedronGeometry(0.22), OUTLINE_MAT); c1h.scale.set(1.12, 1.62, 1.12); c1.add(c1h); crystal.add(c1);
  for (let i = 0; i < 4; i++) { const a = i * 1.57; const s2 = new THREE.Mesh(new THREE.OctahedronGeometry(0.07), M(0xffd166, 1, 0.2)); s2.position.set(Math.sin(a) * 0.3, 0, Math.cos(a) * 0.3); crystal.add(s2); }
  // telescope
  const scope = new THREE.Group(); scope.position.set(0, 0.55, 0.25); scope.rotation.x = -0.55; head.add(scope);
  scope.add(C(0.08, 0.1, 0.55, gold, 0, 0, 0, 10, true).rotateX(Math.PI / 2));
  scope.add(C(0.13, 0.13, 0.08, M(0xb45309, 0.15), 0, 0, 0.28, 10, true).rotateX(Math.PI / 2));
  scope.add(S(0.08, ember, 0, 0, 0.34, { ol: true }));
  for (let i = 0; i < 3; i++) { const a = i * 2.1; head.add(S(0.05, M(0xffd166, 1), Math.sin(a) * 0.45, 0.35 + i * 0.1, Math.cos(a) * 0.45, { ol: true })); }
  return { group, head, face, muzzle: crystal, flame: new THREE.Group() };
}

/** 💰 Midas – a golden cauldron of liquid gold with a wand, turning weak orcs into coins */
function buildMidas(level: number): TowerModel {
  const group = podium(level, 0xb45309);
  const head = new THREE.Group(); head.position.y = 0.3; group.add(head);
  const gold = M(0xfbbf24, 0.35, 0.3), goldD = M(0xb45309, 0.2, 0.4), white = M(0xfff7ed, 0.15, 0.85);
  head.add(C(0.36, 0.3, 0.5, goldD, 0, 0.25, 0, 14, true));
  head.add(C(0.36, 0.36, 0.08, gold, 0, 0.52, 0, 14, true));
  const surface = new THREE.Mesh(new THREE.CircleGeometry(0.32, 18), M(0xffe066, 1, 0.2)); surface.rotation.x = -Math.PI / 2; surface.position.y = 0.54; surface.name = 'liquid'; head.add(surface);
  for (let i = 0; i < 3; i++) { const b = S(0.07, white, Math.sin(i * 2.1) * 0.16, 0.56, Math.cos(i * 2.1) * 0.16, { ol: true }); b.name = 'bubble' + i; head.add(b); }
  for (const sd of [-1, 1]) head.add(tor(0.09, 0.03, gold, sd * 0.36, 0.28, 0, { rz: sd * Math.PI / 2 }));
  const face = eyesOn(head, 0.36, 0.25, 0.34, 0xb45309, 0xfbbf24, 'smile', 0x7c2d12);
  const wand = new THREE.Group(); wand.position.set(0, 0.45, 0.42); head.add(wand);
  wand.add(C(0.03, 0.03, 0.5, M(0x6b4423, 0.1, 0.6), 0, 0, 0.2, 8, true).rotateX(Math.PI / 2));
  const star = new THREE.Mesh(new THREE.OctahedronGeometry(0.11), M(0xffe066, 1, 0.2)); star.position.z = 0.46; star.name = 'wandStar';
  const sh = new THREE.Mesh(new THREE.OctahedronGeometry(0.11), OUTLINE_MAT); sh.scale.setScalar(1.12); star.add(sh); wand.add(star);
  const coin = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.04, 14), gold); coin.name = 'coin'; coin.position.set(0, 1.05, 0); coin.rotation.x = Math.PI / 2;
  const ch = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.04, 14), OUTLINE_MAT); ch.scale.setScalar(1.1); coin.add(ch); head.add(coin);
  return { group, head, face, muzzle: wand, flame: new THREE.Group() };
}

/** 🐉 Draco – a plump RED dragon perched on its tower (clearly different from the orange flying dragon the orcs ride:
 *  no rider, folded wings with cream membranes, a curled tail with a gold spade, gold back spikes and a big cute head
 *  whose snout IS the flamethrower nozzle. */
function buildDraco(level: number): TowerModel {
  const group = podium(level, 0xb91c1c);
  const head = new THREE.Group(); head.position.y = 0.3; group.add(head);
  const red = M(0xef4444, 0.3, 0.45), redD = M(0xb91c1c, 0.22, 0.5), belly = M(0xfca5a5, 0.18), gold = M(0xfbbf24, 0.35, 0.3), dark = M(0x7f1d1d, 0.1, 0.55), cream = M(0xfff7e0);
  // plump body
  head.add(S(0.46, red, 0, 0.46, -0.04, { sy: 0.98, sz: 1.12, cast: true, ol: true }));
  head.add(S(0.32, belly, 0, 0.38, 0.24, { sy: 0.92, sz: 0.62 }));
  // curled tail with a golden spade tip
  const tail = new THREE.Group(); tail.position.set(0, 0.32, -0.5); head.add(tail);
  tail.add(S(0.22, red, 0, 0, -0.16, { sz: 1.15, cast: true, ol: true }));
  tail.add(S(0.155, red, 0, 0.06, -0.52, { sz: 1.15, ol: true }));
  tail.add(S(0.11, red, 0, 0.16, -0.76, { ol: true }));
  tail.add(cone(0.15, 0.32, gold, 0, 0.18, -0.92, { rx: -Math.PI / 2, sz: 0.45, ol: true }));
  // golden back spikes
  for (let i = 0; i < 3; i++) head.add(cone(0.065, 0.17, gold, 0, 0.84 + i * 0.03, -0.28 + i * 0.26, { ol: true }));
  // wings: red bone fingers with a cream membrane, folded but unmistakably wings
  for (const sd of [-1, 1]) {
    const w = new THREE.Group(); w.position.set(sd * 0.4, 0.62, -0.2); w.rotation.z = -sd * 0.32; head.add(w);
    w.add(S(0.32, redD, sd * 0.12, 0.14, 0, { sx: 1.15, sy: 0.72, sz: 0.3, ol: true, cast: true }));
    for (let k = 0; k < 3; k++) w.add(S(0.13, cream, sd * (0.26 + k * 0.1), 0.12 - k * 0.07, -0.02, { sx: 1.05, sy: 0.72, sz: 0.26, ol: true }));
    const tip = cone(0.055, 0.18, gold, sd * 0.52, 0.42, 0, { ol: true }); tip.rotation.z = -sd * 1.25; w.add(tip);
  }
  // neck + big cute head
  head.add(S(0.22, red, 0, 0.76, 0.18, { sy: 1.15, sz: 1.15, ol: true }));
  const hd = new THREE.Group(); hd.position.set(0, 1.02, 0.3); head.add(hd);
  hd.add(S(0.31, red, 0, 0, 0, { sx: 1.08, sy: 0.98, sz: 1.15, cast: true, ol: true }));
  hd.add(S(0.19, belly, 0, -0.13, 0.32, { sy: 0.85, sz: 0.7, ol: true })); // snout
  for (const sd of [-1, 1]) {
    const hn = cone(0.075, 0.28, gold, sd * 0.21, 0.22, -0.12, { ol: true }); hn.rotation.z = -sd * 0.45; hd.add(hn);
    hd.add(S(0.035, dark, sd * 0.11, -0.15, 0.4, {}));                        // nostril
    const tooth = cone(0.032, 0.09, cream, sd * 0.09, -0.19, 0.38, { rx: Math.PI }); hd.add(tooth);
  }
  const face = makeFace({ r: 0.13, gap: 0.155, iris: 0x7f1d1d, skin: 0xef4444, mouth: 'grin', cheeks: true, brows: 0x7f1d1d, body: { R: 0.32, cy: 0, sy: 0.98, y0: 0.03 } });
  hd.add(face);
  return { group, head, face, muzzle: hd, flame: new THREE.Group() };
}

/** ☀️ Sol – a smiling little sun on a stone pedestal: 12 golden rays that spin, and a warm halo */
function buildSol(level: number): TowerModel {
  const group = podium(level, 0xd97706);
  const head = new THREE.Group(); head.position.y = 0.3; group.add(head);
  const sun = M(0xfbbf24, 0.45, 0.3), sunD = M(0xd97706, 0.3, 0.4), glow = M(0xfde68a, 1, 0.2), dark = M(0x92400e, 0.1, 0.5);
  head.add(S(0.3, sunD, 0, 0.28, 0, { sy: 0.55, ol: true }));
  const halo = new THREE.Mesh(new THREE.TorusGeometry(0.52, 0.025, 8, 30), new THREE.MeshBasicMaterial({ color: 0xffe9a0, transparent: true, opacity: 0.7, depthWrite: false }));
  halo.rotation.x = Math.PI / 2; halo.position.y = 0.95; halo.name = 'halo'; head.add(halo);
  const orb = new THREE.Group(); orb.position.y = 0.95; head.add(orb);
  orb.add(S(0.36, sun, 0, 0, 0, { ol: true, cast: true }));
  const rays = new THREE.Group(); rays.name = 'spin'; orb.add(rays);
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    const r = cone(0.09, 0.26, i % 2 ? sunD : sun, 0, 0, 0, { ol: true });
    r.position.set(Math.cos(a) * 0.48, 0, Math.sin(a) * 0.48);
    r.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(Math.cos(a), 0, Math.sin(a)));
    rays.add(r);
  }
  for (let i = 0; i < 3; i++) {
    const s = new THREE.Mesh(new THREE.OctahedronGeometry(0.07), glow); s.name = 'orbit' + i;
    s.userData = { r: 0.78, y: 0.95, n: 3, spd: 1.1, yIsWorld: true, off: 0.3 }; head.add(s);
  }
  const face = makeFace({ r: 0.125, gap: 0.155, iris: 0xb45309, skin: 0xfbbf24, mouth: 'grin', cheeks: true, brows: 0x92400e, body: { R: 0.36, cy: 0, sy: 1, y0: 0.03 } });
  orb.add(face);
  void dark;
  return { group, head, face, muzzle: orb, flame: new THREE.Group() };
}

/** 💎 Chroma – a beautiful PINK crystal that spins above its pedestal. The eyes live on the tower, NOT on the
 *  rotating crystal, so the face always stays turned toward the enemy no matter how the crystal spins. */
function buildChroma(level: number): TowerModel {
  const group = podium(level, 0xdb2777);
  const head = new THREE.Group(); head.position.y = 0.3; group.add(head);
  const pinkD = M(0x9d174d, 0.3, 0.4), pinkL = M(0xf9a8d4, 0.35, 0.35), glow = M(0xfbcfe8, 1, 0.2), gold = M(0xfbbf24, 0.35, 0.3);
  // pedestal with a golden cradle
  head.add(S(0.3, pinkD, 0, 0.26, 0, { sy: 0.5, ol: true }));
  const cradle = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.045, 8, 20), gold); cradle.rotation.x = Math.PI / 2; cradle.position.y = 0.52; head.add(cradle);
  // the spinning crystal (everything here rotates together)
  const prism = new THREE.Group(); prism.name = 'spin'; prism.position.y = 1.02; head.add(prism);
  const c = new THREE.Mesh(new THREE.OctahedronGeometry(0.34), M(0xf472b6, 0.55, 0.25)); c.scale.y = 1.55; prism.add(c);
  const ch = new THREE.Mesh(new THREE.OctahedronGeometry(0.34), OUTLINE_MAT); ch.scale.set(1.12, 1.73, 1.12); c.add(ch);
  const c2 = new THREE.Mesh(new THREE.OctahedronGeometry(0.19), pinkL); c2.position.y = 0.42; prism.add(c2);
  const c2h = new THREE.Mesh(new THREE.OctahedronGeometry(0.19), OUTLINE_MAT); c2h.scale.setScalar(1.18); c2.add(c2h);
  for (let i = 0; i < 3; i++) {
    const a = i * 2.094;
    const s = new THREE.Mesh(new THREE.OctahedronGeometry(0.12), glow);
    s.position.set(Math.cos(a) * 0.58, Math.sin(a * 1.4) * 0.2, Math.sin(a) * 0.58);
    const sh = new THREE.Mesh(new THREE.OctahedronGeometry(0.12), OUTLINE_MAT); sh.scale.setScalar(1.15); s.add(sh); prism.add(s);
  }
  const halo = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.025, 8, 26), new THREE.MeshBasicMaterial({ color: 0xfbcfe8, transparent: true, opacity: 0.75, depthWrite: false }));
  halo.rotation.x = Math.PI / 2; halo.position.y = 1.02; halo.name = 'halo'; head.add(halo);
  // the face is on the tower body so the eyes ALWAYS keep looking at the enemy
  const face = makeFace({ r: 0.115, gap: 0.145, iris: 0x9d174d, skin: 0xf472b6, mouth: 'grin', cheeks: true, body: { R: 0.34, cy: 1.02, sy: 1.55, y0: 1.02 } });
  head.add(face);
  return { group, head, face, muzzle: prism, flame: new THREE.Group() };
}

/** ❄️ Frostbite – a faceted ice keep with a snow-capped roof and hanging icicles, glowing frost runes,
 *  and a tall cluster of ice spires (a glacier pinnacle) on top that the snow spray is fired from. */
function buildFrostbite(level: number): TowerModel {
  const group = podium(level, 0x0284c7);
  const head = new THREE.Group(); head.position.y = 0.3; group.add(head);
  const ice = M(0x7dd3fc, 0.5, 0.3), iceD = M(0x0284c7, 0.3, 0.4), white = M(0xf0f9ff, 0.2), gold = M(0xfbbf24, 0.35, 0.3), glow = M(0xe0f2fe, 1, 0.25);
  // faceted hexagonal keep with glowing ice veins running down its sides
  head.add(C(0.36, 0.44, 0.66, iceD, 0, 0.33, 0, 6, true));
  head.add(C(0.38, 0.38, 0.08, ice, 0, 0.66, 0, 6, true));
  for (const [y, r] of [[0.52, 0.37], [0.22, 0.4]] as [number, number][]) { const ring = new THREE.Mesh(new THREE.TorusGeometry(r, 0.028, 8, 22), gold); ring.rotation.x = Math.PI / 2; ring.position.y = y; head.add(ring); }
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    const vein = B(0.045, 0.5, 0.02, glow, Math.sin(a) * 0.375, 0.36, Math.cos(a) * 0.375); vein.rotation.y = a; head.add(vein);          // ice veins
    const rune = B(0.1, 0.16, 0.03, glow, Math.sin(a) * 0.38, 0.42, Math.cos(a) * 0.38); rune.rotation.y = a; head.add(rune);            // glowing runes
  }
  // snow-capped roof with drips and hanging icicles
  head.add(C(0.4, 0.34, 0.16, white, 0, 0.74, 0, 6, true));
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    head.add(S(0.075, white, Math.sin(a) * 0.38, 0.66, Math.cos(a) * 0.38, { sy: 1.1, sz: 0.9, ol: true }));
    head.add(S(0.05, white, Math.sin(a) * 0.2, 0.76, Math.cos(a) * 0.2, { sy: 0.8, ol: true }));
    const ic = cone(0.055, 0.24, ice, Math.sin(a) * 0.36, 0.62, Math.cos(a) * 0.36, { ol: true }); ic.rotation.x = Math.PI; head.add(ic);
    const ic2 = cone(0.038, 0.15, white, Math.sin(a + 0.5) * 0.33, 0.6, Math.cos(a + 0.5) * 0.33, { ol: true }); ic2.rotation.x = Math.PI; head.add(ic2);
  }
  // soft mist pooling at the base
  for (let i = 0; i < 7; i++) {
    const a = (i / 7) * Math.PI * 2;
    head.add(S(0.13, glow, Math.sin(a) * 0.5, 0.12 + (i % 2) * 0.06, Math.cos(a) * 0.5, { sy: 0.5, sz: 0.9, ol: false }));
  }
  // the glacier pinnacle: TALL vertical ice spires bunched together (a spire – never radiating like petals)
  const spire = new THREE.Group(); spire.position.y = 0.82; head.add(spire);
  const iceL = M(0xbae6fd, 0.45, 0.25);
  const main = new THREE.Mesh(new THREE.OctahedronGeometry(0.3), iceL); main.scale.set(0.62, 1.35, 0.62); main.position.y = 0.46; spire.add(main);
  const mainOl = new THREE.Mesh(new THREE.OctahedronGeometry(0.3), OUTLINE_MAT); mainOl.scale.set(0.68, 1.44, 0.68); mainOl.position.y = 0.46; spire.add(mainOl);
  for (const [x, z, h, r] of [[-0.26, 0.1, 0.62, 0.2], [0.28, -0.13, 0.52, 0.18], [0.05, 0.3, 0.42, 0.15], [-0.14, -0.28, 0.36, 0.13]] as [number, number, number, number][]) {
    const s2 = new THREE.Mesh(new THREE.OctahedronGeometry(0.3), iceL); s2.scale.set(r / 0.3, h / 0.3, r / 0.3); s2.position.set(x, h / 2 - 0.04, z); spire.add(s2);
    const s2h = new THREE.Mesh(new THREE.OctahedronGeometry(0.3), OUTLINE_MAT); s2h.scale.set((r + 0.014) / 0.3, (h + 0.03) / 0.3, (r + 0.014) / 0.3); s2h.position.copy(s2.position); spire.add(s2h);
  }
  // a thin ring of small crystals orbiting the spire — magic, not petals
  const ring = new THREE.Group(); ring.name = 'spin'; ring.position.y = 0.72; head.add(ring);
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2;
    const c = new THREE.Mesh(new THREE.OctahedronGeometry(0.075), glow);
    c.position.set(Math.cos(a) * 0.62, 0, Math.sin(a) * 0.62); c.rotation.set(a, a * 2, 0);
    const ch = new THREE.Mesh(new THREE.OctahedronGeometry(0.075), OUTLINE_MAT); ch.scale.setScalar(1.16); c.add(ch);
    ring.add(c);
  }
  const halo = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.022, 8, 26), new THREE.MeshBasicMaterial({ color: 0xbae6fd, transparent: true, opacity: 0.6, depthWrite: false }));
  halo.rotation.x = Math.PI / 2; halo.name = 'halo'; halo.position.y = 0.72; head.add(halo);
  // gentle snowfall around the tower (the engine drifts these down and wraps them back up)
  const snowField = new THREE.Group(); snowField.name = 'snowField'; head.add(snowField);
  for (let i = 0; i < 11; i++) {
    const fl = S(0.032 + (i % 3) * 0.012, white, Math.sin(i * 2.1) * 0.62, 0.2 + ((i * 0.37) % 1) * 1.3, Math.cos(i * 1.7) * 0.62, { ol: false });
    snowField.add(fl);
  }
  // orbiting ice crystals
  for (let i = 0; i < 3; i++) {
    const s = new THREE.Mesh(new THREE.OctahedronGeometry(0.1), glow); s.name = 'orbit' + i;
    s.userData = { r: 0.62, y: 1.12, n: 3, spd: 1.5 }; head.add(s);
    const sh = new THREE.Mesh(new THREE.OctahedronGeometry(0.1), OUTLINE_MAT); sh.scale.setScalar(1.18); s.add(sh);
  }
  for (const sd of [-1, 1]) head.add(S(0.16, white, sd * 0.36, 0.46, 0.2, { sx: 1.2, sy: 0.7, sz: 1.1, ol: true }));
  const face = makeFace({ r: 0.115, gap: 0.14, iris: 0x0369a1, skin: 0x7dd3fc, mouth: 'smile', cheeks: true, body: { kind: 'cyl', R: 0.36, cy: 0.33, y0: 0.4 } });
  head.add(face);
  return { group, head, face, muzzle: spire, flame: new THREE.Group() };
}

export function buildTowerKind(kind: TowerKind, level: number): TowerModel {
  switch (kind) {
    case 'gravity': return buildGravity(level);
    case 'tornado': return buildTornado(level);
    case 'meteor': return buildMeteor(level);
    case 'midas': return buildMidas(level);
    case 'draco': return buildDraco(level);
    case 'sol': return buildSol(level);
    case 'chroma': return buildChroma(level);
    case 'frostbite': return buildFrostbite(level);
    default: {
      // cannon: fall back to the original Bolo
      const g = podium(level, 0x2b5fd9);
      const head = new THREE.Group(); head.position.y = 0.3; g.add(head);
      const blue = M(0x4f8cff), blueD = M(0x2b5fd9), gold = M(0xfbbf24, 0.3, 0.3), dark = M(0x1f2937, 0.05);
      head.add(S(0.38, blue, 0, 0.35, 0, { ol: true, cast: true }));
      head.add(S(0.22, M(0x9ec5ff), 0, 0.16, 0.26, { sy: 0.8, sz: 0.5 }));
      head.add(S(0.33, blueD, 0, 0.6, -0.02, { sy: 0.55, ol: true }));
      head.add(S(0.055, gold, 0, 0.75, -0.02, { ol: true }));
      head.add(C(0.014, 0.014, 0.16, M(0x9ca3af, 0.1), 0, 0.83, -0.02, 6, false));
      const fl = makeFlame(0.09); fl.position.set(0, 0.9, -0.02); head.add(fl);
      head.add(C(0.1, 0.13, 0.52, dark, 0, 0.26, 0.42, 12, true).rotateX(Math.PI / 2));
      head.add(C(0.155, 0.155, 0.07, gold, 0, 0.26, 0.7, 12, true).rotateX(Math.PI / 2));
      head.add(C(0.08, 0.08, 0.02, M(0x0b0b12, 0.02), 0, 0.26, 0.74, 12, false).rotateX(Math.PI / 2));
      for (const sd of [-1, 1]) head.add(C(0.085, 0.085, 0.12, gold, sd * 0.4, 0.42, 0, 10, true).rotateZ(Math.PI / 2));
      const face = eyesOn(head, 0.38, 0.35, 0.42, 0x1d4ed8, 0x4f8cff, 'none');
      return { group: g, head, face, muzzle: head, flame: fl };
    }
  }
}
