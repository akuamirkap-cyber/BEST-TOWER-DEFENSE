/**
 * Compact sound engine: everything is synthesised live with WebAudio (no audio files).
 * One master gain -> compressor, a shared hall reverb, and two buses: sound effects and a simple adaptive music loop.
 * Browsers only allow audio after the first tap, so the context is created/resumed on pointerdown or keydown.
 */
export type MusicMode = 'off' | 'menu' | 'calm' | 'battle' | 'win' | 'lose';

interface ToneOpts {
  f: number; to?: number; dur: number; type?: OscillatorType; vol?: number; attack?: number; sus?: number;
  delay?: number; at?: number; music?: boolean; lp?: number; lpTo?: number; hp?: number; q?: number; det?: number; pan?: number; rev?: number; prio?: number;
}
interface NoiseOpts {
  dur: number; vol?: number; f?: number; to?: number; q?: number; type?: BiquadFilterType; attack?: number;
  delay?: number; at?: number; music?: boolean; pan?: number; rev?: number; prio?: number;
}

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
const rnd = (a: number, b: number) => a + Math.random() * (b - a);

const PENT = [0, 2, 4, 7, 9];
const BPM: Record<MusicMode, number> = { off: 100, menu: 92, calm: 104, battle: 132, win: 124, lose: 66 };

export class Sfx {
  ctx: AudioContext | null = null;
  private _muted = false;
  private master!: GainNode; private sfxBus!: GainNode; private musicBus!: GainNode; private revIn!: GainNode;
  private noiseBuf: AudioBuffer | null = null;
  private voices = 0; private gates = new Map<string, number>();
  private mode: MusicMode = 'off'; private step = 0; private nextT = 0; private timer: number | null = null;
  private windTimer: number | null = null; private windGain: GainNode | null = null;
  private disposed = false; private started = false;
  private unlock = () => this.resume();
  private onVis = () => {
    const c = this.ctx; if (!c) return;
    if (document.hidden) c.suspend().catch(() => undefined); else if (this.started) c.resume().catch(() => undefined);
  };

  constructor() {
    if (typeof window === 'undefined') return;
    window.addEventListener('pointerdown', this.unlock, { passive: true });
    window.addEventListener('keydown', this.unlock);
    document.addEventListener('visibilitychange', this.onVis);
  }

  get muted() { return this._muted; }
  set muted(v: boolean) { this._muted = v; this.applyVolumes(); }

  resume() {
    if (this.disposed) return;
    if (!this.ctx) {
      try {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.ctx = new AC();
      } catch { this.ctx = null; return; }
      this.setup();
    }
    const c = this.ctx; if (c && c.state === 'suspended') c.resume().catch(() => undefined);
    this.started = true;
  }
  dispose() {
    this.disposed = true;
    window.removeEventListener('pointerdown', this.unlock); window.removeEventListener('keydown', this.unlock);
    document.removeEventListener('visibilitychange', this.onVis);
    if (this.timer !== null) { window.clearInterval(this.timer); this.timer = null; }
    if (this.windTimer !== null) { window.clearTimeout(this.windTimer); this.windTimer = null; }
    this.ctx?.close().catch(() => undefined); this.ctx = null;
  }

  // ---------- graph ----------
  private setup() {
    const c = this.ctx!;
    this.master = c.createGain(); this.master.gain.value = 0.9;
    const comp = c.createDynamicsCompressor(); comp.threshold.value = -16; comp.knee.value = 20; comp.ratio.value = 4;
    comp.attack.value = 0.005; comp.release.value = 0.22;
    this.master.connect(comp); comp.connect(c.destination);
    this.sfxBus = c.createGain(); this.sfxBus.connect(this.master);
    this.musicBus = c.createGain(); this.musicBus.connect(this.master);
    const conv = c.createConvolver(); conv.buffer = this.impulse(1.7, 2.4);
    this.revIn = c.createGain(); const revOut = c.createGain(); revOut.gain.value = 0.5;
    this.revIn.connect(conv); conv.connect(revOut); revOut.connect(this.master);
    const n = Math.floor(c.sampleRate * 1.5); this.noiseBuf = c.createBuffer(1, n, c.sampleRate);
    const d = this.noiseBuf.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    this.applyVolumes(); this.startWind(); this.syncMusic();
  }
  private impulse(sec: number, decay: number) {
    const c = this.ctx!; const n = Math.floor(c.sampleRate * sec); const b = c.createBuffer(2, n, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = b.getChannelData(ch); let prev = 0; for (let i = 0; i < n; i++) { const v = (Math.random() * 2 - 1) * Math.pow(1 - i / n, decay); prev = prev * 0.45 + v * 0.55; d[i] = prev; } }
    return b;
  }
  private applyVolumes() {
    const c = this.ctx; if (!c || !this.sfxBus) return; const t = c.currentTime;
    this.sfxBus.gain.setTargetAtTime(this._muted ? 0 : 1, t, 0.03);
    this.master.gain.setTargetAtTime(0.9, t, 0.05);
    this.musicBus.gain.setTargetAtTime(this._muted ? 0 : 0.55, t, 0.08);
    if (this.windGain) this.windGain.gain.setTargetAtTime(this._muted ? 0 : 0.035, t, 0.1);
  }
  private allowed(bus: boolean, prio: number) {
    if (this._muted) return false;
    if (this.voices > 70) return false;
    if (!bus && prio < 1 && this.voices > 40) return false;
    return true;
  }
  private gate(k: string, ms: number) { const n = performance.now(); const l = this.gates.get(k) ?? -1e9; if (n - l < ms) return false; this.gates.set(k, n); return true; }

  // ---------- voices ----------
  tone(o: ToneOpts) {
    const c = this.ctx; if (!c) return;
    if (!this.allowed(!!o.music, o.prio ?? 1)) return;
    const t = o.at ?? c.currentTime + (o.delay ?? 0) + 0.004;
    const osc = c.createOscillator(); osc.type = o.type ?? 'sine'; osc.frequency.setValueAtTime(o.f, t);
    if (o.to && o.to !== o.f) osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.to), t + o.dur);
    if (o.det) osc.detune.value = o.det;
    const g = c.createGain(); const peak = o.vol ?? 0.1; const a = Math.min(o.attack ?? 0.006, o.dur * 0.5);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a);
    if (o.sus) g.gain.setValueAtTime(peak, t + Math.max(a, o.dur * o.sus));
    g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    let node: AudioNode = osc;
    if (o.lp) { const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.setValueAtTime(o.lp, t); if (o.lpTo) f.frequency.exponentialRampToValueAtTime(Math.max(60, o.lpTo), t + o.dur); f.Q.value = o.q ?? 0.7; node.connect(f); node = f; }
    if (o.hp) { const f = c.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = o.hp; node.connect(f); node = f; }
    node.connect(g); this.out(g, !!o.music, o.pan, o.rev);
    osc.start(t); osc.stop(t + o.dur + 0.05); this.voices++; osc.onended = () => { this.voices--; };
  }
  noise(o: NoiseOpts) {
    const c = this.ctx; if (!c || !this.noiseBuf) return;
    if (!this.allowed(!!o.music, o.prio ?? 1)) return;
    const t = o.at ?? c.currentTime + (o.delay ?? 0) + 0.004;
    const src = c.createBufferSource(); src.buffer = this.noiseBuf; src.loop = true;
    const f = c.createBiquadFilter(); f.type = o.type ?? 'lowpass'; f.frequency.setValueAtTime(o.f ?? 1200, t);
    if (o.to) f.frequency.exponentialRampToValueAtTime(Math.max(40, o.to), t + o.dur); f.Q.value = o.q ?? 0.7;
    const g = c.createGain(); const a = Math.min(o.attack ?? 0.004, o.dur * 0.5);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(o.vol ?? 0.1, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    src.connect(f); f.connect(g); this.out(g, !!o.music, o.pan, o.rev);
    src.start(t, Math.random()); src.stop(t + o.dur + 0.05); this.voices++; src.onended = () => { this.voices--; };
  }
  private out(n: AudioNode, music: boolean, pan = 0, rev = 0) {
    const c = this.ctx!; let node: AudioNode = n;
    if (pan && typeof c.createStereoPanner === 'function') { const p = c.createStereoPanner(); p.pan.value = clamp(pan, -1, 1); node.connect(p); node = p; }
    node.connect(music ? this.musicBus : this.sfxBus);
    if (rev > 0) { const s = c.createGain(); s.gain.value = rev; node.connect(s); s.connect(this.revIn); }
  }

  // ================= SOUND EFFECTS =================
  click() { this.tone({ f: 740, to: 1120, dur: 0.07, type: 'triangle', vol: 0.07, prio: 2 }); }
  select() { this.tone({ f: 660, dur: 0.08, type: 'sine', vol: 0.07, prio: 2 }); this.tone({ f: 990, dur: 0.14, type: 'sine', vol: 0.06, delay: 0.06, rev: 0.25, prio: 2 }); }
  deny() { this.tone({ f: 190, to: 140, dur: 0.14, type: 'square', vol: 0.05, lp: 900 }); this.tone({ f: 170, to: 120, dur: 0.17, type: 'square', vol: 0.05, lp: 900, delay: 0.11 }); }
  build() {
    this.noise({ dur: 0.09, vol: 0.08, f: 700, to: 300 }); this.tone({ f: 210, to: 100, dur: 0.13, type: 'triangle', vol: 0.13 });
    [523, 659, 880].forEach((f, i) => this.tone({ f, dur: 0.2, type: 'triangle', vol: 0.06, delay: 0.06 + i * 0.05, rev: 0.3 }));
  }
  upgrade() {
    [523, 659, 784, 1047, 1319].forEach((f, i) => this.tone({ f, dur: 0.34, type: 'triangle', vol: 0.07, delay: i * 0.07, rev: 0.35 }));
    this.tone({ f: 2093, dur: 0.7, type: 'sine', vol: 0.035, delay: 0.3, rev: 0.6 });
    this.noise({ dur: 0.35, vol: 0.035, f: 7000, type: 'highpass', delay: 0.25 });
  }
  coin() {
    if (!this.gate('coin', 45)) return;
    this.tone({ f: 988, dur: 0.09, type: 'square', vol: 0.04, lp: 4000 });
    this.tone({ f: 1319, dur: 0.3, type: 'square', vol: 0.04, lp: 4000, delay: 0.07, rev: 0.25 });
    this.tone({ f: 2637, dur: 0.32, type: 'sine', vol: 0.02, delay: 0.07, rev: 0.4 });
  }
  shoot() {
    if (!this.gate('shoot', 45)) return;
    this.noise({ dur: 0.05, vol: 0.07, f: 2400, type: 'bandpass', q: 1 });
    this.tone({ f: 520, to: 110, dur: 0.12, type: 'square', vol: 0.05, lp: 1800 });
    this.tone({ f: 130, to: 60, dur: 0.16, type: 'sine', vol: 0.11 });
    this.tone({ f: 500, to: 1300, dur: 0.35, type: 'sine', vol: 0.018, delay: 0.05, rev: 0.3 });
  }
  hit() {
    if (!this.gate('hit', 35)) return;
    this.noise({ dur: 0.035, vol: 0.05, f: 3000, type: 'highpass', prio: 0 });
    this.tone({ f: 420, to: 210, dur: 0.06, type: 'triangle', vol: 0.045, prio: 0 });
  }
  boom() {
    this.noise({ dur: 0.75, vol: 0.2, f: 2200, to: 90, rev: 0.4 });
    this.tone({ f: 95, to: 32, dur: 0.58, type: 'sine', vol: 0.3 });
    this.tone({ f: 200, to: 50, dur: 0.32, type: 'sawtooth', vol: 0.06, lp: 500 });
    this.noise({ dur: 0.25, vol: 0.08, f: 6000, type: 'highpass', delay: 0.03 });
    this.noise({ dur: 0.3, vol: 0.05, f: 1800, to: 400, type: 'bandpass', delay: 0.18, rev: 0.4 });
  }
  /** Draco's flamethrower (throttled – it fires continuously) */
  flame() {
    if (!this.gate('flame', 110)) return;
    this.noise({ dur: 0.2, vol: 0.055, f: 1100, to: 500, type: 'bandpass', q: 0.55, attack: 0.03, prio: 0 });
    this.tone({ f: rnd(60, 105), to: 48, dur: 0.16, type: 'sawtooth', vol: 0.035, lp: 420, prio: 0 });
    this.tone({ f: 2400, to: 900, dur: 0.09, type: 'sine', vol: 0.012, prio: 0 });
  }
  /** Sol's nova / Chroma's beam: a bright crystalline shimmer */
  prism() {
    if (!this.gate('prism', 220)) return;
    this.noise({ dur: 0.16, vol: 0.05, f: 800, to: 4200, type: 'bandpass', q: 0.8 });
    [740, 988, 1245, 1480, 1976].forEach((f, i) => this.tone({ f, dur: 0.22, type: 'sine', vol: 0.035, delay: i * 0.035, rev: 0.5 }));
    this.tone({ f: 130, to: 55, dur: 0.22, type: 'sine', vol: 0.09 });
  }
  /** frost magic freezes a tower */
  freeze() {
    if (!this.gate('freeze', 200)) return;
    this.noise({ dur: 0.3, vol: 0.06, f: 4200, to: 900, type: 'bandpass', q: 1.2, rev: 0.35 });
    [1200, 1600, 2100, 2800].forEach((f, i) => this.tone({ f, dur: 0.22, type: 'sine', vol: 0.03, delay: i * 0.05, rev: 0.5 }));
    this.tone({ f: 180, to: 70, dur: 0.25, type: 'triangle', vol: 0.07 });
  }
  /** a tornado spins up */
  whoosh() { if (!this.gate('whoosh', 350)) return; this.noise({ dur: 0.55, vol: 0.07, f: 380, to: 2200, type: 'bandpass', q: 0.6, attack: 0.12, rev: 0.35 }); this.tone({ f: 200, to: 620, dur: 0.5, type: 'sawtooth', vol: 0.035, lp: 1200, rev: 0.25 }); }
  /** a meteor falls from the sky */
  launch() {
    this.noise({ dur: 0.6, vol: 0.1, f: 2600, to: 250, type: 'bandpass', q: 0.7, attack: 0.05, rev: 0.3 });
    this.tone({ f: 900, to: 120, dur: 0.55, type: 'sawtooth', vol: 0.06, lp: 2200, lpTo: 350, rev: 0.3 });
    this.tone({ f: 60, to: 32, dur: 0.4, type: 'sine', vol: 0.12, delay: 0.35 });
  }
  /** something heavy hits the ground hard (gravity slam, bowling ball landing) */
  thud() {
    if (!this.gate('thud', 120)) return;
    this.noise({ dur: 0.32, vol: 0.16, f: 900, to: 90, rev: 0.22 });
    this.tone({ f: 95, to: 40, dur: 0.32, type: 'sine', vol: 0.19 });
    this.noise({ dur: 0.18, vol: 0.05, f: 2800, to: 700, type: 'bandpass', delay: 0.06 });
  }
  pop() {
    if (!this.gate('pop', 30)) return;
    const j = rnd(0.9, 1.15);
    this.tone({ f: 420 * j, to: 920 * j, dur: 0.09, type: 'sine', vol: 0.08, pan: rnd(-0.4, 0.4) });
    this.tone({ f: 920 * j, to: 520 * j, dur: 0.13, type: 'sine', vol: 0.06, delay: 0.08 });
    this.noise({ dur: 0.08, vol: 0.07, f: 1800, type: 'bandpass', q: 0.8 });
    this.tone({ f: 170 * j, to: 60, dur: 0.12, type: 'triangle', vol: 0.08 });
  }
  spawn() { if (!this.gate('spawn', 130)) return; this.tone({ f: rnd(190, 260), to: rnd(380, 460), dur: 0.14, type: 'sine', vol: 0.03, pan: rnd(-0.6, 0.6), prio: 0 }); }
  hurt() {
    this.tone({ f: 260, to: 120, dur: 0.32, type: 'sawtooth', vol: 0.09, lp: 900 });
    this.noise({ dur: 0.22, vol: 0.07, f: 700, to: 200 });
    this.tone({ f: 660, to: 330, dur: 0.25, type: 'triangle', vol: 0.05, delay: 0.04, rev: 0.4 });
  }
  warn() { if (!this.gate('warn', 800)) return; this.tone({ f: 880, dur: 0.1, type: 'square', vol: 0.045, lp: 2500 }); this.tone({ f: 660, dur: 0.12, type: 'square', vol: 0.045, lp: 2500, delay: 0.14 }); this.tone({ f: 880, dur: 0.1, type: 'square', vol: 0.045, lp: 2500, delay: 0.3 }); }
  wave() {
    const horn = (f: number, d: number, delay: number) => {
      this.tone({ f, dur: d, type: 'sawtooth', vol: 0.06, lp: 1500, lpTo: 800, attack: 0.05, sus: 0.5, delay, rev: 0.35 });
      this.tone({ f: f * 1.5, dur: d, type: 'sawtooth', vol: 0.03, lp: 1300, attack: 0.06, sus: 0.5, delay, rev: 0.35, det: 6 });
    };
    horn(294, 0.24, 0); horn(392, 0.46, 0.22);
    this.tone({ f: 80, to: 45, dur: 0.32, type: 'sine', vol: 0.16 }); this.noise({ dur: 0.2, vol: 0.05, f: 400, to: 120 });
  }
  waveClear() { [660, 880, 1100].forEach((f, i) => this.tone({ f, dur: 0.22, type: 'triangle', vol: 0.08, delay: i * 0.08, rev: 0.35 })); this.tone({ f: 1760, dur: 0.6, type: 'sine', vol: 0.03, delay: 0.25, rev: 0.6 }); }
  levelUp() {
    [523, 659, 784, 1047, 784, 1047, 1319].forEach((f, i) => this.tone({ f, dur: 0.26, type: 'square', vol: 0.05, lp: 3200, delay: i * 0.1, rev: 0.3 }));
    [523, 659, 784, 1047].forEach(f => this.tone({ f, dur: 1.4, type: 'triangle', vol: 0.05, attack: 0.05, sus: 0.4, delay: 0.7, rev: 0.5 }));
    [2093, 2637, 3136].forEach((f, i) => this.tone({ f, dur: 0.9, type: 'sine', vol: 0.025, delay: 0.75 + i * 0.07, rev: 0.7 }));
    this.noise({ dur: 0.5, vol: 0.05, f: 6000, type: 'highpass', delay: 0.7 });
  }
  gameOver() {
    [392, 370, 330, 262].forEach((f, i) => this.tone({ f, dur: 0.5, type: 'triangle', vol: 0.08, delay: i * 0.24, rev: 0.45 }));
    this.tone({ f: 98, to: 65, dur: 1.6, type: 'sawtooth', vol: 0.07, lp: 400, attack: 0.1, sus: 0.4, delay: 0.2, rev: 0.4 });
  }

  // ================= MUSIC (a small adaptive loop) =================
  setMusic(mode: MusicMode) {
    if (mode === this.mode) return;
    this.mode = mode; this.step = 0;
    if (mode !== 'off') this.syncMusic();
    else if (this.timer !== null) { window.clearInterval(this.timer); this.timer = null; }
  }
  private syncMusic() {
    const c = this.ctx; if (!c || !this.musicBus) return;
    if (this.mode !== 'off' && this.timer === null) { this.nextT = c.currentTime + 0.08; this.timer = window.setInterval(() => this.pump(), 25); }
    if (this.mode === 'off' && this.timer !== null) { window.clearInterval(this.timer); this.timer = null; }
  }
  private pump() {
    const c = this.ctx; if (!c || this.mode === 'off') return;
    const eighth = 60 / BPM[this.mode] / 2;
    if (this.nextT < c.currentTime - 0.05) this.nextT = c.currentTime + 0.04;
    while (this.nextT < c.currentTime + 0.14) { this.playStep(this.nextT, eighth); this.nextT += eighth; this.step = (this.step + 1) % 32; }
  }
  /** menu / calm = soft chords + pluck; battle = driving bass + drums; win = bright; lose = slow */
  private playStep(t: number, e: number) {
    const s = this.step & 7, bar = (this.step >> 3) & 3; const m = this.mode;
    const root = 48 + [0, -3, -5, -7][bar]; const tri = bar === 1 ? [0, 3, 7] : bar === 3 ? [0, 4, 7] : [0, 4, 7];
    const bass = (f: number, d: number, v: number) => this.tone({ f, dur: d, type: 'triangle', vol: v, at: t, music: true, lp: 700, attack: 0.012 });
    const pluck = (f: number, v: number, pan = 0) => this.tone({ f, dur: e * 1.6, type: 'sawtooth', vol: v, at: t, music: true, lp: 3200, lpTo: 600, q: 1.2, attack: 0.004, pan, rev: 0.2 });
    const pad = (f: number, d: number, v: number, pan: number) => this.tone({ f, dur: d, type: 'sawtooth', vol: v, at: t, music: true, lp: 900, attack: 0.35, sus: 0.6, det: pan > 0 ? 7 : -7, pan, rev: 0.5 });
    const kick = (v: number) => { this.tone({ f: 150, to: 40, dur: 0.22, type: 'sine', vol: v, at: t, music: true, attack: 0.002 }); this.noise({ dur: 0.02, vol: v * 0.25, f: 3000, type: 'highpass', at: t, music: true }); };
    const snare = (v: number) => { this.noise({ dur: 0.16, vol: v, f: 1900, to: 1200, q: 0.8, type: 'bandpass', at: t, music: true }); this.tone({ f: 200, to: 120, dur: 0.1, type: 'triangle', vol: v * 0.7, at: t, music: true }); };
    const hat = (v: number) => this.noise({ dur: 0.045, vol: v, f: 7500, type: 'highpass', at: t, music: true });
    const wood = () => this.tone({ f: 980, to: 880, dur: 0.06, type: 'sine', vol: 0.03, at: t, music: true });

    if (m === 'menu' || m === 'calm') {
      const soft = m === 'menu' ? 0.85 : 1;
      if (s === 0) { for (const i of tri) pad(root + i, e * 7.6, 0.05 * soft, i > 0 ? 0.3 : -0.3); bass(root - 12, e * 3, 0.13 * soft); }
      if (s === 4) bass(root - 5, e * 2.2, 0.09 * soft);
      const note = [0, -1, 2, -1, 4, -1, 2, 0, 0, -1, 2, -1, 4, -1, -1, -1, 4, -1, 2, -1, 0, -1, 2, -1, 4, -1, 7, -1, 4, -1, -1, -1][this.step];
      if (note >= 0) pluck(root + 12 + PENT[note % 5] + 12 * Math.floor(note / 5), 0.07 * soft, (s % 5) * 0.08 - 0.2);
      if (s === 2 || s === 6) wood();
    } else if (m === 'battle') {
      bass(root - 12 + (s === 3 ? 12 : s === 6 ? 7 : 0), e * 0.9, 0.15);
      if (s === 2 || s === 5) for (const i of tri) pluck(root + 12 + i, 0.05, (i - 4) * 0.05);
      pluck(root + 24 + tri[s % 3], 0.028, (s - 4) * 0.1);
      if (s === 0 || s === 4 || (s === 3 && bar % 2 === 1)) kick(0.2);
      if (s === 2 || s === 6) snare(0.12);
      hat(s === 7 ? 0.028 : 0.018);
    } else if (m === 'win') {
      if (s === 0 || s === 4) kick(0.12);
      if (s === 0) { for (const i of tri) pad(root + i, e * 7.6, 0.045, i > 0 ? 0.3 : -0.3); bass(root - 12, e * 3, 0.12); }
      const note = [4, -1, 5, -1, 7, -1, 5, 4, 2, -1, 4, -1, 5, -1, -1, -1, 4, -1, 5, -1, 7, -1, 8, 7, 5, -1, 4, -1, 2, -1, -1, -1][this.step];
      if (note >= 0) pluck(root + 12 + PENT[note % 5], 0.06, 0.1);
    } else if (m === 'lose') {
      if (s === 0 && bar % 2 === 0) for (const i of [0, 3, 7]) pad(root - 12 + i, e * 15, 0.06, i > 0 ? 0.3 : -0.3);
      if (s === 4 && bar % 2 === 0) pluck(root + 12 + (bar === 0 ? 7 : 3), 0.045, 0.1);
    }
  }

  // ================= AMBIENCE =================
  private startWind() {
    const c = this.ctx!; if (!this.noiseBuf) return;
    const src = c.createBufferSource(); src.buffer = this.noiseBuf; src.loop = true;
    const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 450; bp.Q.value = 0.6;
    const lfo = c.createOscillator(); lfo.frequency.value = 0.07; const lg = c.createGain(); lg.gain.value = 220;
    lfo.connect(lg); lg.connect(bp.frequency);
    const g = c.createGain(); g.gain.value = 0.035;
    const lfo2 = c.createOscillator(); lfo2.frequency.value = 0.13; const lg2 = c.createGain(); lg2.gain.value = 0.015;
    lfo2.connect(lg2); lg2.connect(g.gain);
    src.connect(bp); bp.connect(g); g.connect(this.master); src.start(); lfo.start(); lfo2.start();
    this.windGain = g;
    const loop = () => { this.bird(); this.windTimer = window.setTimeout(loop, 3000 + Math.random() * 5000); };
    this.windTimer = window.setTimeout(loop, 2600);
  }
  private bird() {
    if (!this.ctx || this._muted || document.hidden) return;
    const base = 2200 + Math.random() * 400, n = 2 + Math.floor(Math.random() * 3), pan = rnd(-0.8, 0.8);
    for (let i = 0; i < n; i++) { const f = base + rnd(-250, 350); this.tone({ f, to: f * rnd(1.15, 1.45), dur: 0.07, type: 'sine', vol: 0.022, delay: i * 0.1, pan, rev: 0.35, prio: 0 }); }
  }
}
