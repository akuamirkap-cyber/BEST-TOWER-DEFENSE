import * as THREE from 'three';
import { BOX, SPH, OUTLINE_MAT, makeFace, makeFlame, makeBlast } from './voxel';

/**
 * ACTORS – the whole cast of the game, deliberately tiny: ONE orc and ONE tower.
 * Both are chubby, rounded characters with big glossy blinking eyes (the same face system as before),
 * thick dark outlines on the rounded parts, and small cube details. Everything is shared-geometry cached,
 * so a crowd of orcs costs very little.
 */
export const Y = new THREE.Vector3(0, 1, 0);

// ---------- shared materials / geometry (cached: a crowd of orcs shares them all) ----------
const MATS = new Map<string, THREE.MeshStandardMaterial>();
export function M(color: number, glow = 0.08, rough = 0.55) {
  const k = color + '|' + glow + '|' + rough;
  let m = MATS.get(k);
  if (!m) { m = new THREE.MeshStandardMaterial({ color, roughness: rough, emissive: color, emissiveIntensity: glow }); MATS.set(k, m); }
  return m;
}
/** per-enemy material: it is tinted on hit / poison, so it must not be shared */
export const newSkin = (color: number) => new THREE.MeshStandardMaterial({ color, roughness: 0.55, emissive: color, emissiveIntensity: 0.08 });

const GEO = new Map<string, THREE.BufferGeometry>();
function G<T extends THREE.BufferGeometry>(key: string, make: () => T): T {
  let g = GEO.get(key); if (!g) { g = make(); GEO.set(key, g); } return g as T;
}
const OL = 0.022; // outline thickness
function hull(m: THREE.Mesh, kr: number, kh: number) { const o = new THREE.Mesh(m.geometry, OUTLINE_MAT); o.scale.set(kr, kh, kr); m.add(o); }

interface O { sx?: number; sy?: number; sz?: number; rx?: number; ry?: number; rz?: number; ol?: boolean; cast?: boolean; seg?: number }
function fin<T extends THREE.Mesh>(m: T, x: number, y: number, z: number, o: O): T {
  m.position.set(x, y, z); m.rotation.set(o.rx ?? 0, o.ry ?? 0, o.rz ?? 0); m.castShadow = !!o.cast; return m;
}
/** sphere, optional outline */
export function S(r: number, mat: THREE.Material, x = 0, y = 0, z = 0, o: O = {}) {
  const m = new THREE.Mesh(SPH, mat); const sx = o.sx ?? 1, sy = o.sy ?? 1, sz = o.sz ?? 1;
  m.scale.set(r * sx, r * sy, r * sz); fin(m, x, y, z, o);
  if (o.ol) { const k = 1 + OL / ((r * (sx + sy + sz)) / 3); hull(m, k, k); }
  return m;
}
/** cylinder (capsule-ish body parts), optional outline */
export function C(rt: number, rb: number, h: number, mat: THREE.Material, x = 0, y = 0, z = 0, seg = 12, ol = true) {
  const m = new THREE.Mesh(G(`cyl${rt}|${rb}|${h}|${seg}`, () => new THREE.CylinderGeometry(rt, rb, h, seg)), mat);
  fin(m, x, y, z, {}); m.castShadow = true;
  if (ol) hull(m, 1 + OL / Math.max(rt, rb), 1 + (OL * 2) / h);
  return m;
}
/** capsule with rounded ends: the arms, legs and fingers */
export function cap(r: number, len: number, mat: THREE.Material, x = 0, y = 0, z = 0, o: O = {}) {
  const m = new THREE.Mesh(G(`cap${r}|${len}`, () => new THREE.CapsuleGeometry(r, len, 4, 10)), mat);
  fin(m, x, y, z, o); sc(m, o); m.castShadow = !!o.cast;
  if (o.ol) hull(m, 1 + OL / r, 1 + (OL * 2) / (len + 2 * r));
  return m;
}
/** cone whose BASE is at the origin and whose tip points up (+y) */
export function cone(r: number, h: number, mat: THREE.Material, x = 0, y = 0, z = 0, o: O = {}) {
  const m = new THREE.Mesh(G(`cone${r}|${h}`, () => new THREE.ConeGeometry(r, h, 10).translate(0, h / 2, 0)), mat);
  fin(m, x, y, z, o); sc(m, o); m.castShadow = !!o.cast;
  if (o.ol) hull(m, 1 + OL / r, 1 + OL / h);
  return m;
}
export function tor(R: number, t: number, mat: THREE.Material, x = 0, y = 0, z = 0, o: O = {}) {
  const m = new THREE.Mesh(G(`tor${R}|${t}`, () => new THREE.TorusGeometry(R, t, 8, 22)), mat);
  fin(m, x, y, z, o); sc(m, o); return m;
}
/** small cube details: belts, buckles, runes, tufts */
export function B(w: number, h: number, d: number, mat: THREE.Material, x = 0, y = 0, z = 0, o: O = {}) {
  const m = new THREE.Mesh(BOX, mat); m.scale.set(w, h, d); fin(m, x, y, z, o);
  if (o.ol) { const k = 1 + OL / ((w + h + d) / 3); hull(m, k, k); }
  return m;
}
function sc(m: THREE.Mesh, o: O) { if (o.sx !== undefined || o.sy !== undefined || o.sz !== undefined) m.scale.set(o.sx ?? 1, o.sy ?? 1, o.sz ?? 1); }

// ================= ORC =================
export interface Actor {
  group: THREE.Group; parts: THREE.Group[]; limbs: Record<string, THREE.Group>;
  face: THREE.Object3D; skin: THREE.MeshStandardMaterial;
}

/**
 * ONE orc type: a chubby green orc with a big head, floppy ears, tiny tusks and a wooden club.
 * Every limb is its own top-level group so the body can fall apart when it dies (face stays on the head).
 */
export function buildOrc(skinColor: number): Actor {
  const skin = newSkin(skinColor);
  const cloth = M(0xd9433b, 0.1), belt = M(0x5b3a1e), gold = M(0xfbbf24, 0.28, 0.32), boot = M(0x4a3222);
  const dark = M(0x35692c, 0.06, 0.7), wood = M(0x8a5a2b);
  const group = new THREE.Group();

  // legs: chubby capsule legs with round little boots
  const mkLeg = (sd: number) => {
    const l = new THREE.Group(); l.position.set(sd * 0.15, 0.32, 0);
    l.add(cap(0.085, 0.1, skin, 0, -0.16, 0, { cast: true, ol: true }));
    l.add(S(0.135, boot, 0, -0.3, 0.06, { sx: 1, sy: 0.62, sz: 1.28, ol: true }));   // round, not slab-like
    l.add(S(0.05, M(0x6b4c2c), 0, -0.36, 0.16, { ol: false }));                     // sole highlight
    return l;
  };
  const legL = mkLeg(-1), legR = mkLeg(1);

  // body: a proper pear – a wide lower belly under a round chest, with a light belly patch and a belt
  const body = new THREE.Group(); body.position.y = 0.55;
  body.add(S(0.31, skin, 0, 0, 0, { sy: 0.95, sz: 0.9, cast: true, ol: true }));
  body.add(S(0.245, skin, 0, -0.12, 0, { sy: 0.85, sz: 0.88, cast: true, ol: true }));  // wider lower half
  body.add(S(0.21, M(0x9ee27a), 0, -0.05, 0.2, { sy: 1.15, sz: 0.46 }));                // soft belly
  body.add(C(0.26, 0.35, 0.21, cloth, 0, -0.21, 0, 12, true));
  body.add(tor(0.275, 0.032, belt, 0, -0.11, 0, { rx: Math.PI / 2 }));
  body.add(B(0.1, 0.09, 0.045, gold, 0, -0.11, 0.285, { ol: true }));

  // arms: capsules with round mitten hands
  const mkArm = (sd: number) => {
    const a = new THREE.Group(); a.position.set(sd * 0.29, 0.68, 0);
    a.add(cap(0.085, 0.11, skin, 0, -0.14, 0, { cast: true, ol: true }));
    a.add(S(0.115, skin, 0, -0.31, 0.01, { ol: true }));
    return a;
  };
  const armL = mkArm(-1), armR = mkArm(1);

  // head: big rounded skull, floppy ears, glossy tower-style eyes, nose, tusks and one cute curl
  const head = new THREE.Group(); head.position.y = 1.0;
  head.add(S(0.43, skin, 0, 0, 0, { sx: 1.12, sy: 0.97, sz: 1.03, cast: true, ol: true }));
  const inner = M(0x8fd96a);
  const mkEar = (sd: number) => {
    const p = new THREE.Group(); p.position.set(sd * 0.44, 0.08, -0.03); p.rotation.z = -sd * 1.07;
    p.add(cone(0.13, 0.36, skin, 0, 0, 0, { sz: 0.42, ol: true }));
    p.add(cone(0.075, 0.27, inner, 0, 0.02, 0.03, { sz: 0.4 }));
    head.add(p); return p;
  };
  const earL = mkEar(-1), earR = mkEar(1);
  const face = makeFace({ r: 0.13, gap: 0.175, iris: 0x7c4a1e, skin: skinColor, mouth: 'grin', cheeks: true, brows: 0x35692c, body: { R: 0.43, cy: 0, sy: 0.96, y0: 0.02 } });
  head.add(face);
  head.add(S(0.045, dark, 0, -0.1, 0.425, { sx: 1.3, sy: 0.9, sz: 0.9 }));
  for (const sd of [-1, 1]) head.add(cone(0.045, 0.13, M(0xfff7e0), sd * 0.13, -0.215, 0.335, { rz: -sd * 0.12 }));
  // one cute hair tuft: three tapering curls that lean into each other, with a soft highlight strand
  const hair = M(0x3b2f2f);
  for (const [x, h, rz] of [[-0.11, 0.2, -0.42], [0, 0.3, -0.05], [0.11, 0.2, 0.42]] as [number, number, number][]) {
    head.add(cone(0.052, h, hair, x, 0.36, 0.02, { rz }));
    head.add(cone(0.024, h * 0.6, M(0x5b4636), x * 0.72, 0.36, 0.06, { rz: rz * 1.1 }));
  }

  // club: knobbly stick with spikes (thrown away on its own when the orc dies)
  const club = new THREE.Group(); club.position.set(0, -0.28, 0.04); club.rotation.x = 1.15;
  club.add(cap(0.05, 0.3, wood, 0, 0.18, 0, { ol: true, cast: true }));
  club.add(S(0.16, M(0x6b4428), 0, 0.48, 0, { ol: true, cast: true }));
  club.add(tor(0.055, 0.016, M(0xc9a66b, 0.1, 0.8), 0, 0.1, 0, { rx: Math.PI / 2 }));
  club.add(tor(0.055, 0.016, M(0xc9a66b, 0.1, 0.8), 0, 0.2, 0, { rx: Math.PI / 2 }));      // rope wrap
  for (let i = 0; i < 4; i++) { const a = (i / 4) * Math.PI * 2 + 0.4; const sp = cone(0.035, 0.1, M(0xd9d9d9), Math.cos(a) * 0.14, 0.48, Math.sin(a) * 0.14); sp.quaternion.setFromUnitVectors(Y, new THREE.Vector3(Math.cos(a), 0.35, Math.sin(a)).normalize()); club.add(sp); }
  const leaf = S(0.075, M(0x4ade80), 0.12, 0.62, 0.05, { sx: 1.5, sy: 0.5, sz: 0.8, ol: true }); leaf.rotation.z = -0.6; club.add(leaf);
  armR.add(club);
  // *** the whole body MUST be parented to the root group ***
  // without this line the group is EMPTY, so the orc is invisible in the world (while the game logic still
  // targets it), and on death its limbs fly out from the world origin instead of where the orc stood.
  group.add(legL, legR, body, armL, armR, head);

  return {
    group,
    parts: [legL, legR, body, armL, armR, head, club],
    limbs: { legL, legR, body, armL, armR, head, earL, earR, club },
    face, skin,
  };
}

/**
 * The orc walk cycle: waddling steps, swinging arms, bobbing head, flapping ears.
 * Every limb is touched defensively – a missing limb must never throw, or one broken orc would freeze the whole
 * update loop and every other enemy would sit frozen at the origin (looking invisible while towers still aim at it).
 */
export function poseOrc(L: Record<string, THREE.Group>, ph: number, time: number, moving = true) {
  const rot = (k: string, x: number, y = 0, z = 0) => { const o = L[k]; if (o) o.rotation.set(x, y, z); };
  const sw = moving ? Math.sin(ph) * 0.7 : Math.sin(time * 1.3) * 0.05;
  rot('legL', sw); rot('legR', -sw);
  rot('armL', -sw * 0.8, 0, -0.12); rot('armR', moving ? -0.6 + Math.sin(ph * 0.5) * 0.25 : -0.35, 0, 0.12);
  if (L.head) {
    L.head.rotation.z = Math.sin(ph * 0.5) * 0.08;
    L.head.rotation.x = Math.sin(ph * 2) * 0.05;
    L.head.position.y = (L.head.userData.y0 as number | undefined) ?? L.head.position.y;
    if (L.head.userData.y0 === undefined) L.head.userData.y0 = L.head.position.y;
    L.head.position.y = (L.head.userData.y0 as number) + Math.sin(time * 2.3) * 0.012;
  }
  if (L.body) { L.body.rotation.z = Math.sin(ph) * 0.05; L.body.scale.y = 1 + Math.sin(time * 2.3) * 0.025; }
  const flap = Math.sin(time * 2.6 + ph) * 0.12;
  if (L.earL) L.earL.rotation.z = 1.07 + flap;
  if (L.earR) L.earR.rotation.z = -1.07 - Math.sin(time * 2.6 + ph + 1) * 0.12;
}

// ================= TOWER (the cannon "Bolo") =================
export interface TowerModel { group: THREE.Group; head: THREE.Group; face: THREE.Object3D; muzzle: THREE.Object3D; flame: THREE.Object3D }

/**
 * ONE tower type: "Bolo", a chubby cannon buddy standing on a stone podium.
 * Cute glossy eyes that look around and blink, a lit fuse on its cap, and a star muzzle flash on the barrel tip.
 * The three orbiting crystal shards show the tower level (1-3).
 */
export function buildTower(level: number): TowerModel {
  const group = new THREE.Group();
  const stone = M(0x98a3b5, 0.1, 0.75), accent = M(0x2b5fd9, 0.35), blue = M(0x4f8cff), blueDark = M(0x2b5fd9), gold = M(0xfbbf24, 0.3, 0.3);
  const dark = M(0x1f2937, 0.05);

  // stone podium with glowing runes
  group.add(C(0.5, 0.55, 0.22, stone, 0, 0.11, 0, 12, true));
  group.add(C(0.43, 0.47, 0.1, accent, 0, 0.26, 0, 12, true));
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + 0.26;
    const rune = B(0.07, 0.06, 0.05, M(0x4f8cff, 1), Math.cos(a) * 0.53, 0.15, Math.sin(a) * 0.53);
    rune.rotation.y = -a + Math.PI / 2; group.add(rune);
  }
  // level shards orbiting the podium
  const shards = new THREE.Group(); shards.name = 'shards'; shards.position.y = 0.52; group.add(shards);
  for (let i = 0; i < level; i++) {
    const a = (i * Math.PI * 2) / level; const sh = new THREE.Mesh(new THREE.OctahedronGeometry(0.075), M(0x4f8cff, 0.9, 0.3));
    sh.scale.y = 1.5; sh.position.set(Math.cos(a) * 0.6, 0, Math.sin(a) * 0.6); shards.add(sh);
  }

  // the cannon buddy
  const head = new THREE.Group(); head.position.y = 0.3; group.add(head);
  head.add(S(0.38, blue, 0, 0.35, 0, { cast: true, ol: true }));
  head.add(S(0.22, M(0x9ec5ff), 0, 0.16, 0.26, { sy: 0.8, sz: 0.5, ol: false }));
  // sailor cap with a lit fuse
  head.add(S(0.33, blueDark, 0, 0.6, -0.02, { sy: 0.55, ol: true }));
  head.add(S(0.055, gold, 0, 0.75, -0.02, { ol: true }));
  head.add(C(0.014, 0.014, 0.16, M(0x9ca3af, 0.1), 0, 0.83, -0.02, 6, false));
  const flame = makeFlame(0.09); flame.position.set(0, 0.9, -0.02); head.add(flame);
  // barrel + muzzle ring + bore
  head.add(C(0.1, 0.13, 0.52, dark, 0, 0.26, 0.42, 12, true).rotateX(Math.PI / 2));
  head.add(C(0.155, 0.155, 0.07, gold, 0, 0.26, 0.7, 12, true).rotateX(Math.PI / 2));
  head.add(C(0.08, 0.08, 0.02, M(0x0b0b12, 0.02), 0, 0.26, 0.74, 12, false).rotateX(Math.PI / 2));
  // little side knobs (shoulders) + star muzzle flash
  for (const sd of [-1, 1]) head.add(C(0.085, 0.085, 0.12, gold, sd * 0.4, 0.42, 0, 10, true).rotateZ(Math.PI / 2));
  const muzzle = makeBlast(0.5); muzzle.position.set(0, 0.26, 0.86); head.add(muzzle);
  // cute face on the upper front
  const face = makeFace({ r: 0.13, gap: 0.16, iris: 0x1d4ed8, skin: 0x4f8cff, mouth: 'none', cheeks: true, body: { R: 0.38, cy: 0.35, sy: 1, y0: 0.42 } });
  head.add(face);

  return { group, head, face, muzzle, flame };
}
