import * as THREE from 'three';
import { Sfx } from './sfx';
import { BOX, SPH, RING, DISC, OUTLINE_MAT, makeFlame, flickerFlame, updateFace } from './voxel';
import { poseOrc } from './actors';
import { buildOrcKind, buildTowerKind, ORC_DATA, TOWER_DATA } from './newcomers';
import type { OrcKind, TowerKind } from './newcomers';
import { buildWorld, makeSkyTexture, BIOMES, weatherOf } from './world';
import type { World } from './world';

/**
 * Voxel Defense – FIVE orcs, FIVE towers.
 * The orcs march in from the LEFT along a winding road to the crystal castle. You place towers on the grass,
 * upgrade them to level 3 and try to survive the waves. Each tower does something different:
 *   🔵 Meriam  splash shells   · 🕳️ Gravitasi  sucks every orc in   · 🌪️ Pusaran  lifts a group into the air
 *   🌠 Meteor  sky bombardment · 💰 Alkimia  turns weak orcs into gold
 */
const W = 24, H = 14, MAX_LIVES = 10, START_GOLD = 400;
const BLOOD = 0xc0262d;
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

/** where each tower's "muzzle" sits in its own head space (y = height, f = forward) */
const MUZZLE: Record<TowerKind, { y: number; f: number }> = {
  cannon: { y: 0.26, f: 0.86 }, gravity: { y: 0.92, f: 0 }, tornado: { y: 0.72, f: 0.12 }, meteor: { y: 1.0, f: 0.2 }, midas: { y: 0.45, f: 0.9 },
  draco: { y: 0.83, f: 0.72 }, sol: { y: 0.95, f: 0 }, chroma: { y: 1.02, f: 0 }, frostbite: { y: 1.5, f: 0 },
};

// five road layouts; every one starts at the left edge, so the orcs always come from the left
const LAYOUTS: [number, number][][] = [
  [[0, 7], [5, 7], [5, 2], [11, 2], [11, 11], [17, 11], [17, 6], [23, 6]],
  [[0, 3], [4, 3], [4, 10], [9, 10], [9, 5], [15, 5], [15, 12], [19, 12], [19, 7], [23, 7]],
  [[0, 11], [3, 11], [3, 3], [8, 3], [8, 8], [12, 8], [12, 1], [18, 1], [18, 9], [23, 9]],
  [[0, 6], [6, 6], [6, 12], [2, 12], [2, 2], [10, 2], [10, 9], [16, 9], [16, 4], [20, 4], [20, 10], [23, 10]],
  [[0, 2], [4, 2], [4, 8], [1, 8], [1, 12], [9, 12], [9, 6], [14, 6], [14, 1], [20, 1], [20, 11], [23, 11]],
];

export interface FloatText { id: number; x: number; y: number; text: string; color: string }
export interface SelectedInfo { id: number; kind: TowerKind; level: number; upgradeCost: number | null; sellValue: number; dmg: number; range: string; rate: string; splash: number }
export interface GameState {
  screen: 'menu' | 'playing' | 'levelComplete' | 'gameOver';
  level: number; wave: number; wavesPerLevel: number; lives: number; maxLives: number;
  gold: number; score: number; best: number; kills: number;
  selected: SelectedInfo | null; selectedType: TowerKind;
  waveActive: boolean; countdown: number; enemiesLeft: number;
  muted: boolean; speed: number; nextWave: string;
}

// ================= particles =================
class Particles {
  mesh: THREE.InstancedMesh; n = 700;
  pos: Float32Array; vel: Float32Array; life: Float32Array; maxLife: Float32Array;
  size: Float32Array; alive: Uint8Array; grav: Float32Array; smoke: Uint8Array;
  dummy = new THREE.Object3D(); cursor = 0;
  constructor(scene: THREE.Scene) {
    this.mesh = new THREE.InstancedMesh(BOX, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6 }), this.n);
    this.mesh.frustumCulled = false; this.mesh.castShadow = true;
    this.pos = new Float32Array(this.n * 3); this.vel = new Float32Array(this.n * 3); this.grav = new Float32Array(this.n);
    this.life = new Float32Array(this.n); this.maxLife = new Float32Array(this.n); this.size = new Float32Array(this.n);
    this.alive = new Uint8Array(this.n); this.smoke = new Uint8Array(this.n);
    for (let i = 0; i < this.n; i++) { this.dummy.scale.setScalar(0); this.dummy.updateMatrix(); this.mesh.setMatrixAt(i, this.dummy.matrix); this.mesh.setColorAt(i, new THREE.Color(1, 1, 1)); }
    scene.add(this.mesh);
  }
  emit(p: THREE.Vector3, color: number, count: number, speed: number, size: number, life: number, up = 2, grav = 9) {
    const col = new THREE.Color(color);
    const cr = (color >> 16) & 255, cg = (color >> 8) & 255, cb = color & 255;
    const smoky = Math.max(cr, cg, cb) < 0xb4 && Math.max(cr, cg, cb) - Math.min(cr, cg, cb) < 0x24;
    const SMOKE = [0xf4f6fa, 0xe6e9f0, 0xd9dde7];
    for (let k = 0; k < count; k++) {
      const i = this.cursor; this.cursor = (this.cursor + 1) % this.n;
      this.alive[i] = 1; this.grav[i] = grav;
      this.pos[i * 3] = p.x; this.pos[i * 3 + 1] = p.y; this.pos[i * 3 + 2] = p.z;
      const a = Math.random() * Math.PI * 2, sp = speed * (0.4 + Math.random() * 0.8);
      this.vel[i * 3] = Math.cos(a) * sp; this.vel[i * 3 + 1] = up * (0.5 + Math.random()); this.vel[i * 3 + 2] = Math.sin(a) * sp;
      this.life[i] = this.maxLife[i] = life * (0.6 + Math.random() * 0.6); this.size[i] = size * (0.6 + Math.random() * 0.8);
      if (smoky) {
        this.smoke[i] = 1; this.grav[i] = -(0.5 + Math.random() * 0.6); this.size[i] *= 1.7;
        this.life[i] = this.maxLife[i] = this.life[i] * 1.5; this.vel[i * 3 + 1] = 0.3 + Math.random() * 0.9;
        this.mesh.setColorAt(i, new THREE.Color(SMOKE[(Math.random() * SMOKE.length) | 0]));
      } else { this.smoke[i] = 0; this.mesh.setColorAt(i, col.clone().offsetHSL(0, 0, (Math.random() - 0.5) * 0.15)); }
    }
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }
  update(dt: number) {
    for (let i = 0; i < this.n; i++) {
      if (!this.alive[i]) continue;
      this.life[i] -= dt;
      if (this.life[i] <= 0) { this.alive[i] = 0; this.dummy.scale.setScalar(0); this.dummy.updateMatrix(); this.mesh.setMatrixAt(i, this.dummy.matrix); continue; }
      this.vel[i * 3 + 1] -= this.grav[i] * dt;
      for (let k = 0; k < 3; k++) this.pos[i * 3 + k] += this.vel[i * 3 + k] * dt;
      if (this.pos[i * 3 + 1] < 0.05 && this.grav[i] > 0) { this.pos[i * 3 + 1] = 0.05; this.vel[i * 3 + 1] *= -0.4; this.vel[i * 3] *= 0.7; this.vel[i * 3 + 2] *= 0.7; }
      const t = this.life[i] / this.maxLife[i];
      this.dummy.position.set(this.pos[i * 3], this.pos[i * 3 + 1], this.pos[i * 3 + 2]);
      this.dummy.rotation.set(this.life[i] * 5, this.life[i] * 3, 0);
      if (this.smoke[i]) {
        const dr = Math.max(0, 1 - 1.5 * dt); this.vel[i * 3] *= dr; this.vel[i * 3 + 2] *= dr;
        this.dummy.scale.setScalar(this.size[i] * (0.45 + 1.1 * (1 - t)) * Math.min(1, t * 2.6));
      } else this.dummy.scale.setScalar(this.size[i] * Math.min(1, t * 2));
      this.dummy.updateMatrix(); this.mesh.setMatrixAt(i, this.dummy.matrix);
    }
    this.mesh.instanceMatrix.needsUpdate = true;
  }
}

// ================= the ragdoll-ish death =================
/** a piece of a dead orc: it keeps its EXACT pose at death and tumbles around its own centre */
interface Piece { obj: THREE.Object3D; lc: THREE.Vector3; v: THREE.Vector3; w: THREE.Vector3; life: number; r: number }
class Scatter {
  pieces: Piece[] = [];
  constructor(private scene: THREE.Scene, private onHit: (p: THREE.Vector3, force: number) => void) {}
  /**
   * Every part becomes its own rigid body. The part is moved into the SCENE with `attach` (which keeps its exact world
   * pose, so it can never end up somewhere else), and the tumble is applied by hand around the part's own centre.
   */
  burst(root: THREE.Object3D, parts: THREE.Object3D[], center: THREE.Vector3, away: THREE.Vector3, power: number, travel: THREE.Vector3) {
    root.updateMatrixWorld(true); this.scene.updateMatrixWorld(true);
    for (const part of parts) {
      const box = new THREE.Box3().setFromObject(part);
      const wc = box.isEmpty() ? part.getWorldPosition(new THREE.Vector3()) : box.getCenter(new THREE.Vector3());
      const size = box.isEmpty() ? new THREE.Vector3(0.3, 0.3, 0.3) : box.getSize(new THREE.Vector3());
      const r = clamp(0.5 * ((size.x + size.y + size.z) / 3) * 0.9, 0.06, 0.5);
      // 1) keep the exact world pose (never teleports), 2) remember the centre in local space so the tumble pivots there
      const lc = part.worldToLocal(wc.clone()); // local centre, computed BEFORE the re-parent (matrixWorld is fresh now)
      this.scene.attach(part);
      const off = wc.clone().sub(center); const radial = new THREE.Vector3(off.x, 0, off.z);
      if (radial.lengthSq() < 1e-4) radial.set(Math.random() - 0.5, 0, Math.random() - 0.5);
      radial.normalize();
      const pw = power * (0.75 + Math.random() * 0.5);
      const v = away.clone().multiplyScalar(pw).addScaledVector(radial, 0.8 + Math.random() * 1.1).add(travel);
      v.y = 3.2 + Math.random() * 2.6 + Math.max(0, off.y) * 1.3;
      const w = off.clone().cross(away).multiplyScalar((pw * 2.6) / (0.4 + off.lengthSq() * 0.6));
      w.x += (Math.random() - 0.5) * 7; w.y += (Math.random() - 0.5) * 7; w.z += (Math.random() - 0.5) * 7; w.clampLength(0, 15);
      this.pieces.push({ obj: part, lc, v, w, life: 2.6 + Math.random() * 1.2, r });
    }
    const extra = this.pieces.length - 120;
    for (let i = 0; i < extra; i++) this.pieces[i].life = Math.min(this.pieces[i].life, 0.5);
  }
  update(dt: number) {
    for (let i = this.pieces.length - 1; i >= 0; i--) {
      const p = this.pieces[i]; p.life -= dt; const o = p.obj;
      p.v.y -= 11 * dt; o.position.addScaledVector(p.v, dt);
      const wl = p.w.length();
      if (wl > 1e-3) {
        // tumble around the piece's own centre of mass (never around a corner), so limbs spin the way they should
        const q = new THREE.Quaternion().setFromAxisAngle(p.w.clone().normalize(), wl * dt);
        const c = p.lc.clone().multiply(o.scale).applyQuaternion(o.quaternion).add(o.position);
        o.quaternion.premultiply(q);
        o.position.sub(c).applyQuaternion(q).add(c);
      }
      if (o.position.y - p.r < 0.06) {
        o.position.y = 0.06 + p.r;
        if (p.v.y < 0) {
          const force = -p.v.y;
          if (force > 2.4) this.onHit(o.position, force);
          p.v.y = force > 1.3 ? force * 0.34 : 0;
        }
        const f = Math.pow(0.8, dt * 60); p.v.x *= f; p.v.z *= f;
        const k = 1 - Math.pow(0.6, dt * 60);
        p.w.x += (p.v.z / p.r - p.w.x) * k; p.w.z += (-p.v.x / p.r - p.w.z) * k; p.w.y *= Math.pow(0.88, dt * 60);
      }
      if (p.life < 0.8) {
        const s = Math.max(0, o.scale.x - dt * 1.5); o.scale.setScalar(s);
        if (s < 0.06) { this.scene.remove(o); this.pieces.splice(i, 1); continue; }
      }
      if (p.life <= -0.5) { this.scene.remove(o); this.pieces.splice(i, 1); }
    }
  }
  /** toss a single loose piece (an ice shard) – it tumbles, lands, then fades */
  toss(obj: THREE.Object3D, vel: THREE.Vector3, life = 1.6, r = 0.1) {
    this.pieces.push({ obj, lc: new THREE.Vector3(), v: vel.clone(), w: new THREE.Vector3((Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8), life, r });
  }
  clear() { for (const p of this.pieces) this.scene.remove(p.obj); this.pieces = []; }
}

interface Fx { mesh: THREE.Object3D; life: number; max: number; s0: number; s1: number; rise: number; uniform: boolean; base: number }
interface Enemy {
  id: number; kind: OrcKind; s: number; speed: number; hp: number; maxHp: number; reward: number; size: number;
  group: THREE.Group; limbs: Record<string, THREE.Group>; face: THREE.Object3D; parts: THREE.Group[];
  skin: THREE.MeshStandardMaterial; hpBg: THREE.Mesh; hpFg: THREE.Mesh;
  flashT: number; hurtT: number; bobOff: number; dead: boolean;
  knock: number; hopT: number; hopH: number; lift: number; hitSrc?: THREE.Vector3; slowT?: number; grabT?: number; stunT?: number;
  frost?: number; frozen?: number; iceShell?: THREE.Object3D;
  shellT: number; shellOn: boolean; freezeT: number;
}
interface Tower {
  id: number; kind: TowerKind; c: number; r: number; level: number; cooldown: number; invested: number;
  group: THREE.Group; head: THREE.Group; face: THREE.Object3D; muzzle: THREE.Object3D; flame: THREE.Object3D;
  recoil: number; target: Enemy | null; idleYaw: number; frozen: number; pulseT: number; gravStage?: number;
}
interface Projectile { pos: THREE.Vector3; start: THREE.Vector3; target: Enemy; mesh: THREE.Object3D; speed: number; dmg: number; t: number; splash: number }
interface TornadoFx { obj: THREE.Group; s: number; life: number; dmg: number; radius: number; spin: number }
interface BurnFx { mesh: THREE.Mesh; pos: THREE.Vector3; r: number; dps: number; life: number; max: number }
interface MeteorFx { obj: THREE.Object3D; pos: THREE.Vector3; to: THREE.Vector3; t: number; dmg: number; splash: number }

export class Game {
  renderer: THREE.WebGLRenderer; scene: THREE.Scene; camera: THREE.PerspectiveCamera;
  state: GameState; onState: (s: GameState) => void; onFloat: (f: FloatText) => void;
  world?: World; tiles: ('grass' | 'path' | 'blocked')[] = []; tileCarved: boolean[] = [];
  tileCenter: THREE.Vector3[] = []; waypoints: THREE.Vector3[] = []; cum: number[] = []; pathLen = 0;
  enemies: Enemy[] = []; towers: Tower[] = []; projectiles: Projectile[] = [];
  tornadoes: TornadoFx[] = []; burns: BurnFx[] = []; meteors: MeteorFx[] = [];
  particles: Particles; scatter: Scatter; fx: Fx[] = []; lights: THREE.PointLight[] = []; lightIdx = 0;
  hover: THREE.Mesh; hoverRing: THREE.Mesh; selRing: THREE.Mesh;
  spawnTimer = 0; spawned = 0; hpMult = 1; spdMult = 1; time = 0; shake = 0;
  raf = 0; lastEmit = 0; dirty = true; nextId = 1; floatId = 1;
  selectedTowerId: number | null = null; pointerDown: { x: number; y: number } | null = null;
  ray = new THREE.Raycaster(); plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  canvas: HTMLCanvasElement; sfx = new Sfx(); clock = new THREE.Clock(); ro?: ResizeObserver;
  camTarget = new THREE.Vector3(0, 0, 2.0); curSrc: THREE.Vector3 | null = null;

  constructor(canvas: HTMLCanvasElement, onState: (s: GameState) => void, onFloat: (f: FloatText) => void) {
    this.canvas = canvas; this.onState = onState; this.onFloat = onFloat;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1.05;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xa9dcff);
    this.scene.fog = new THREE.Fog(0xa9dcff, 34, 60);
    this.camera = new THREE.PerspectiveCamera(40, 1, 0.1, 120);

    this.scene.add(new THREE.HemisphereLight(0xffffff, 0x7fb069, 0.7));
    const sun = new THREE.DirectionalLight(0xfff3dc, 1.9); sun.position.set(11, 20, 9); sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048); sun.shadow.camera.left = -16; sun.shadow.camera.right = 16;
    sun.shadow.camera.top = 16; sun.shadow.camera.bottom = -16; sun.shadow.camera.near = 1; sun.shadow.camera.far = 60;
    sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.02; this.scene.add(sun);
    this.scene.add(new THREE.AmbientLight(0xffffff, 0.15));
    for (let i = 0; i < 6; i++) { const l = new THREE.PointLight(0xffffff, 0, 6); l.userData.life = 0; this.scene.add(l); this.lights.push(l); }

    this.particles = new Particles(this.scene);
    this.scatter = new Scatter(this.scene, (p, force) => this.particles.emit(p.clone().setY(0.1), 0xd9cfb4, Math.min(4, 1 + Math.floor(force * 0.5)), 1, 0.07, 0.5, 1.2));

    this.hover = new THREE.Mesh(DISC, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.42, depthWrite: false }));
    this.hover.scale.set(0.46, 1, 0.46); this.hover.visible = false; this.scene.add(this.hover);
    const ringGeo = new THREE.RingGeometry(0.94, 1, 64); ringGeo.rotateX(-Math.PI / 2);
    this.hoverRing = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6, side: THREE.DoubleSide }));
    this.hoverRing.visible = false; this.scene.add(this.hoverRing);
    this.selRing = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7, side: THREE.DoubleSide }));
    this.selRing.visible = false; this.scene.add(this.selRing);

    const best = Number(localStorage.getItem('voxeltd_best') || 0);
    this.state = {
      screen: 'menu', level: 1, wave: 0, wavesPerLevel: 5, lives: MAX_LIVES, maxLives: MAX_LIVES,
      gold: START_GOLD, score: 0, best, kills: 0, selected: null, selectedType: 'cannon',
      waveActive: false, countdown: 0, enemiesLeft: 0, muted: false, speed: 1, nextWave: '',
    };
    this.buildLevel(); this.bindInput();
    this.ro = new ResizeObserver(() => this.resize()); this.ro.observe(canvas.parentElement!);
    this.resize(); this.loop();
  }

  // ---------- level ----------
  buildLevel() {
    if (this.world) this.world.dispose();
    for (const t of this.towers) this.removeTower(t);
    for (const e of this.enemies) this.scene.remove(e.group);
    for (const p of this.projectiles) this.scene.remove(p.mesh);
    for (const tn of this.tornadoes) this.scene.remove(tn.obj);
    for (const m of this.meteors) this.scene.remove(m.obj);
    for (const b of this.burns) this.scene.remove(b.mesh);
    this.scatter.clear();
    this.towers = []; this.enemies = []; this.projectiles = []; this.tornadoes = []; this.burns = []; this.meteors = [];
    this.selectedTowerId = null; this.selRing.visible = false; this.spawned = 0;

    const layout = LAYOUTS[(this.state.level - 1) % LAYOUTS.length];
    this.tiles = new Array(W * H).fill('grass'); this.tileCarved = new Array(W * H).fill(false);
    for (let i = 0; i < layout.length - 1; i++) {
      const [c0, r0] = layout[i], [c1, r1] = layout[i + 1];
      const dc = Math.sign(c1 - c0), dr = Math.sign(r1 - r0);
      let c = c0, r = r0;
      while (true) { this.tiles[r * W + c] = 'path'; if (c === c1 && r === r1) break; c += dc; r += dr; }
    }
    this.waypoints = layout.map(([c, r]) => new THREE.Vector3(c - W / 2 + 0.5, 0, r - H / 2 + 0.5));
    this.waypoints.unshift(this.waypoints[0].clone().add(new THREE.Vector3(-1.2, 0, 0)));
    this.cum = [0];
    for (let i = 1; i < this.waypoints.length; i++) this.cum.push(this.cum[i - 1] + this.waypoints[i].distanceTo(this.waypoints[i - 1]));
    this.pathLen = this.cum[this.cum.length - 1] - 0.62;

    const isP = (c: number, r: number) => c >= 0 && c < W && r >= 0 && r < H && this.tiles[r * W + c] === 'path';
    for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) {
      const i = r * W + c; if (this.tiles[i] === 'path') continue;
      this.tileCarved[i] = isP(c - 1, r) || isP(c + 1, r) || isP(c, r - 1) || isP(c, r + 1);
    }

    const tileX = (c: number) => c - W / 2 + 0.5, tileZ = (r: number) => r - H / 2 + 0.5;
    const world = buildWorld({ W, H, level: this.state.level, biome: (this.state.level - 1) % BIOMES.length, waypoints: this.waypoints, tiles: this.tiles, tileCarved: this.tileCarved, tileX, tileZ });
    this.world = world; this.tileCenter = world.tileCenter;
    this.scene.add(world.group); // <- without this the whole island (grass, road, castle, trees) never renders
    const B = world.biome;
    // rain turns the sky overcast and gloomy; snow makes it pale and bright
    const wth = weatherOf(B);
    let skyTop = B.skyTop, skyBot = B.skyBot, fogCol = B.fog;
    if (wth === 'rain') {
      skyTop = new THREE.Color(B.skyTop).multiplyScalar(0.52).getHex();
      skyBot = new THREE.Color(B.skyBot).multiplyScalar(0.72).getHex();
      fogCol = new THREE.Color(B.fog).multiplyScalar(0.82).getHex();
    } else if (wth === 'snow') {
      skyTop = new THREE.Color(B.skyTop).lerp(new THREE.Color(0xffffff), 0.22).getHex();
      skyBot = new THREE.Color(B.skyBot).lerp(new THREE.Color(0xffffff), 0.4).getHex();
      fogCol = new THREE.Color(B.fog).lerp(new THREE.Color(0xffffff), 0.45).getHex();
    }
    if (this.scene.background instanceof THREE.Texture) this.scene.background.dispose();
    this.scene.background = makeSkyTexture(skyTop, skyBot);
    (this.scene.fog as THREE.Fog).color.setHex(fogCol);
    this.state.nextWave = this.previewWave();
    this.dirty = true;
  }
  posAt(s: number, out: THREE.Vector3) {
    if (s <= 0) return out.copy(this.waypoints[0]);
    for (let i = 1; i < this.waypoints.length; i++) if (s <= this.cum[i]) { const t = (s - this.cum[i - 1]) / (this.cum[i] - this.cum[i - 1]); return out.lerpVectors(this.waypoints[i - 1], this.waypoints[i], t); }
    return out.copy(this.waypoints[this.waypoints.length - 1]);
  }

  // ---------- flow ----------
  startGame() {
    const s = this.state; s.level = 1; s.gold = START_GOLD; s.score = 0; s.kills = 0; s.lives = MAX_LIVES;
    s.wave = 0; s.wavesPerLevel = 5; s.waveActive = false; s.countdown = 14; s.screen = 'playing'; s.selected = null;
    this.buildLevel(); this.sfx.setMusic('calm'); this.sfx.build();
    this.float('ORC DATANG DARI KIRI  ➜', this.waypoints[1].clone().setY(2.1), '#c4b5fd');
    this.dirty = true;
  }
  nextLevel() {
    const s = this.state; s.level++; s.gold += 90 + s.level * 25; s.lives = Math.min(MAX_LIVES, s.lives + 2);
    s.wave = 0; s.wavesPerLevel = Math.min(9, 5 + Math.floor((s.level - 1) / 2));
    s.waveActive = false; s.countdown = 14; s.screen = 'playing'; s.selected = null;
    this.buildLevel(); this.sfx.setMusic('calm'); this.sfx.levelUp(); this.dirty = true;
  }
  restart() { this.sfx.click(); this.startGame(); }
  cycleSpeed() { this.state.speed = this.state.speed === 1 ? 2 : this.state.speed === 2 ? 4 : 1; this.sfx.click(); this.dirty = true; }
  toggleMute() { this.state.muted = !this.state.muted; this.sfx.muted = this.state.muted; this.dirty = true; }
  setSelectedType(k: TowerKind) { this.state.selectedType = k; this.selectTower(null); this.sfx.click(); this.dirty = true; }
  callWave() {
    const s = this.state;
    if (s.screen !== 'playing' || s.waveActive) return;
    const bonus = Math.floor(s.countdown * 2);
    if (bonus > 0 && s.wave > 0) { s.gold += bonus; this.float(`+${bonus} 💰 bonus`, this.waypoints[this.waypoints.length - 1], '#fde047'); }
    this.startWave();
  }
  previewWave() {
    const s = this.state; const w = s.wave + 1; if (w > s.wavesPerLevel) return '';
    return `${this.spawnCount(w)} orc menuju kristal`;
  }
  spawnCount(w = this.state.wave) { return 8 + w * 2 + this.state.level * 2; }
  /**
   * The orcs that can ACTUALLY appear in this level. The menu roster is generated from THIS, never from a
   * hand-written list, so what is shown is always exactly what spawns (no ghost entries).
   */
  rosterKinds(): OrcKind[] {
    const seen = new Set<OrcKind>();
    const wl = this.state.wavesPerLevel;
    for (let w = 1; w <= wl; w++) for (let k = 0; k < 8; k++) for (const t of this.composeWave(w)) seen.add(t);
    return (Object.keys(ORC_DATA) as OrcKind[]).filter(k => seen.has(k));
  }

  // ---------- waves ----------
  /** the composition of one wave: mostly ordinary orcs, with the special ones appearing from the 2nd wave onwards */
  composeWave(w: number): OrcKind[] {
    const s = this.state; const n = this.spawnCount(w); const q: OrcKind[] = [];
    const lvl = s.level;
    for (let i = 0; i < n; i++) {
      const r = Math.random();
      if (w >= 2 && r < 0.14 + lvl * 0.015) q.push('bomber');
      else if (w >= 2 && r < 0.22 + lvl * 0.02) q.push('frostmage');
      else if ((w >= 3 || lvl >= 2) && r > 0.86 - lvl * 0.015) q.push('shellback');
      else if (w >= 3 && r > 0.72) q.push('splitter');
      else q.push('normal');
    }
    return q;
  }
  startWave() {
    const s = this.state; s.wave++; s.waveActive = true; s.countdown = 0;
    const L = s.level, w = s.wave;
    this.hpMult = (1 + 0.16 * (w - 1)) * Math.pow(1.4, L - 1);
    this.spdMult = Math.min(1.5, 1 + 0.05 * (L - 1));
    this.waveQueue = this.composeWave(w); this.spawnTimer = 0.3; s.nextWave = this.previewWave();
    this.sfx.wave(); this.dirty = true;
    this.float(w === s.wavesPerLevel ? 'WAVE TERAKHIR!  ➜' : 'ORC DATANG  ➜', this.waypoints[1].clone().setY(2.1), w === s.wavesPerLevel ? '#fda4af' : '#c4b5fd');
  }
  waveQueue: OrcKind[] = [];

  // ---------- enemies ----------
  spawnEnemy(kind: OrcKind, at = 0, hpScale = 1, sizeScale = 1) {
    const data = ORC_DATA[kind];
    const a = buildOrcKind(kind); const size = data.size * sizeScale * (0.95 + Math.random() * 0.1);
    const g = a.group; g.scale.setScalar(size); this.scene.add(g);
    const hpBg = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.1), new THREE.MeshBasicMaterial({ color: 0x1a1a2e, transparent: true, opacity: 0.6 }));
    const hpFg = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.1), new THREE.MeshBasicMaterial({ color: 0x4ade80 }));
    hpBg.position.y = 1.95 / data.size; hpFg.position.y = 1.95 / data.size; hpFg.position.z = 0.001;
    hpBg.quaternion.copy(this.camera.quaternion); hpFg.quaternion.copy(this.camera.quaternion);
    hpBg.visible = hpFg.visible = false;
    const grp = new THREE.Group(); grp.add(hpBg, hpFg); grp.name = 'hp'; g.add(grp);
    const hp = Math.round(data.hp * this.hpMult * hpScale);
    const e: Enemy = {
      id: this.nextId++, kind, s: at, speed: data.speed * this.spdMult * (0.94 + Math.random() * 0.12), hp, maxHp: hp,
      reward: data.reward, size, group: g, limbs: a.limbs, face: a.face, parts: a.parts, skin: a.skin,
      hpBg, hpFg, flashT: 0, hurtT: 0, bobOff: Math.random() * 6, dead: false,
      knock: 0, hopT: 0, hopH: 0, lift: 0, shellT: 2.5 + Math.random() * 2, shellOn: false, freezeT: 0,
    };
    this.enemies.push(e);
    const p = new THREE.Vector3(); this.posAt(at, p);
    g.position.copy(p); // place it on the road right away – never leave a fresh orc sitting at the world origin
    this.particles.emit(p.clone().setY(0.4), 0x9b5cff, 6, 1.5, 0.12, 0.5);
    this.sfx.spawn();
    return e;
  }
  enemyCenter(e: Enemy) { return e.group.position.clone().setY(e.group.position.y + e.size * 0.7); }
  damage(e: Enemy, dmg: number, src?: THREE.Vector3, silent = false) {
    if (e.dead) return;
    if (e.shellOn) { // 🐢 curled up: immune
      if (!silent && Math.random() < 0.05) { const c = this.enemyCenter(e); this.float('KEBAL', c.setY(c.y + 0.4), '#86efac'); }
      return;
    }
    e.hp -= dmg; if (!silent) { e.flashT = 0.08; e.hurtT = 0.22; }
    if (src) e.hitSrc = src.clone();
    if (!silent) this.particles.emit(this.enemyCenter(e), BLOOD, 4, 1.6, 0.07, 0.5, 2);
    if (e.hp <= 0) this.kill(e);
  }
  kill(e: Enemy) {
    e.dead = true;
    if ((e.frozen ?? 0) > 0) this.shatterIce(e); // a frozen orc dies TOGETHER with its ice: the shards burst as the body scatters
    const center = this.enemyCenter(e);
    const fwd = new THREE.Vector3(Math.sin(e.group.rotation.y), 0, Math.cos(e.group.rotation.y));
    let srcP = e.hitSrc ?? this.curSrc ?? undefined;
    if (!srcP) { let bd = 1e9; for (const t of this.towers) { const d = t.group.position.distanceTo(e.group.position); if (d < bd) { bd = d; srcP = t.group.position; } } }
    const away = srcP ? new THREE.Vector3(e.group.position.x - srcP.x, 0, e.group.position.z - srcP.z) : fwd.clone().negate();
    if (away.lengthSq() < 0.04) away.copy(fwd);
    away.normalize();
    const power = 3.1 + Math.min(3.4, ((e.maxHp - e.hp) / Math.max(14, e.maxHp * 0.3)) * 2.6);
    const travel = fwd.clone().multiplyScalar(e.speed * 0.8);
    // scattered pieces are never touched again, so the hit-flash would freeze on them and turn the whole corpse white.
    // Back to the real skin colour first.
    e.flashT = 0; e.skin.emissive.setHex(e.skin.color.getHex()); e.skin.emissiveIntensity = 0.12;
    this.scatter.burst(e.group, e.parts, center, away, power, travel);
    this.particles.emit(center, BLOOD, 18, 2.6, e.size * 0.16, 0.9, 3.5);
    this.particles.emit(center, e.skin.color.getHex(), 10, 2, e.size * 0.14, 0.8, 3);
    this.particles.emit(center, 0xfde047, 5, 1.5, 0.1, 0.6, 3.5);
    this.ring(center.clone().setY(0.06), BLOOD, 0.2, e.size * 1.6, 0.4, DISC, 0.7);
    this.state.gold += e.reward; this.state.score += e.reward * 10 * this.state.level; this.state.kills++;
    this.float(`+${e.reward}`, center.setY(center.y + 0.6), '#fde047');
    this.scene.remove(e.group);

    // 🎃 the splitter bursts into three small orcs
    if (e.kind === 'splitter') {
      this.float('PECAH!', e.group.position.clone().setY(e.group.position.y + 1), '#fdba74');
      for (let i = 0; i < 3; i++) {
        const mini = this.spawnEnemy('normal', Math.max(0, e.s - 0.3 + i * 0.28), 0.35, 0.62);
        mini.hopT = 0.5; mini.hopH = 0.5; mini.knock = 1.2;
        this.particles.emit(this.enemyCenter(mini), 0xfdba74, 8, 2, 0.08, 0.5, 2.5);
      }
      this.particles.emit(e.group.position, 0xfdba74, 22, 3, 0.12, 0.7, 3);
    }
    // 💣 the bomber detonates, hurting its own side in a chain reaction
    if (e.kind === 'bomber') {
      const at = e.group.position.clone();
      this.fireball(at.clone().setY(0.3), 1.1);
      this.ring(at.clone().setY(0.07), 0xffd166, 0.2, 3.2, 0.4); this.flash(at.clone().setY(0.5), 0xff9a3c, 8, 6);
      this.shake = Math.max(this.shake, 0.22); this.sfx.boom();
      this.float('BOM!', at.clone().setY(1.4), '#fbbf24');
      for (const o of [...this.enemies]) {
        if (o === e || o.dead) continue;
        const d = o.group.position.distanceTo(at); if (d > 1.9) continue;
        this.damage(o, Math.round(o.maxHp * 0.32), at.clone(), true);
        if (!o.dead) { o.knock = Math.max(o.knock, 2.2 * (1 - d / 1.9)); o.hopT = 0.35; o.hopH = 0.22; }
      }
    }
    this.sfx.pop();
    this.dirty = true;
  }
  leak(e: Enemy) {
    e.dead = true; this.scene.remove(e.group);
    this.state.lives--; this.shake = 0.4; this.sfx.hurt();
    if (this.state.lives > 0 && this.state.lives <= 3) this.sfx.warn();
    const end = this.waypoints[this.waypoints.length - 1];
    this.particles.emit(end.clone().setY(1), 0xff4d4d, 20, 3, 0.12, 0.6, 3);
    this.ring(end.clone().setY(0.08), 0xff4d4d, 0.3, 2.5, 0.5); this.flash(end.clone().setY(1), 0xff3333, 5);
    this.float('-1 ❤️', end.clone().setY(1.6), '#f87171');
    if (this.state.lives <= 0) { this.state.lives = 0; this.gameOver(); }
    this.dirty = true;
  }
  gameOver() {
    const s = this.state; s.screen = 'gameOver'; s.waveActive = false;
    if (s.score > s.best) { s.best = s.score; localStorage.setItem('voxeltd_best', String(s.best)); }
    this.sfx.setMusic('lose'); this.sfx.gameOver(); this.dirty = true;
  }

  // ---------- towers ----------
  stats(kind: TowerKind, level: number) {
    const d = TOWER_DATA[kind]; const i = level - 1;
    return { dmg: d.dmg[i], range: d.range[i], rate: d.rate[i], splash: d.splash[i] };
  }
  upgradeCost(kind: TowerKind, level: number) { return level >= 3 ? null : TOWER_DATA[kind].upgrade[level - 1]; }
  makeModel(kind: TowerKind, level: number) {
    const m = buildTowerKind(kind, level);
    const muzzle = new THREE.Group();
    muzzle.position.set(0, MUZZLE[kind].y, MUZZLE[kind].f); m.head.add(muzzle);
    return { ...m, muzzle };
  }
  placeTower(c: number, r: number) {
    const s = this.state; const kind = s.selectedType; const def = TOWER_DATA[kind];
    const center = this.tileCenter[r * W + c];
    if (s.gold < def.cost) { this.sfx.deny(); this.float('Emas kurang!', center.clone().setY(0.5), '#f87171'); return; }
    s.gold -= def.cost;
    const m = this.makeModel(kind, 1);
    m.group.position.copy(center); m.group.scale.setScalar(0.01);
    m.group.userData.target = this.tileCarved[r * W + c] ? 0.86 : 1;
    this.scene.add(m.group);
    this.world?.setGrassHole(center.x, center.z, 0.4, true);
    this.towers.push({
      id: this.nextId++, kind, c, r, level: 1, cooldown: 0.2, invested: def.cost,
      group: m.group, head: m.head, face: m.face, muzzle: m.muzzle, flame: m.flame,
      recoil: 0, target: null, idleYaw: 0, frozen: 0, pulseT: 0,
    });
    this.particles.emit(center.clone().setY(0.3), 0xffffff, 14, 2.2, 0.12, 0.5, 2.5);
    this.ring(center.clone().setY(0.06), parseInt(def.color.slice(1), 16), 0.3, 1.2, 0.4);
    this.sfx.build(); this.dirty = true;
  }
  removeTower(t: Tower) {
    this.scene.remove(t.group);
    this.world?.setGrassHole(t.group.position.x, t.group.position.z, 0.4, false);
    if (this.selectedTowerId === t.id) this.selectTower(null);
  }
  towerAt(c: number, r: number) { return this.towers.find(t => t.c === c && t.r === r); }
  selectTower(t: Tower | null) {
    this.selectedTowerId = t ? t.id : null;
    if (t) {
      const st = this.stats(t.kind, t.level);
      this.selRing.position.set(t.group.position.x, t.group.position.y + 0.05, t.group.position.z);
      this.selRing.scale.setScalar(st.range);
      (this.selRing.material as THREE.MeshBasicMaterial).color.setHex(parseInt(TOWER_DATA[t.kind].color.slice(1), 16));
      this.selRing.visible = true;
    } else this.selRing.visible = false;
    this.dirty = true;
  }
  upgradeSelected() {
    const t = this.towers.find(x => x.id === this.selectedTowerId); if (!t) return;
    const cost = this.upgradeCost(t.kind, t.level); if (cost == null) return;
    if (this.state.gold < cost) { this.sfx.deny(); return; }
    this.state.gold -= cost; t.invested += cost; t.level++;
    const pos = t.group.position.clone(); this.scene.remove(t.group);
    const m = this.makeModel(t.kind, t.level); m.group.position.copy(pos); m.group.scale.setScalar(0.6);
    m.group.userData.target = this.tileCarved[t.r * W + t.c] ? 0.86 : 1; this.scene.add(m.group);
    t.group = m.group; t.head = m.head; t.face = m.face; t.muzzle = m.muzzle; t.flame = m.flame;
    const col = parseInt(TOWER_DATA[t.kind].color.slice(1), 16);
    this.particles.emit(pos.clone().setY(0.6), col, 20, 2.5, 0.13, 0.6, 3);
    this.ring(pos.clone().setY(0.06), col, 0.3, 1.6, 0.5);
    this.float('UPGRADE!', pos.clone().setY(1.5), '#a5f3fc'); this.sfx.upgrade(); this.selectTower(t);
  }
  sellSelected() {
    const i = this.towers.findIndex(x => x.id === this.selectedTowerId); if (i < 0) return;
    const t = this.towers[i]; const v = Math.round(t.invested * 0.7);
    this.state.gold += v; this.removeTower(t); this.towers.splice(i, 1);
    this.particles.emit(t.group.position.clone().setY(0.4), 0xfde047, 12, 2, 0.1, 0.5);
    this.float(`+${v} 💰`, t.group.position.clone().setY(1), '#fde047'); this.sfx.coin(); this.dirty = true;
  }
  muzzleWorld(t: Tower, out = new THREE.Vector3()) {
    const a = t.head.rotation.y, g = t.group.scale.x, mz = MUZZLE[t.kind];
    return out.set(t.group.position.x + Math.sin(a) * mz.f * g, t.group.position.y + (0.3 + mz.y) * g, t.group.position.z + Math.cos(a) * mz.f * g);
  }
  kick(t: Tower, k: number) { if (t.muzzle) t.muzzle.scale.setScalar(k); }

  // ---------- effects ----------
  flash(pos: THREE.Vector3, color: number, intensity: number, dist = 5) {
    const l = this.lights[this.lightIdx]; this.lightIdx = (this.lightIdx + 1) % this.lights.length;
    l.position.copy(pos); l.color.setHex(color); l.intensity = intensity; l.distance = dist; l.userData.life = 1;
  }
  ring(pos: THREE.Vector3, color: number, s0: number, s1: number, life: number, geo: THREE.BufferGeometry = RING, opacity = 0.9, rise = 0) {
    if (Math.max((color >> 16) & 255, (color >> 8) & 255, color & 255) < 0x60) { color = 0xeee6d2; life = Math.min(life, 0.55); opacity *= 0.5; s1 = Math.max(s1, s0 * 2.2); }
    const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color, transparent: true, opacity, side: THREE.DoubleSide, depthWrite: false }));
    m.position.copy(pos); m.scale.setScalar(s0); this.scene.add(m);
    this.fx.push({ mesh: m, life, max: life, s0, s1, rise, uniform: false, base: 0.9 });
  }
  /** a glowing line (used for the golden bolt of Midas) */
  beamFx(a: THREE.Vector3, b: THREE.Vector3, color: number, width = 0.08, life = 0.25) {
    const d = b.clone().sub(a); const len = d.length(); if (len < 0.01) return; d.normalize();
    const g = new THREE.Group(); g.position.copy(a).add(b).multiplyScalar(0.5);
    g.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), d);
    for (const [w, c, k] of [[width * 2.6, color, 0.35], [width, 0xfff3b0, 1]] as [number, number, number][]) {
      const m = new THREE.Mesh(BOX, new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: k, depthWrite: false, blending: THREE.AdditiveBlending }));
      m.scale.set(w, w, len); g.add(m);
    }
    this.scene.add(g); this.fx.push({ mesh: g, life, max: life, s0: 1, s1: 1, rise: 0, uniform: false, base: 1 });
  }
  fireball(at: THREE.Vector3, size = 1) {
    const layers: [number, number, number, number, number][] = [[0xff4a14, 0.5, 2.1, 0.55, 1.1], [0xff9a1f, 0.4, 1.6, 0.42, 1.4], [0xfff0a8, 0.25, 1.0, 0.3, 1.8]];
    for (const [c, s0, s1, life, rise] of layers) {
      const m = new THREE.Mesh(SPH, new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.9, depthWrite: false }));
      m.position.copy(at).setY(at.y + 0.45 * size); m.scale.setScalar(s0 * size); this.scene.add(m);
      this.fx.push({ mesh: m, life, max: life, s0: s0 * size, s1: s1 * size, rise: rise * size, uniform: true, base: 0.9 });
    }
    for (let i = 0; i < 4; i++) {
      const fl = makeFlame(0.9 * size);
      fl.position.copy(at).add(new THREE.Vector3((Math.random() - 0.5) * 1.1 * size, 0.05, (Math.random() - 0.5) * 1.1 * size));
      fl.rotation.y = Math.random() * 6; this.scene.add(fl);
      this.fx.push({ mesh: fl, life: 0.5 + Math.random() * 0.25, max: 0.6, s0: 1, s1: 1, rise: 0.6 + Math.random() * 0.6, uniform: false, base: 0.9 });
    }
    this.particles.emit(at.clone().setY(at.y + 0.3), 0xffd166, 18, 3.8 * size, 0.12 * size, 0.6, 4);
    this.particles.emit(at.clone().setY(at.y + 0.3), 0xff6a1f, 14, 3 * size, 0.15 * size, 0.7, 3.5);
    this.particles.emit(at.clone().setY(at.y + 0.5), 0x3a3a44, 16, 1.3 * size, 0.22 * size, 1.5, 1.8, -1.2);
  }
  explode(at: THREE.Vector3, splash: number, dmg: number) {
    this.curSrc = at.clone();
    this.fireball(at, splash > 0 ? 1.15 : 0.7);
    this.ring(at.clone().setY(0.07), 0xffd166, 0.2, Math.max(1.2, splash * 2.2), 0.35);
    this.ring(at.clone().setY(0.04), 0xeee6d2, 0.5, 1.2, 0.5);
    this.flash(at.clone().setY(0.6), 0xff9a3c, 6, 5);
    this.shake = Math.max(this.shake, splash > 0 ? 0.2 : 0.12);
    this.sfx.boom();
    if (splash <= 0) return;
    for (const e of [...this.enemies]) {
      if (e.dead) continue;
      const d = e.group.position.distanceTo(at); if (d > splash) continue;
      const k = 1 - d / splash;
      this.damage(e, Math.round(dmg * (1 - 0.5 * k)), at);
      if (!e.dead) { e.knock = Math.max(e.knock, 2.4 * k); e.hopT = 0.35; e.hopH = 0.18; }
    }
  }
  float(text: string, world: THREE.Vector3, color: string) {
    const v = world.clone().project(this.camera); const rect = this.canvas.getBoundingClientRect();
    this.onFloat({ id: this.floatId++, x: (v.x * 0.5 + 0.5) * rect.width, y: (-v.y * 0.5 + 0.5) * rect.height, text, color });
  }

  // ---------- input ----------
  bindInput() {
    const c = this.canvas;
    c.addEventListener('pointerdown', e => { this.pointerDown = { x: e.clientX, y: e.clientY }; this.sfx.resume(); });
    c.addEventListener('pointerup', e => {
      if (!this.pointerDown) return;
      const dx = e.clientX - this.pointerDown.x, dy = e.clientY - this.pointerDown.y; this.pointerDown = null;
      if (dx * dx + dy * dy > 100) return;
      this.onTap(e.clientX, e.clientY);
    });
    c.addEventListener('pointermove', e => { if (e.pointerType === 'mouse') this.onHover(e.clientX, e.clientY); });
    c.addEventListener('pointerleave', () => { this.hover.visible = false; this.hoverRing.visible = false; });
  }
  pick(cx: number, cy: number) {
    const rect = this.canvas.getBoundingClientRect();
    const ndc = new THREE.Vector2(((cx - rect.left) / rect.width) * 2 - 1, -((cy - rect.top) / rect.height) * 2 + 1);
    this.ray.setFromCamera(ndc, this.camera); const p = new THREE.Vector3();
    if (!this.ray.ray.intersectPlane(this.plane, p)) return null;
    const c = Math.floor(p.x + W / 2), r = Math.floor(p.z + H / 2);
    if (c < 0 || c >= W || r < 0 || r >= H) return null;
    return { c, r };
  }
  onHover(cx: number, cy: number) {
    const t = this.pick(cx, cy);
    if (!t || this.state.screen !== 'playing' || this.tiles[t.r * W + t.c] !== 'grass' || this.towerAt(t.c, t.r)) { this.hover.visible = false; this.hoverRing.visible = false; return; }
    const kind = this.state.selectedType; const def = TOWER_DATA[kind]; const ok = this.state.gold >= def.cost; const ctr = this.tileCenter[t.r * W + t.c];
    const hr = this.tileCarved[t.r * W + t.c] ? 0.3 : 0.37;
    this.hover.visible = true; this.hover.position.set(ctr.x, ctr.y + 0.06, ctr.z); this.hover.scale.set(hr, 1, hr);
    (this.hover.material as THREE.MeshBasicMaterial).color.setHex(ok ? 0xffffff : 0xff5555);
    this.hoverRing.visible = true; this.hoverRing.position.set(ctr.x, ctr.y + 0.05, ctr.z);
    this.hoverRing.scale.setScalar(def.range[0]);
    (this.hoverRing.material as THREE.MeshBasicMaterial).color.setHex(ok ? parseInt(def.color.slice(1), 16) : 0xff5555);
  }
  onTap(cx: number, cy: number) {
    if (this.state.screen !== 'playing') return;
    const t = this.pick(cx, cy); if (!t) { this.selectTower(null); return; }
    const tw = this.towerAt(t.c, t.r);
    if (tw) { this.selectTower(tw.id === this.selectedTowerId ? null : tw); this.sfx.click(); return; }
    if (this.selectedTowerId) { this.selectTower(null); return; }
    if (this.tiles[t.r * W + t.c] === 'grass') this.placeTower(t.c, t.r); else this.sfx.deny();
  }

  /** small 3/4-view portraits of every tower, drawn from the real models (used by the cards) */
  makePortraits(): Partial<Record<TowerKind, string>> {
    const out: Partial<Record<TowerKind, string>> = {};
    let r: THREE.WebGLRenderer | null = null;
    try {
      const size = 192;
      r = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
      r.setPixelRatio(1); r.setSize(size, size, false); r.setClearColor(0x000000, 0);
      r.outputColorSpace = THREE.SRGBColorSpace; r.toneMapping = THREE.ACESFilmicToneMapping; r.toneMappingExposure = 1.15;
      const sc = new THREE.Scene();
      sc.add(new THREE.HemisphereLight(0xffffff, 0x8899aa, 1.2));
      const key = new THREE.DirectionalLight(0xfff3dc, 2.4); key.position.set(3, 5, 4); sc.add(key);
      const rim = new THREE.DirectionalLight(0x9bd0ff, 0.9); rim.position.set(-4, 2, -3); sc.add(rim);
      const cam = new THREE.PerspectiveCamera(28, 1, 0.1, 60);
      for (const kind of Object.keys(TOWER_DATA) as TowerKind[]) {
        const m = buildTowerKind(kind, 1); m.group.rotation.y = 0.38; m.group.updateMatrixWorld(true);
        const box = new THREE.Box3().setFromObject(m.group); const c = box.getCenter(new THREE.Vector3()); const sz = box.getSize(new THREE.Vector3());
        const radius = Math.max(sz.y * 0.56, Math.max(sz.x, sz.z) * 0.62);
        const dist = radius / Math.tan(THREE.MathUtils.degToRad(cam.fov / 2));
        cam.position.copy(c).addScaledVector(new THREE.Vector3(0, 0.45, 1).normalize(), dist); cam.lookAt(c);
        sc.add(m.group); r.render(sc, cam); out[kind] = r.domElement.toDataURL('image/png'); sc.remove(m.group);
      }
    } catch { /* the UI falls back to emoji icons */ }
    finally { r?.dispose(); r?.forceContextLoss(); }
    return out;
  }
  /** small portraits of every orc, drawn from the real models (used by the menu roster) */
  makeOrcPortraits(): Partial<Record<OrcKind, string>> {
    const out: Partial<Record<OrcKind, string>> = {};
    let r: THREE.WebGLRenderer | null = null;
    try {
      const size = 160;
      r = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
      r.setPixelRatio(1); r.setSize(size, size, false); r.setClearColor(0x000000, 0);
      r.outputColorSpace = THREE.SRGBColorSpace; r.toneMapping = THREE.ACESFilmicToneMapping; r.toneMappingExposure = 1.15;
      const sc = new THREE.Scene();
      sc.add(new THREE.HemisphereLight(0xffffff, 0x8899aa, 1.2));
      const key = new THREE.DirectionalLight(0xfff3dc, 2.4); key.position.set(3, 5, 4); sc.add(key);
      const rim = new THREE.DirectionalLight(0x9bd0ff, 0.9); rim.position.set(-4, 2, -3); sc.add(rim);
      const cam = new THREE.PerspectiveCamera(28, 1, 0.1, 60);
      for (const kind of Object.keys(ORC_DATA) as OrcKind[]) {
        const a = buildOrcKind(kind); const g = new THREE.Group(); g.add(...a.parts); g.rotation.y = 0.45; g.updateMatrixWorld(true);
        const box = new THREE.Box3().setFromObject(g); const c = box.getCenter(new THREE.Vector3()); const sz = box.getSize(new THREE.Vector3());
        const radius = Math.max(sz.y * 0.56, Math.max(sz.x, sz.z) * 0.6);
        const dist = radius / Math.tan(THREE.MathUtils.degToRad(cam.fov / 2));
        cam.position.copy(c).addScaledVector(new THREE.Vector3(0, 0.3, 1).normalize(), dist); cam.lookAt(c);
        sc.add(g); r.render(sc, cam); out[kind] = r.domElement.toDataURL('image/png'); sc.remove(g);
      }
    } catch { /* fall back to emoji */ }
    finally { r?.dispose(); r?.forceContextLoss(); }
    return out;
  }

  // ---------- loop ----------
  loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, this.clock.getDelta());
    const steps = this.state.screen === 'playing' ? this.state.speed : 1;
    for (let i = 0; i < steps; i++) {
      this.time += dt;
      // a crash here used to freeze EVERYTHING (dead buttons, no orcs). Keep the frame alive and print the real error.
      try { this.update(dt); } catch (err) {
        const self = this as unknown as { _err?: boolean };
        if (!self._err) { self._err = true; console.error('[VoxelDefense] galat di update() — kirim pesan ini:', err); }
      }
    }
    if (this.world) { this.world.pads.visible = this.state.screen === 'playing'; this.world.update(this.clock.elapsedTime); }
    this.render();
    const now = performance.now();
    if (this.dirty || now - this.lastEmit > 150) {
      this.lastEmit = now; this.dirty = false;
      const t = this.towers.find(x => x.id === this.selectedTowerId);
      const s = this.state;
      s.selected = t ? {
        id: t.id, kind: t.kind, level: t.level, upgradeCost: this.upgradeCost(t.kind, t.level), sellValue: Math.round(t.invested * 0.7),
        dmg: this.stats(t.kind, t.level).dmg, range: this.stats(t.kind, t.level).range.toFixed(1),
        rate: (1 / this.stats(t.kind, t.level).rate).toFixed(1), splash: this.stats(t.kind, t.level).splash,
      } : null;
      s.enemiesLeft = s.waveActive ? this.enemies.length + Math.max(0, this.waveQueue.length) : 0;
      this.onState({ ...s });
    }
  };

  update(dt: number) {
    const s = this.state; const playing = s.screen === 'playing';
    this.curSrc = null; this.scatter.update(dt);

    for (const l of this.lights) if (l.userData.life > 0) { l.userData.life -= dt * 7; l.intensity *= Math.max(0, 1 - dt * 9); if (l.userData.life <= 0) l.intensity = 0; }
    this.fx = this.fx.filter(f => {
      f.life -= dt; if (f.life <= 0) { this.scene.remove(f.mesh); return false; }
      const t = 1 - f.life / f.max; const op = (f.max > 2 ? Math.min(1, f.life / 1.5) : 1 - t) * f.base;
      if (f.uniform) f.mesh.scale.setScalar(f.s0 + (f.s1 - f.s0) * (1 - Math.pow(1 - t, 3)));
      else { const e2 = 1 - Math.pow(1 - t, 3); f.mesh.scale.set(f.s0 + (f.s1 - f.s0) * e2, 1, f.s0 + (f.s1 - f.s0) * e2); }
      if (f.rise) f.mesh.position.y += f.rise * dt;
      if (f.mesh.name === 'flame') {
        f.mesh.traverse(o => { const m = (o as THREE.Mesh).material as THREE.Material | undefined; if (m && 'opacity' in m) (m as THREE.MeshBasicMaterial).opacity = op; });
        flickerFlame(f.mesh, this.time * 1.3 + f.mesh.id, 0.35 + 0.65 * (f.life / f.max));
      } else if ((f.mesh as THREE.Mesh).material) ((f.mesh as THREE.Mesh).material as THREE.MeshBasicMaterial).opacity = op;
      return true;
    });

    if (playing) {
      if (!s.waveActive) { s.countdown -= dt; if (s.countdown <= 0) this.startWave(); }
      if (s.waveActive && this.waveQueue.length) {
        this.spawnTimer -= dt;
        if (this.spawnTimer <= 0) {
          const kind = this.waveQueue.shift()!; this.spawnEnemy(kind); this.spawned++;
          this.spawnTimer = kind === 'splitter' || kind === 'shellback' ? 1.1 : Math.max(0.35, 0.8 - s.level * 0.03);
        }
      }

      // ---- enemies ----
      const tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3();
      for (const e of this.enemies) {
        // every orc is guarded on its own: one broken orc must not stop the others from being placed on the map
        try {
        e.flashT = Number.isFinite(e.flashT) ? Math.max(0, e.flashT - dt) : 0;
        e.hurtT = Number.isFinite(e.hurtT) ? Math.max(0, e.hurtT - dt) : 0;
        e.lift = Math.max(0, e.lift - dt * 2.2);
        // 🐢 shellback: curls into its shell (invulnerable, rooted) then walks again
        if (e.kind === 'shellback') {
          e.shellT -= dt;
          if (!e.shellOn && e.shellT <= 0) { e.shellOn = true; e.shellT = 2.4; }
          else if (e.shellOn && e.shellT <= 0) { e.shellOn = false; e.shellT = 4.2; }
          const sh = e.limbs.shell;
          if (sh) {
            const want = e.shellOn ? -1.15 : 0;
            sh.rotation.x += (want - sh.rotation.x) * Math.min(1, dt * 8);
            sh.position.y = 0.72 + (e.shellOn ? -0.28 : 0);
          }
        }
        // ❄️ frost mage: freezes the nearest tower so it cannot shoot
        if (e.kind === 'frostmage') {
          e.freezeT -= dt;
          if (e.freezeT <= 0) {
            let best: Tower | null = null, bd = 3.4;
            for (const t of this.towers) { const d = t.group.position.distanceTo(e.group.position); if (d < bd) { bd = d; best = t; } }
            if (best) {
              e.freezeT = 3.6; best.frozen = 2.6; best.recoil = 1;
              this.particles.emit(best.group.position.clone().setY(1.2), 0x9be8ff, 18, 2.2, 0.1, 0.7, 2.5);
              this.ring(best.group.position.clone().setY(0.08), 0x9be8ff, 0.3, 1.6, 0.5);
              this.flash(best.group.position.clone().setY(1), 0x9be8ff, 4, 4);
              this.float('BEKU! ❄️', best.group.position.clone().setY(1.8), '#7dd3fc'); this.sfx.freeze();
            }
          }
        }
        if (e.knock) { e.s = Math.max(0, e.s - e.knock * dt); e.knock *= Math.exp(-dt * 5); if (Math.abs(e.knock) < 0.05) e.knock = 0; }
        if ((e.slowT ?? 0) > 0) e.slowT! -= dt; // ❄️ Frostbite: chilled to half speed
        if ((e.stunT ?? 0) > 0) e.stunT! -= dt; // 🕳️ grabbed / slammed: cannot move at all
        // ❄️ frozen solid inside a block of ice: cannot move, and when the ice expires it SHATTERS with the orc
        if ((e.frozen ?? 0) > 0) {
          e.frozen! -= dt;
          if (e.frozen! <= 0) {
            this.shatterIce(e);
            this.damage(e, e.maxHp * 2);
            continue;
          }
        }
        if ((e.frost ?? 0) > 0 && (e.frozen ?? 0) <= 0) e.frost = Math.max(0, (e.frost ?? 0) - dt * 0.12);
        const speedMul = e.shellOn || (e.stunT ?? 0) > 0 || (e.frozen ?? 0) > 0 ? 0 : (e.slowT ?? 0) > 0 ? 0.5 : 1;
        e.s += e.speed * speedMul * dt;
        if (e.s >= this.pathLen) { this.leak(e); continue; }
        this.posAt(e.s, tmp); this.posAt(Math.min(this.pathLen, e.s + 0.3), tmp2);
        const ph = this.time * 10 * (e.speed / 1.25) + e.bobOff;
        const hopT = e.hopT; if (hopT > 0) e.hopT = hopT - dt;
        e.group.position.set(tmp.x, Math.abs(Math.sin(ph)) * 0.06 * speedMul + (hopT > 0 ? Math.sin(Math.min(1, hopT / 0.4) * Math.PI) * (e.hopH || 0.3) : 0) + e.lift, tmp.z);
        e.group.rotation.y = Math.atan2(tmp2.x - tmp.x, tmp2.z - tmp.z);
        e.group.rotation.x = -clamp(e.knock * 0.12, -0.5, 0.5);
        poseOrc(e.limbs, ph, this.time, speedMul > 0);
        // hit flash: a warm tint, NOT full-white emissive (1.6 white blew the whole orc out to pure white under ACES)
        const base = e.skin.color;
        e.flashT = Math.max(0, e.flashT);
        const frostAmt = e.frost ?? 0;
        if (e.flashT > 0) { e.skin.emissive.setHex(0xffe0d6); e.skin.emissiveIntensity = 0.55; }
        else if (frostAmt > 0.02) { e.skin.emissive.setHex(0x9be8ff); e.skin.emissiveIntensity = 0.12 + frostAmt * 0.8; } // ❄️ turns icy as frost piles up
        else { e.skin.emissive.setHex(base.getHex()); e.skin.emissiveIntensity = 0.12; }
        // a NaN here would collapse the whole body to nothing (invisible orc that towers still shoot at)
        const hit = Number.isFinite(e.hurtT) ? clamp(e.hurtT / 0.22, 0, 1) : 0;
        const es = Number.isFinite(e.size) && e.size > 0.05 ? e.size : 1;
        e.group.scale.set(es * (1 + hit * 0.14), es * (1 - hit * 0.12), es * (1 + hit * 0.14));
        updateFace(e.face, dt, this.time, {
          lookX: Math.sin(this.time * 0.9 + e.bobOff) * 0.55,
          lookY: Math.sin(this.time * 0.6 + e.bobOff * 2) * 0.22 + (e.shellOn ? -0.4 : 0),
          focus: 0.15, squint: hit > 0 ? 1 : e.shellOn ? 0.6 : 0, worry: e.hp / e.maxHp < 0.3 ? 0.8 : 0,
        });
        const ratio = e.hp / e.maxHp;
        if (ratio < 1) {
          e.hpBg.visible = e.hpFg.visible = true; e.hpFg.scale.x = ratio; e.hpFg.position.x = -(1 - ratio) * 0.4;
          (e.hpFg.material as THREE.MeshBasicMaterial).color.setHex(ratio > 0.5 ? 0x4ade80 : ratio > 0.25 ? 0xfacc15 : 0xf87171);
        }
        const hpg = e.group.getObjectByName('hp'); if (hpg) hpg.rotation.y = -e.group.rotation.y;
        } catch (err) {
          const self = this as unknown as { _err2?: boolean };
          if (!self._err2) { self._err2 = true; console.error('[VoxelDefense] galat pada satu orc (yang lain tetap jalan):', err); }
          const fix = new THREE.Vector3(); this.posAt(Math.max(0, e.s), fix); e.group.position.copy(fix);
        }
      }
      this.enemies = this.enemies.filter(e => !e.dead);

      // ---- towers ----
      for (const t of this.towers) {
        t.cooldown -= dt; t.recoil = Math.max(0, t.recoil - dt * 4); t.pulseT -= dt;
        const st = this.stats(t.kind, t.level); const tp = t.group.position;
        const target = t.group.userData.target ?? 1;
        if (t.group.scale.x < target) t.group.scale.setScalar(Math.min(target, t.group.scale.x + dt * 4));
        if (t.muzzle && t.muzzle.scale.x > 0 && t.muzzle.scale.x < 2) t.muzzle.scale.multiplyScalar(Math.max(0, 1 - dt * 14));
        if (t.flame) flickerFlame(t.flame, this.time + t.id);
        const shards = t.group.getObjectByName('shards'); if (shards) { shards.rotation.y += dt * 1.3; shards.children.forEach((c, i) => { c.position.y = Math.sin(this.time * 2.5 + i * 2) * 0.05; }); }
        const spin = t.head.getObjectByName('spin'); if (spin) spin.rotation.y += dt * 1.6;
        const halo = t.head.getObjectByName('halo'); if (halo) { halo.rotation.z += dt * 0.9; halo.position.y = (halo.userData.y0 as number | undefined ?? (halo.userData.y0 = halo.position.y)) + Math.sin(this.time * 1.8 + t.id) * 0.04; }
        const sfl = t.head.getObjectByName('snowField'); // gentle snowfall drifting around Frostbite
        if (sfl) {
          sfl.rotation.y += dt * 0.35;
          for (const flake of sfl.children) {
            flake.position.y -= dt * (0.14 + ((flake.id % 5) * 0.04));
            flake.position.x += Math.sin(this.time * 1.4 + flake.id) * dt * 0.16;
            if (flake.position.y < 0.02) flake.position.y = 1.55;
          }
        }
        const swirl = t.head.getObjectByName('swirl'); if (swirl) swirl.rotation.y += dt * (0.8 + t.recoil * 6);
        const rotor = t.head.getObjectByName('rotor'); if (rotor) rotor.rotation.y += dt * (6 + t.recoil * 30);
        const funnel = t.head.getObjectByName('funnel'); if (funnel) funnel.rotation.y -= dt * 2.2;
        const coin = t.head.getObjectByName('coin'); if (coin) { coin.rotation.y += dt * 3; coin.position.y = 1.05 + Math.sin(this.time * 3 + t.id) * 0.05; }
        const wandStar = t.head.getObjectByName('wandStar'); if (wandStar) wandStar.rotation.y += dt * 3.2;

        // look at the target (or the nearest enemy, or wander)
        let gaze: Enemy | null = t.target && !t.target.dead ? t.target : null;
        if (!gaze) {
          let bd = 6.5 * 6.5;
          for (const e of this.enemies) { if (e.dead) continue; const dx = e.group.position.x - tp.x, dz = e.group.position.z - tp.z; const d = dx * dx + dz * dz; if (d < bd) { bd = d; gaze = e; } }
        }
        const want = gaze ? Math.atan2(gaze.group.position.x - tp.x, gaze.group.position.z - tp.z) : Math.sin(this.time * 0.5 + t.id) * 0.35;
        let d = want - t.head.rotation.y; d = Math.atan2(Math.sin(d), Math.cos(d));
        t.head.rotation.y += d * Math.min(1, dt * (gaze ? 11 : 3));
        // living body
        const rc = t.recoil, br = Math.sin(this.time * 2.2 + t.id) * 0.015;
        t.head.scale.set(1 + rc * 0.06, 1 - rc * 0.08 + br, 1 + rc * 0.06);
        t.head.rotation.z = Math.sin(this.time * 1.6 + t.id) * 0.025;
        t.head.position.set(-rc * 0.12 * Math.sin(t.head.rotation.y), 0.3, -rc * 0.12 * Math.cos(t.head.rotation.y));
        let lx = Math.sin(this.time * 0.7 + t.id) * 0.7, ly = Math.sin(this.time * 0.45 + t.id * 2) * 0.35;
        if (gaze) {
          const want2 = Math.atan2(gaze.group.position.x - tp.x, gaze.group.position.z - tp.z);
          const diff = Math.atan2(Math.sin(want2 - t.head.rotation.y), Math.cos(want2 - t.head.rotation.y));
          lx = clamp(diff * 1.5, -1, 1); ly = -0.15;
        }
        updateFace(t.face, dt, this.time, { lookX: lx, lookY: ly, focus: gaze ? 1 : 0.25, squint: rc * 1.2, worry: t.frozen > 0 ? 1 : 0 });

        if (t.frozen > 0) { t.frozen -= dt; continue; }

        // target in range = the leading orc
        let target2: Enemy | null = null;
        for (const e of this.enemies) {
          if (e.dead || e.shellOn || (e.frozen ?? 0) > 0) continue; // a frozen orc is already dealt with – pick the next one
          const dx = e.group.position.x - tp.x, dz = e.group.position.z - tp.z;
          if (dx * dx + dz * dz > st.range * st.range) continue;
          if (!target2 || e.s > target2.s) target2 = e;
        }
        t.target = target2;

        if (t.kind === 'draco') { this.dracoTick(t, st, dt); continue; }
        if (t.kind === 'sol') { this.solBeam(t, st, dt); continue; } // ☀️ a blazing solar beam out of its FACE
        if (t.kind === 'chroma') { if (t.cooldown <= 0 && target2) { t.cooldown = st.rate; t.recoil = 1; this.chromaShot(t, target2, st); } continue; }
        if (t.kind === 'frostbite') { this.frostTick(t, target2, st, dt); continue; }
        if (t.kind === 'gravity') { this.gravityTick(t, st, dt); continue; }
        if (t.kind === 'tornado') { if (t.cooldown <= 0 && target2) { t.cooldown = st.rate; t.recoil = 1; this.spawnTornado(t, target2, st); } continue; }
        if (t.kind === 'meteor') { if (t.cooldown <= 0 && target2) { t.cooldown = st.rate; t.recoil = 1; this.callMeteor(t, st); } continue; }
        if (t.kind === 'midas') { if (t.cooldown <= 0 && target2) { this.midasShot(t, st); } continue; }
        if (target2 && t.cooldown <= 0) this.fireCannon(t, target2);
      }

      // ---- projectiles ----
      this.projectiles = this.projectiles.filter(p => {
        const goal = this.enemyCenter(p.target);
        const total = Math.max(1.5, p.start.distanceTo(goal));
        p.t += dt * p.speed / total;
        const k = Math.min(1, p.t);
        p.pos.lerpVectors(p.start, goal, k); p.pos.y += Math.sin(k * Math.PI) * Math.min(1.2, total * 0.3);
        p.mesh.position.copy(p.pos);
        if (Math.random() < 0.6) this.particles.emit(p.pos, 0xffd9a0, 1, 0.3, 0.05, 0.25, 0.3, 0);
        if (p.t >= 1) { this.explode(goal.clone().setY(0.1), p.splash, p.dmg); this.scene.remove(p.mesh); return false; }
        return true;
      });

      // ---- tornadoes ----
      const tmpT = new THREE.Vector3();
      this.tornadoes = this.tornadoes.filter(tn => {
        tn.life -= dt; tn.spin += dt * 9; tn.s += 2.2 * dt;
        if (tn.s >= this.pathLen || tn.life <= 0) { this.scene.remove(tn.obj); return false; }
        this.posAt(tn.s, tmpT); tn.obj.position.copy(tmpT); tn.obj.rotation.y = tn.spin;
        if (Math.random() < 0.6) this.particles.emit(tmpT.clone().setY(0.6), 0xbae6fd, 1, 1.4, 0.05, 0.4, 1.5, -1);
        for (const e of this.enemies) {
          if (e.dead || e.shellOn) continue;
          if (e.group.position.distanceTo(tmpT) > tn.radius) continue;
          e.lift = Math.max(e.lift, 1.1); e.s = Math.max(0, e.s - 1.2 * dt);
          this.damage(e, tn.dmg * dt, undefined, true);
          if (Math.random() < 0.15) this.particles.emit(this.enemyCenter(e), 0x7dd3fc, 1, 1, 0.05, 0.35, 1.5, -1);
        }
        return true;
      });

      // ---- meteors ----
      this.meteors = this.meteors.filter(mt => {
        mt.t += dt * 3.2;
        mt.obj.position.lerp(mt.to, Math.min(1, dt * 3.2));
        mt.obj.rotation.y += dt * 6; mt.obj.rotation.x += dt * 4;
        if (Math.random() < 0.8) this.particles.emit(mt.obj.position, 0xff7a3c, 1, 1, 0.12, 0.35, 0, 0);
        if (mt.obj.position.distanceTo(mt.to) < 0.25) {
          this.explode(mt.to.clone().setY(0.1), mt.splash, mt.dmg);
          const burn = new THREE.Mesh(DISC, new THREE.MeshBasicMaterial({ color: 0xff7a3c, transparent: true, opacity: 0.6, depthWrite: false }));
          burn.position.copy(mt.to).setY(0.05); burn.scale.setScalar(mt.splash); this.scene.add(burn);
          this.burns.push({ mesh: burn, pos: mt.to.clone(), r: mt.splash, dps: mt.dmg * 0.35, life: 4, max: 4 });
          this.scene.remove(mt.obj); return false;
        }
        return true;
      });

      // ---- burn pools ----
      this.burns = this.burns.filter(b => {
        b.life -= dt; if (b.life <= 0) { this.scene.remove(b.mesh); return false; }
        (b.mesh.material as THREE.MeshBasicMaterial).opacity = Math.min(0.6, b.life * 0.25);
        b.mesh.rotation.y += dt * 0.6;
        if (Math.random() < 0.2) this.particles.emit(b.pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * b.r, 0.1, (Math.random() - 0.5) * b.r)), 0xff7a3c, 1, 0.8, 0.06, 0.5, 1.5, -1);
        for (const e of this.enemies) { if (e.dead) continue; if (e.group.position.distanceTo(b.pos) <= b.r) this.damage(e, b.dps * dt, undefined, true); }
        return true;
      });

      // ---- wave complete ----
      if (s.waveActive && !this.waveQueue.length && !this.enemies.length) {
        s.waveActive = false; this.spawned = 0;
        const bonus = 15 + s.wave * 5 + s.level * 5; s.gold += bonus; s.score += 100 * s.level;
        if (s.wave >= s.wavesPerLevel) {
          s.screen = 'levelComplete'; s.score += 500 * s.level;
          if (s.score > s.best) { s.best = s.score; localStorage.setItem('voxeltd_best', String(s.best)); }
          this.sfx.setMusic('win'); this.sfx.levelUp();
          const end = this.waypoints[this.waypoints.length - 1];
          this.particles.emit(end.clone().setY(1), 0xf0abfc, 60, 4, 0.14, 1.2, 5);
        } else {
          s.countdown = 10; s.nextWave = this.previewWave();
          this.float(`Wave selesai +${bonus} 💰`, this.waypoints[this.waypoints.length - 1].clone().setY(1.5), '#fde047');
          this.sfx.waveClear();
        }
        this.dirty = true;
      }
    }
    this.particles.update(dt);
    this.shake = Math.max(0, this.shake - dt * 1.5);
  }

  /**
   * 🕳️ gravity: THREE beats, TWO impacts.
   *   1. SLAM   – everyone in range is punched DOWN into the ground (first impact)
   *   2. LIFT   – the survivors are hoisted into the air and held
   *   3. SLAM 2 – they are smashed DOWN into the terrain (second impact, lethal)
   */
  gravityTick(t: Tower, st: { dmg: number; range: number; rate: number }, dt: number) {
    const tp = t.group.position; const R = st.range; const maxGrab = 1 + t.level;
    const stage = t.gravStage ?? 0;
    if (t.pulseT <= 0) {
      const inRange = () => {
        const out: Enemy[] = [];
        for (const e of this.enemies) {
          if (e.dead || e.shellOn) continue;
          const dx = e.group.position.x - tp.x, dz = e.group.position.z - tp.z;
          if (dx * dx + dz * dz > R * R) continue;
          out.push(e); if (out.length >= maxGrab) break;
        }
        return out;
      };
      t.recoil = 1;
      if (stage === 0) {
        // BEAT 1 — SLAM DOWN
        const picked = inRange();
        for (const e of picked) {
          e.lift = 0; e.hopT = 0.4; e.hopH = 0.55; e.stunT = Math.max(e.stunT ?? 0, 0.55);
          this.curSrc = tp.clone(); this.damage(e, Math.round(st.dmg * 1.15), tp.clone());
        }
        if (picked.length) {
          this.ring(tp.clone().setY(0.08), 0xc4b5fd, 0.3, R, 0.55, RING, 0.85);
          this.particles.emit(tp.clone().setY(0.15), 0xc4b5fd, 20, 3, 0.11, 0.6, 2.6);
          this.particles.emit(tp.clone().setY(0.15), 0xffffff, 10, 2.4, 0.08, 0.5, 2.2);
          this.flash(tp.clone().setY(0.5), 0xc4b5fd, 4, R + 1);
          this.shake = Math.max(this.shake, 0.24); this.sfx.thud();
          this.float('HANTAM!', tp.clone().setY(1.3), '#c4b5fd');
          t.pulseT = 0.45; t.gravStage = 1;
        } else { t.pulseT = 0.4; t.gravStage = 0; }
      } else if (stage === 1) {
        // BEAT 2 — LIFT
        const lifted = inRange();
        for (const e of lifted) {
          e.grabT = 1.8; e.stunT = Math.max(e.stunT ?? 0, 2); e.lift = 1.25;
          const c = this.enemyCenter(e); this.float('TERANGKAT!', c.setY(c.y + 1.3), '#c4b5fd');
        }
        if (lifted.length) {
          this.ring(tp.clone().setY(tp.y + 0.1), 0xc4b5fd, 0.3, R, 0.9, RING, 0.6);
          this.particles.emit(tp.clone().setY(tp.y + 0.2), 0xc4b5fd, 12, 2, 0.08, 0.6, 2);
          this.flash(tp.clone().setY(tp.y + 0.8), 0xc4b5fd, 3, R + 1);
          this.sfx.prism(); t.pulseT = 1.95; t.gravStage = 2;
        } else { t.pulseT = 0.35; t.gravStage = 0; }
      } else {
        // BEAT 3 — SLAM DOWN INTO THE TERRAIN (lethal)
        let any = false;
        for (const e of [...this.enemies]) {
          if (e.dead || (e.grabT ?? 0) <= 0) continue;
          any = true; e.grabT = 0; e.lift = 0;
          const at = e.group.position.clone();
          this.particles.emit(at.clone().setY(0.1), 0xc4b5fd, 22, 3.4, 0.12, 0.7, 2.8);
          this.particles.emit(at.clone().setY(0.1), 0xffffff, 12, 2.8, 0.08, 0.55, 2.4);
          this.ring(at.clone().setY(0.08), 0xffffff, 0.2, 1.9, 0.42, RING, 0.9);
          this.ring(at.clone().setY(0.12), 0xc4b5fd, 0.35, 2.6, 0.55, RING, 0.75);
          this.flash(at.clone().setY(0.6), 0xc4b5fd, 6, 6);
          this.float('HANTAM! ×2', at.clone().setY(1.3), '#c4b5fd');
          this.curSrc = tp.clone(); this.damage(e, e.maxHp * 2, tp.clone());
        }
        if (any) { this.shake = Math.max(this.shake, 0.3); this.sfx.thud(); }
        t.pulseT = st.rate; t.gravStage = 0;
      }
    }
    // while lifted, the victims bob in the air
    for (const e of this.enemies) {
      const g = e.grabT ?? 0;
      if (g <= 0) continue;
      e.grabT = g - dt;
      e.lift = 1.25 + Math.sin(this.time * 3.4 + e.bobOff) * 0.1;
      e.s = Math.max(0, e.s - 0.25 * dt);
      if (Math.random() < 0.3) this.particles.emit(this.enemyCenter(e), 0xc4b5fd, 1, 0.5, 0.05, 0.35, 1, -1);
    }
  }
  // 🌪️ tornado: a spinning funnel that runs down the road and lifts orcs into the air
  spawnTornado(_t: Tower, target: Enemy, st: { dmg: number; splash: number }) {
    const g = new THREE.Group();
    const cloud = new THREE.Mesh(SPH, new THREE.MeshStandardMaterial({ color: 0xf0f9ff, roughness: 0.85, transparent: true, opacity: 0.9 }));
    cloud.scale.set(0.42, 0.26, 0.42); cloud.position.y = 1.15; g.add(cloud);
    for (let i = 0; i < 3; i++) {
      const c = new THREE.Mesh(new THREE.ConeGeometry(0.42 - i * 0.1, 0.42, 12), new THREE.MeshStandardMaterial({ color: i % 2 ? 0x7dd3fc : 0x38bdf8, roughness: 0.5, transparent: true, opacity: 0.8 }));
      c.position.y = 0.85 - i * 0.32; g.add(c);
    }
    for (let i = 0; i < 3; i++) {
      const r = new THREE.Mesh(new THREE.TorusGeometry(0.5 - i * 0.12, 0.03, 6, 18), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6, depthWrite: false }));
      r.rotation.x = Math.PI / 2; r.position.y = 0.35 + i * 0.35; g.add(r);
    }
    this.scene.add(g);
    this.tornadoes.push({ obj: g, s: Math.max(0, target.s - 0.4), life: 3.2, dmg: st.dmg, radius: st.splash, spin: 0 });
    this.sfx.whoosh();
  }
  // 🌠 meteor: a rock falls from the sky onto the biggest cluster in range
  callMeteor(t: Tower, st: { dmg: number; range: number; splash: number }) {
    const tp = t.group.position; const R = st.range;
    let best: THREE.Vector3 | null = null, bestN = 0;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const dx = e.group.position.x - tp.x, dz = e.group.position.z - tp.z; if (dx * dx + dz * dz > R * R) continue;
      let n = 0;
      for (const o of this.enemies) if (!o.dead && o.group.position.distanceTo(e.group.position) < 1.4) n++;
      if (n > bestN) { bestN = n; best = e.group.position.clone(); }
    }
    if (!best) { t.cooldown = 0.5; return; }
    const obj = new THREE.Mesh(SPH, new THREE.MeshStandardMaterial({ color: 0xff7a3c, emissive: 0xff4500, emissiveIntensity: 0.9, roughness: 0.5 }));
    obj.scale.setScalar(0.3); obj.position.copy(best).add(new THREE.Vector3(1.2, 6.5, 1.2)); this.scene.add(obj);
    this.meteors.push({ obj, pos: best.clone(), to: best.clone(), t: 0, dmg: st.dmg, splash: st.splash });
    this.float('☄️ METEOR!', best.clone().setY(1.6), '#fdba74'); this.sfx.launch();
  }
  // 💰 midas: golden bolt at the most wounded orc; below 30% HP it turns into gold
  midasShot(t: Tower, st: { dmg: number; rate: number }) {
    const tp = t.group.position;
    let best: Enemy | null = null, bestR = 2;
    for (const e of this.enemies) {
      if (e.dead || e.shellOn) continue;
      const r = e.hp / e.maxHp;
      if (r < bestR) { bestR = r; best = e; }
    }
    if (!best) { t.cooldown = 0.35; return; }
    t.cooldown = st.rate; t.recoil = 1;
    const from = this.muzzleWorld(t); const to = this.enemyCenter(best);
    this.beamFx(from, to, 0xfbbf24, 0.07, 0.22);
    this.particles.emit(from, 0xffe066, 6, 1.6, 0.07, 0.35, 2);
    this.curSrc = tp;
    if (bestR <= 0.3) {
      // EXECUTE: turn into gold
      const bonus = Math.round(best.reward * 2.5 + 10);
      this.state.gold += bonus; this.state.score += bonus * 5;
      this.particles.emit(to, 0xffd166, 26, 3, 0.12, 0.9, 3.2);
      this.ring(best.group.position.clone().setY(0.08), 0xffd166, 0.3, 2, 0.5);
      this.float(`+${bonus} 🪙`, to.setY(to.y + 0.8), '#fde047');
      this.flash(to, 0xffd166, 5, 5); this.sfx.coin();
      this.damage(best, best.maxHp * 2, tp);
    } else {
      this.damage(best, st.dmg, tp);
      this.particles.emit(to, 0xffe066, 8, 2, 0.08, 0.45, 2.2);
    }
  }
  // 🔵 cannon: a shell that arcs into the target and explodes
  fireCannon(t: Tower, target: Enemy) {
    const st = this.stats(t.kind, t.level);
    t.cooldown = st.rate; t.recoil = 1;
    const from = this.muzzleWorld(t);
    const shell = new THREE.Mesh(SPH, new THREE.MeshBasicMaterial({ color: 0xffd9a0 }));
    shell.scale.setScalar(0.16);
    const glow = new THREE.Mesh(SPH, new THREE.MeshBasicMaterial({ color: 0xff8a4c, transparent: true, opacity: 0.5, depthWrite: false }));
    glow.scale.setScalar(0.34); shell.add(glow);
    shell.position.copy(from); this.scene.add(shell);
    this.projectiles.push({ pos: from.clone(), start: from.clone(), target, mesh: shell, speed: 16, dmg: st.dmg, t: 0, splash: st.splash });
    this.kick(t, 1); this.flash(from, 0xffe08a, 3, 3);
    this.particles.emit(from, 0xffe08a, 5, 1.6, 0.07, 0.25, 0.8, 0);
    this.sfx.shoot();
  }

  // 🐉 Draco: a continuous flamethrower cone – burns EVERY orc standing in front of the dragon's snout
  dracoTick(t: Tower, st: { dmg: number; range: number }, dt: number) {
    const tp = t.group.position; const R = st.range; const ang = t.head.rotation.y;
    const fwd = new THREE.Vector3(Math.sin(ang), 0, Math.cos(ang));
    const CONE = Math.PI / 5; let hit = 0;
    for (const e of this.enemies) {
      if (e.dead || e.shellOn) continue;
      const dx = e.group.position.x - tp.x, dz = e.group.position.z - tp.z;
      const d = Math.hypot(dx, dz); if (d > R) continue;
      let diff = Math.atan2(dx, dz) - ang; diff = Math.atan2(Math.sin(diff), Math.cos(diff));
      if (Math.abs(diff) > CONE) continue;
      hit++;
      this.damage(e, st.dmg * dt, undefined, true);
      if (Math.random() < 0.22) this.particles.emit(this.enemyCenter(e), 0xff7a1a, 1, 0.8, 0.08, 0.35, 1.5, -1.5);
    }
    if (hit > 0) {
      t.recoil = Math.max(t.recoil, 0.35);
      const from = this.muzzleWorld(t); // starts right AT the dragon's snout and streams outward
      for (let i = 0; i < 3; i++) {
        const k = Math.random() * 0.92;
        const p = from.clone().addScaledVector(fwd, k * R * 0.9);
        p.add(new THREE.Vector3((Math.random() - 0.5) * k * 0.95, Math.random() * 0.35, (Math.random() - 0.5) * k * 0.95));
        this.particles.emit(p, k < 0.4 ? 0xffe066 : k < 0.72 ? 0xf97316 : 0x8a8a99, 1, 0.5, 0.11 + k * 0.11, 0.35, 1.4, -3);
      }
      if (Math.random() < 0.35) this.flash(from.clone().addScaledVector(fwd, 0.6), 0xff8a3c, 1.6, 3);
      if (Math.random() < 0.2) this.sfx.flame();
    }
  }
  /**
   * ☀️ Sol: a blazing SOLAR BEAM fired out of its face. The ray travels in a straight line and pierces EVERY
   * enemy standing in it – the more it passes through, the more each one burns (the first hit is the hardest).
   */
  solBeam(t: Tower, st: { dmg: number; range: number; rate: number }, _dt: number) {
    const tp = t.group.position; const R = st.range;
    let lead: Enemy | null = null;
    for (const e of this.enemies) {
      if (e.dead || e.shellOn) continue;
      const dx = e.group.position.x - tp.x, dz = e.group.position.z - tp.z;
      if (dx * dx + dz * dz > R * R) continue;
      if (!lead || e.s > lead.s) lead = e;
    }
    if (!lead) { t.cooldown = 0.3; return; }
    t.cooldown = st.rate; t.recoil = 1;
    const from = this.muzzleWorld(t);                    // straight out of the sun's face
    const aim = this.enemyCenter(lead).clone();
    const dir = aim.clone().sub(from).normalize();
    const end = from.clone().addScaledVector(dir, R + 0.7);
    this.beamFx(from, end, 0xfff3b0, 0.17, 0.22);      // hot core
    this.beamFx(from, end, 0xfbbf24, 0.36, 0.16);      // wide glow
    const hits: { e: Enemy; k: number }[] = [];
    for (const e of this.enemies) {
      if (e.dead || e.shellOn) continue;
      const rel = this.enemyCenter(e).sub(from); const k = rel.dot(dir);
      if (k < 0.2 || k > R + 0.7) continue;
      if (rel.addScaledVector(dir, -k).length() < 0.5 + e.size * 0.4) hits.push({ e, k });
    }
    hits.sort((a, b) => a.k - b.k);
    hits.forEach((h, i) => {
      const c = this.enemyCenter(h.e);
      this.curSrc = from.clone();
      this.damage(h.e, Math.round(st.dmg * Math.pow(0.86, i)), from.clone());
      if (!h.e.dead) { h.e.knock = Math.max(h.e.knock, 1.5); h.e.hopT = 0.3; h.e.hopH = 0.16; }
      this.particles.emit(c, 0xfff3b0, 8, 2, 0.08, 0.35, 2);
      this.particles.emit(c, 0xfbbf24, 5, 1.4, 0.07, 0.35, 1.6);
      this.ring(c.clone(), 0xfbbf24, 0.1, 0.7, 0.2, RING, 0.8);
    });
    if (hits.length >= 3) this.float(`☀️ ×${hits.length} TERBAKAR!`, aim.setY(aim.y + 0.9), '#fde68a');
    this.flash(from, 0xfff3b0, 5, 5); this.shake = Math.max(this.shake, 0.12); this.sfx.prism();
  }
  // 💎 Chroma: one light beam that BOUNCES between enemies, each bounce weaker
  chromaShot(t: Tower, target: Enemy, st: { dmg: number }) {
    const from = this.muzzleWorld(t);
    const hits: { e: Enemy; from: THREE.Vector3 }[] = [];
    let cur = target; const maxHop = 1 + t.level;
    for (let i = 0; i < maxHop; i++) {
      const a = i === 0 ? from : hits[i - 1].from.clone().lerp(this.enemyCenter(hits[i - 1].e), 1);
      hits.push({ e: cur, from: a });
      let best: Enemy | null = null, bd = 2.7;
      for (const e of this.enemies) {
        if (e.dead || e === cur || hits.some(h => h.e === e)) continue;
        const d = e.group.position.distanceTo(cur.group.position); if (d < bd) { bd = d; best = e; }
      }
      if (!best) break;
      cur = best;
    }
    let prev = from;
    hits.forEach((h, i) => {
      const to = this.enemyCenter(h.e);
      this.beamFx(prev, to, i === 0 ? 0xf0abfc : 0xa855f7, 0.075, 0.26);
      this.curSrc = prev.clone();
      this.damage(h.e, Math.round(st.dmg * Math.pow(0.78, i)), prev.clone());
      this.particles.emit(to, 0xf0abfc, 6, 1.8, 0.06, 0.35, 2);
      this.ring(to.clone(), 0xf0abfc, 0.1, 0.55, 0.18, RING, 0.7);
      prev = to;
    });
    if (hits.length >= 3) { const c = this.enemyCenter(hits[hits.length - 1].e); this.float(`💎 ×${hits.length} PANTUL!`, c.setY(c.y + 0.9), '#e879f9'); }
    this.kick(t, 1); this.flash(from, 0xe879f9, 3, 3);
    this.particles.emit(from, 0xf0abfc, 8, 1.8, 0.06, 0.35, 2);
    this.sfx.prism();
  }
  /**
   * ❄️ Frostbite: sprays a STREAM OF SNOW at the leading orc. Frost keeps piling up on its skin until it is
   * encased in a block of ice – and when that ice breaks, the orc breaks with it.
   */
  frostTick(t: Tower, target: Enemy | null, st: { dmg: number }, dt: number) {
    if (!target) { t.cooldown = 0.2; return; }
    const from = this.muzzleWorld(t); const to = this.enemyCenter(target); const dir = to.clone().sub(from);
    // ❄️ the snow spray: a widening cone of flakes, whiter and tighter at the nozzle, cooler and looser at the target
    for (let i = 0; i < 3; i++) {
      const k = Math.pow(Math.random(), 0.6) * 0.97;
      const p = from.clone().addScaledVector(dir, k);
      const spread = 0.16 + k * 0.95;
      p.add(new THREE.Vector3((Math.random() - 0.5) * spread, (Math.random() - 0.5) * spread * 0.7, (Math.random() - 0.5) * spread));
      this.particles.emit(p, k < 0.3 ? 0xffffff : k < 0.62 ? 0xd8f2ff : 0x7dd3fc, 1, 0.7, 0.06 + k * 0.11, 0.45, 1.1, 1.4);
    }
    if (Math.random() < 0.22) { // a big glittering snowflake fleck
      const k = 0.25 + Math.random() * 0.6;
      const p = from.clone().addScaledVector(dir, k).add(new THREE.Vector3((Math.random() - 0.5) * 0.55, (Math.random() - 0.5) * 0.45, (Math.random() - 0.5) * 0.55));
      this.particles.emit(p, 0xffffff, 1, 0.5, 0.16, 0.55, 1, 1);
    }
    if (Math.random() < 0.25) this.particles.emit(from.clone(), 0xd8f2ff, 2, 1.2, 0.11, 0.4, 1.2, 2); // cold mist puffing out of the nozzle
    this.damage(target, st.dmg * dt, undefined, true);
    target.slowT = 0.4;
    target.frost = Math.min(1, (target.frost ?? 0) + dt * 0.55); // about 2 s of steady spray to freeze it solid
    if (target.frost >= 1 && (target.frozen ?? 0) <= 0) this.freezeEnemy(target);
    if (t.cooldown <= 0) { t.cooldown = 0.15; this.beamFx(from, to, 0x9be8ff, 0.05, 0.16); }
    t.recoil = Math.max(t.recoil, 0.3);
  }
  /** encases an orc in a block of ice, with a crown of ice shards on top */
  freezeEnemy(e: Enemy) {
    if (e.dead || (e.frozen ?? 0) > 0) return;
    e.frozen = 1.6; e.frost = 1; e.stunT = Math.max(e.stunT ?? 0, 1.8); e.lift = 0;
    const ice = new THREE.MeshStandardMaterial({ color: 0x9be8ff, transparent: true, opacity: 0.55, roughness: 0.15, emissive: 0x7dd3fc, emissiveIntensity: 0.45, depthWrite: false });
    const iceCore = new THREE.MeshStandardMaterial({ color: 0x7dd3fc, transparent: true, opacity: 0.75, roughness: 0.2, emissive: 0x38bdf8, emissiveIntensity: 0.4, depthWrite: false });
    const snowM = new THREE.MeshStandardMaterial({ color: 0xf0f9ff, roughness: 0.85 });
    const g = new THREE.Group(); g.position.y = 0.55;
    // faceted block: a crystalline core inside a translucent shell, with glowing frost veins running down the faces
    const inner = new THREE.Mesh(new THREE.OctahedronGeometry(0.72), iceCore); inner.scale.set(1.15, 1.45, 1.15); g.add(inner);
    const ih = new THREE.Mesh(new THREE.OctahedronGeometry(0.72), OUTLINE_MAT); ih.scale.set(1.2, 1.5, 1.2); g.add(ih);
    const block = new THREE.Mesh(BOX, ice); block.scale.set(1.28, 1.5, 1.28); g.add(block);
    const ol = new THREE.Mesh(BOX, OUTLINE_MAT); ol.scale.set(1.34, 1.58, 1.34); g.add(ol);
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const vein = new THREE.Mesh(BOX, new THREE.MeshBasicMaterial({ color: 0xe0f2fe, transparent: true, opacity: 0.85 }));
      vein.scale.set(0.045, 1.35, 0.02); vein.position.set(Math.sin(a) * 0.66, 0, Math.cos(a) * 0.66); vein.rotation.y = a; g.add(vein);
    }
    // snow cap on top + icicles + a crown of big crystal shards
    const capTop = new THREE.Mesh(new THREE.SphereGeometry(0.78, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), snowM);
    capTop.scale.set(1, 0.42, 1); capTop.position.y = 0.72; g.add(capTop);
    const capOl = new THREE.Mesh(capTop.geometry, OUTLINE_MAT); capOl.scale.set(1.06, 0.45, 1.06); capTop.add(capOl);
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const ic = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.26, 6), ice);
      ic.position.set(Math.sin(a) * 0.62, -0.35, Math.cos(a) * 0.62); ic.rotation.x = Math.PI; g.add(ic);
    }
    for (let i = 0; i < 7; i++) {
      const c = new THREE.Mesh(new THREE.OctahedronGeometry(0.11 + Math.random() * 0.08), ice);
      c.position.set((Math.random() - 0.5) * 1.15, 0.82 + Math.random() * 0.32, (Math.random() - 0.5) * 1.15);
      c.rotation.set(Math.random() * 3, Math.random() * 3, Math.random() * 3); g.add(c);
    }
    e.iceShell = g; e.group.add(g);
    const p = e.group.position.clone();
    this.ring(p.clone().setY(0.08), 0x9be8ff, 0.2, 1.6, 0.45, RING, 0.9);
    this.particles.emit(p.clone().setY(e.size * 0.6), 0xd8f2ff, 22, 2.6, 0.1, 0.7, 2.4);
    this.flash(p.clone().setY(e.size * 0.8), 0x9be8ff, 5, 5);
    this.float('BEKU! ❄️', p.setY(p.y + e.size + 0.8), '#7dd3fc');
    this.sfx.freeze();
  }
  /** the ice block BREAKS: ice shards fly in every direction and the orc breaks along with it */
  shatterIce(e: Enemy) {
    const p = e.group.position.clone(); const cy = e.size * 0.55;
    if (e.iceShell) { e.group.remove(e.iceShell); e.iceShell = undefined; }
    const iceMat = new THREE.MeshStandardMaterial({ color: 0x9be8ff, transparent: true, opacity: 0.85, roughness: 0.15, emissive: 0x7dd3fc, emissiveIntensity: 0.55 });
    // 16 crystal shards blast outwards in every direction
    for (let i = 0; i < 16; i++) {
      const s = new THREE.Mesh(new THREE.OctahedronGeometry(0.11 + Math.random() * 0.11), iceMat);
      s.position.copy(p).add(new THREE.Vector3((Math.random() - 0.5) * e.size * 1.3, cy + (Math.random() - 0.5) * e.size * 1.3, (Math.random() - 0.5) * e.size * 1.3));
      this.scene.add(s);
      this.scatter.toss(s, new THREE.Vector3((Math.random() - 0.5) * 6, 2.4 + Math.random() * 3.2, (Math.random() - 0.5) * 6), 1.8 + Math.random(), 0.1);
    }
    // ice spikes erupt from the ground where it landed
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2 + Math.random() * 0.5;
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.1 + Math.random() * 0.05, 0.3 + Math.random() * 0.22, 6), iceMat);
      spike.position.set(p.x + Math.cos(a) * (0.32 + Math.random() * 0.35), 0.02, p.z + Math.sin(a) * (0.32 + Math.random() * 0.35));
      spike.rotation.set((Math.random() - 0.5) * 0.25, Math.random() * 3, (Math.random() - 0.5) * 0.25);
      this.scene.add(spike); this.scatter.toss(spike, new THREE.Vector3(0, 0.25, 0), 3.2, 0.1);
    }
    // ice chunks left lying on the ground
    for (let i = 0; i < 3; i++) {
      const chunk = new THREE.Mesh(new THREE.OctahedronGeometry(0.13 + Math.random() * 0.09), iceMat);
      const a = Math.random() * 6.28;
      chunk.position.copy(p).add(new THREE.Vector3(Math.cos(a) * (0.3 + Math.random() * 0.5), 0.1, Math.sin(a) * (0.3 + Math.random() * 0.5)));
      this.scene.add(chunk);
      this.scatter.toss(chunk, new THREE.Vector3(0, 0.6, 0), 5, 0.13);
    }
    this.ring(p.clone().setY(0.08), 0xffffff, 0.15, 2.0, 0.32, RING, 0.95);
    this.ring(p.clone().setY(0.12), 0x9be8ff, 0.3, 2.8, 0.55, RING, 0.8);
    this.particles.emit(p.clone().setY(cy), 0xd8f2ff, 34, 3.8, 0.11, 0.9, 3.2);
    this.particles.emit(p.clone().setY(cy), 0xffffff, 22, 3, 0.09, 0.75, 2.8);
    this.particles.emit(p.clone().setY(0.15), 0xf0f9ff, 14, 2.2, 0.14, 1.1, 1.6, -1);
    this.flash(p.clone().setY(e.size), 0x9be8ff, 7, 6.5);
    this.shake = Math.max(this.shake, 0.18);
    this.float('PECAH! 💥', p.setY(p.y + e.size + 0.9), '#bae6fd');
    this.sfx.thud();
  }

  render() {
    const aspect = this.camera.aspect; const d = Math.max(21, 36 / aspect); // sized for the 24x14 island
    const dir = new THREE.Vector3(0, 1.15, 0.95).normalize();
    this.camera.position.copy(this.camTarget).addScaledVector(dir, d);
    if (this.shake > 0) {
      const k = this.shake * this.shake * 0.6;
      this.camera.position.x += (Math.random() - 0.5) * k; this.camera.position.y += (Math.random() - 0.5) * k;
    }
    this.camera.lookAt(this.camTarget);
    this.renderer.render(this.scene, this.camera);
  }
  resize() {
    const p = this.canvas.parentElement!; const w = p.clientWidth, h = p.clientHeight; if (!w || !h) return;
    this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
  }
  destroy() { cancelAnimationFrame(this.raf); this.ro?.disconnect(); this.sfx.dispose(); this.renderer.dispose(); }
}
